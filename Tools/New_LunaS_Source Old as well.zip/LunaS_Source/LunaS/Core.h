#ifndef __CORE_H
#define __CORE_H
#include "stdafx.h"
#pragma comment(lib, "detours.lib")
#pragma comment(lib, "KosaLib.lib")
#include <windows.h>
#include <stdio.h>
#include <detours.h> 
#include "Exports.h"

#include <KServer.h>
#include "Command.h"
#include "Config.h"

class Core
{

};
#endif
