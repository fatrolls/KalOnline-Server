#undef UNICODE
#include "Core.h"



void __stdcall Hooked_ServerStart(int start)
{
	KServer Server;
	Config config;
	
	Server::CIOServer::Start(start);
	Server.ConsoleMessage(Color::BLUE, "Reading [LunaS] . . . ");
	config.ReadConfig();
}

void __fastcall Hooked_ChatCommand(int *PlayerPointer, void *_edx, char *Command)
{
	LunaCommand LCommand(PlayerPointer, Command);
	LCommand.ReloadConfig();
	LCommand.Coords();
	LCommand.Teleport();
	LCommand.Speed();
	LCommand.BuffAll();
	Server::CPlayer::ChatCommand(PlayerPointer, Command);
}

BOOL APIENTRY DllMain( HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved )
{
	IExports Exports;
	ItemUse itemuse;

    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        {
				Exports.Initialize();
				itemuse.Load();
				DetourTransactionBegin();
				DetourUpdateThread(GetCurrentThread());
				DetourAttach(&(PVOID&)Server::CIOServer::Start, Hooked_ServerStart);
				DetourAttach(&(PVOID&)Server::CPlayer::ChatCommand, Hooked_ChatCommand);
				DetourTransactionCommit();
				break;

		}
    case DLL_PROCESS_DETACH:
        {
			itemuse.Restore();
            DetourTransactionBegin();
            DetourUpdateThread(GetCurrentThread());
            DetourDetach(&(PVOID&)Server::CIOServer::Start, Hooked_ServerStart);
			DetourDetach(&(PVOID&)Server::CPlayer::ChatCommand, Hooked_ChatCommand);
            DetourTransactionCommit();
            break;
        }
    }
    return TRUE;
}





