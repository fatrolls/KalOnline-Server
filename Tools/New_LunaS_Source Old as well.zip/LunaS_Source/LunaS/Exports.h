#ifndef __EXPORTS_H
#define __EXPORTS_H

class IExports
{
	public:
		static FARPROC p[15*4];
		static unsigned long _p;
		virtual void Initialize();
		HINSTANCE hL;
	private:
		
		
};

#endif