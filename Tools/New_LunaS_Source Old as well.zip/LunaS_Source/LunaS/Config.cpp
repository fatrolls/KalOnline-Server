#include "stdafx.h"
#include "Config.h"

#pragma region Vectors
vector<TeleportItem_class>::iterator TeleitemIt;
vector<TeleportItem_class> TeleportItem;

vector<SpawnTimer_class> SpawnTimer;
vector<SpawnTimer_class>::iterator SpawnTimerIt;

vector<GoldenPot_class> GoldenPot;
vector<GoldenPot_class>::iterator GoldenPotIt;

vector<LunaS_class> LunaS;
vector<LunaS_class>::iterator LunaSIt;

vector<TeleportCommand_class> TeleportCommand;
vector<TeleportCommand_class>::iterator TeleportCommandIt;




#pragma endregion

void Config::ReadConfig()
{

	KServer Server;
	IKalConfig * Config = new IKalConfig;

	TeleportItem_class teleitem;
	SpawnTimer_class spawntimer;
	GoldenPot_class goldenpot;
	LunaS_class lunas;
	TeleportCommand_class telecommand;


	
	TeleportCommand.clear();
	LunaS.clear();
	GoldenPot.clear();
	SpawnTimer.clear();
	TeleportItem.clear();


	Config->Load("LunaConfig","./Config/LunaConfig.txt");
	Server.ConsoleMessage(Color::BLUE, "Reading [LunaS_Config] . . .");
	if(!Config->IsLoaded("LunaConfig"))
	{
		Server.ConsoleMessage(Color::RED, "LunaS 'Config/LunaConfig.txt' File open failed at LunaS::Config::ReadConfig()");
		Sleep(1000);
		Server.ConsoleMessage(Color::BLACK, "LunaS [Creating ConfigFile] . . .");
		string True = "\"true\"";
		string False = "\"false\"";
		string WelcomeMsg = "\"Welcome, Have fun in our Server.\"";
		string TeleMessage = "\"Teleported!\"";
		string TeleFailMessage = "\"You need item XXX to teleport\"";
		string AssassinMessage = "\"You can't teleport in assasin mode!\"";
		string SpawnTimer = "\"[Boss] Spawned\"";
		string GoldenPotSuccses = "\"[GoldenPot] Succes!!\"";
		string GoldenPotFailed = "\"[GoldenPot] Failed!!\"";
		string RebirthBlock = "\"[PrivateNotice] You cant use Rb's in this area! AREA 2\"";
		string TempCommand = "\"/temp\"";
		string NaroCommand = "\"/naro\"";
		string CargoCommand = "\"/cargo\"";
		string MineCommand = "\"/mine\"";
		string PubCommand = "\"/pub\"";
		string CopCommand = "\"/cop\"";
		ofstream LunaConfig("./Config/LunaConfig.txt", std::ios_base::out | std::ios_base::app );
		LunaConfig << "/*##################################################################*/" << endl;
		LunaConfig << "/*########################LunaS Configuration#######################*/" << endl;
		LunaConfig << "/*##################################################################*/" << endl;
		LunaConfig << "" << endl;
		LunaConfig << "/*TeleportItem*/" << endl;
		LunaConfig << "(TeleportItem (Level 1) (Index 6000) (RequiredItem 0 0) (DeleteReqiredItem "<< False <<") (Coordinates 0 267634 243008) (FailMessage "<< TeleFailMessage <<") (AssasinMessage "<< AssassinMessage << "))" << endl;
		LunaConfig << "" << endl;
		LunaConfig << "/*TeleportCommand*/" << endl;
		LunaConfig << "(TeleportCommand (RequiredLevel 1) (Command "<< TempCommand <<") (RequiredItem 0 0) (DeleteReqiredItem "<< True <<") (Coordinates 0 267634 243008) (Geon 100) (Message "<< TeleMessage <<") (AssasinMessage "<< AssassinMessage <<") (RequiredItemMessage "<< TeleFailMessage <<"))" << endl;
		LunaConfig << "(TeleportCommand (RequiredLevel 1) (Command "<< NaroCommand <<") (RequiredItem 0 0) (DeleteReqiredItem "<< True <<") (Coordinates 0 267634 243008) (Geon 100) (Message "<< TeleMessage <<") (AssasinMessage "<< AssassinMessage <<") (RequiredItemMessage "<< TeleFailMessage <<"))" << endl;
		LunaConfig << "(TeleportCommand (RequiredLevel 1) (Command "<< CargoCommand <<") (RequiredItem 0 0) (DeleteReqiredItem "<< True <<") (Coordinates 0 267634 243008) (Geon 100) (Message "<< TeleMessage <<") (AssasinMessage "<< AssassinMessage <<") (RequiredItemMessage "<< TeleFailMessage <<"))" << endl;
		LunaConfig << "(TeleportCommand (RequiredLevel 1) (Command "<< MineCommand <<") (RequiredItem 0 0) (DeleteReqiredItem "<< True <<") (Coordinates 0 267634 243008) (Geon 100) (Message "<< TeleMessage <<") (AssasinMessage "<< AssassinMessage <<") (RequiredItemMessage "<< TeleFailMessage <<"))" << endl;
		LunaConfig << "(TeleportCommand (RequiredLevel 1) (Command "<< PubCommand <<") (RequiredItem 0 0) (DeleteReqiredItem "<< True <<") (Coordinates 0 267634 243008) (Geon 100) (Message "<< TeleMessage <<") (AssasinMessage "<< AssassinMessage <<") (RequiredItemMessage "<< TeleFailMessage <<"))" << endl;
		LunaConfig << "(TeleportCommand (RequiredLevel 1) (Command "<< CopCommand <<") (RequiredItem 0 0) (DeleteReqiredItem "<< True <<") (Coordinates 0 267634 243008) (Geon 100) (Message "<< TeleMessage <<") (AssasinMessage "<< AssassinMessage <<") (RequiredItemMessage "<< TeleFailMessage <<"))" << endl;
		LunaConfig << "" << endl;

		LunaConfig.close();
		Sleep(1000);
		Server.ConsoleMessage(Color::BLACK, "LunaS [ConfigFile has been created] . . .");
		this->ReadConfig();
	}
	else if(Config->IsLoaded("LunaConfig"))
	{
		IKalDBSection * MainSection = &Config->Get("LunaConfig");
		for(unsigned int i = 0; i < MainSection->ChildSize(); i++)
		{
			IKalDBSection * FirstChild = MainSection->Get(i);
			if(!FirstChild->GetValue(0).compare("TeleportItem"))
			{
				for(unsigned int childs = 0; childs < FirstChild->ChildSize(); childs++)
				{
					IKalDBSection * ChildOfChild = FirstChild->Get(childs);

					if(!ChildOfChild->GetValue(0).compare("Index"))
					{
						string TeleportItemIndexValue = ChildOfChild->GetValue(1);
						teleitem.MainIndex = atoi(TeleportItemIndexValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("Level"))
					{
						string TeleportItemLevelValue = ChildOfChild->GetValue(1);
						teleitem.RequiredLevel = atoi(TeleportItemLevelValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("RequiredItem"))
					{
						string TeleportItemIndexOutValue = ChildOfChild->GetValue(1);
						string TeleportItemAmountOutValue = ChildOfChild->GetValue(2);
						teleitem.RequiredItemIndex = atoi(TeleportItemIndexOutValue.c_str());
						teleitem.RequiredItemAmount = atoi(TeleportItemAmountOutValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("Coordinates"))
					{
						string TeleportItemMapValue = ChildOfChild->GetValue(1);
						string TeleportItemXValue = ChildOfChild->GetValue(2);
						string TeleportItemYValue = ChildOfChild->GetValue(3);
						teleitem.Map = atoi(TeleportItemMapValue.c_str());
						teleitem.X = atoi(TeleportItemXValue.c_str());
						teleitem.Y = atoi(TeleportItemYValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("AssasinMessage"))
					{
						string TeleportItemAssasinMessageValue = ChildOfChild->GetValue(1);
						teleitem.AssasinMessage = Server.string_to_char(TeleportItemAssasinMessageValue);
					}
					else if(!ChildOfChild->GetValue(0).compare("FailMessage"))
					{
						string TeleportItemFailMessageValue = ChildOfChild->GetValue(1);
						teleitem.FailMessage = Server.string_to_char(TeleportItemFailMessageValue);
					}
					else if(!ChildOfChild->GetValue(0).compare("DeleteReqiredItem"))
					{
						string DeleteReqiredItemValue = ChildOfChild->GetValue(1);
						teleitem.DeleteReqiredItem = Server.string_to_char(DeleteReqiredItemValue);
					}
				}
				TeleportItem.push_back(teleitem);
			}
			else if(!FirstChild->GetValue(0).compare("SpawnTimer"))
			{

				for(unsigned int childs = 0; childs < FirstChild->ChildSize(); childs++)
				{
					IKalDBSection * ChildOfChild = FirstChild->Get(childs);

					if(!ChildOfChild->GetValue(0).compare("Monster"))
					{
						string MonsterIndexValue = ChildOfChild->GetValue(1);
						string MonsterAmountValue = ChildOfChild->GetValue(2);
						spawntimer.MonsterIndex = atoi(MonsterIndexValue.c_str());
						spawntimer.MonsterAmount = atoi(MonsterAmountValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("Coordinates"))
					{
						string SpawnTimerMapValue = ChildOfChild->GetValue(1);
						string SpawnTimerXValue = ChildOfChild->GetValue(2);
						string SpawnTimerYValue = ChildOfChild->GetValue(3);
						spawntimer.Map = atoi(SpawnTimerMapValue.c_str());
						spawntimer.X = atoi(SpawnTimerXValue.c_str());
						spawntimer.Y = atoi(SpawnTimerYValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("Time"))
					{
						string SpawnTimerHourValue = ChildOfChild->GetValue(1);
						string SpawnTimerMinValue = ChildOfChild->GetValue(2);
						string SpawnTimerSecValue = ChildOfChild->GetValue(3);
						spawntimer.Hour = atoi(SpawnTimerHourValue.c_str());
						spawntimer.Min = atoi(SpawnTimerMinValue.c_str());
						spawntimer.Sec = atoi(SpawnTimerSecValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("Day"))
					{
						string SpawnTimerDayValue = ChildOfChild->GetValue(1);
						spawntimer.Day = atoi(SpawnTimerDayValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("Notice"))
					{
						string SpawnTimerNoticeValue = ChildOfChild->GetValue(1);
						spawntimer.Notice = Server.string_to_char(SpawnTimerNoticeValue);
					}
				}
				SpawnTimer.push_back(spawntimer);
			}
			else if(!FirstChild->GetValue(0).compare("GoldenPot"))
			{
				for(unsigned int childs = 0; childs < FirstChild->ChildSize(); childs++)
				{
					IKalDBSection * ChildOfChild = FirstChild->Get(childs);

					if(!ChildOfChild->GetValue(0).compare("Index"))
					{
						std::string MainItemIndexValue = ChildOfChild->GetValue(1);
						goldenpot.Index = atoi(MainItemIndexValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("In1"))
					{
						std::string RandomItem1Value = ChildOfChild->GetValue(1);
						std::string RandomPrefix1Value = ChildOfChild->GetValue(2);
						std::string RandomAmount1Value = ChildOfChild->GetValue(3);
						goldenpot.InIndex1 = atoi(RandomItem1Value.c_str());
						goldenpot.InPrefix1 = atoi(RandomPrefix1Value.c_str());
						goldenpot.InAmount1 = atoi(RandomAmount1Value.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("In2"))
					{
						std::string RandomItem2Value = ChildOfChild->GetValue(1);
						std::string RandomPrefix2Value = ChildOfChild->GetValue(2);
						std::string RandomAmount2Value = ChildOfChild->GetValue(3);
						goldenpot.InIndex2 = atoi(RandomItem2Value.c_str());
						goldenpot.InPrefix2 = atoi(RandomPrefix2Value.c_str());
						goldenpot.InAmount2 = atoi(RandomAmount2Value.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("In3"))
					{
						std::string RandomItem3Value = ChildOfChild->GetValue(1);
						std::string RandomPrefix3Value = ChildOfChild->GetValue(2);
						std::string RandomAmount3Value = ChildOfChild->GetValue(3);
						goldenpot.InIndex3 = atoi(RandomItem3Value.c_str());
						goldenpot.InPrefix3 = atoi(RandomPrefix3Value.c_str());
						goldenpot.InAmount3 = atoi(RandomAmount3Value.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("In4"))
					{
						std::string RandomItem4Value = ChildOfChild->GetValue(1);
						std::string RandomPrefix4Value = ChildOfChild->GetValue(2);
						std::string RandomAmount4Value = ChildOfChild->GetValue(3);
						goldenpot.InIndex4 = atoi(RandomItem4Value.c_str());
						goldenpot.InPrefix4 = atoi(RandomPrefix4Value.c_str());
						goldenpot.InAmount4 = atoi(RandomAmount4Value.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("In5"))
					{
						std::string RandomItem5Value = ChildOfChild->GetValue(1);
						std::string RandomPrefix5Value = ChildOfChild->GetValue(2);
						std::string RandomAmount5Value = ChildOfChild->GetValue(3);
						goldenpot.InIndex5 = atoi(RandomItem5Value.c_str());
						goldenpot.InPrefix5 = atoi(RandomPrefix5Value.c_str());
						goldenpot.InAmount5 = atoi(RandomAmount5Value.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("In6"))
					{
						std::string RandomItem6Value = ChildOfChild->GetValue(1);
						std::string RandomPrefix6Value = ChildOfChild->GetValue(2);
						std::string RandomAmount6Value = ChildOfChild->GetValue(3);

						goldenpot.InIndex6 = atoi(RandomItem6Value.c_str());
						goldenpot.InPrefix6 = atoi(RandomPrefix6Value.c_str());
						goldenpot.InAmount6 = atoi(RandomAmount6Value.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("SuccesMessage"))
					{
						std::string SuccesMessageValue = ChildOfChild->GetValue(1);
						goldenpot.SuccsesMessage = Server.string_to_char(SuccesMessageValue);

					}
					else if(!ChildOfChild->GetValue(0).compare("FailMessage"))
					{
						std::string FailMessageValue = ChildOfChild->GetValue(1);
						goldenpot.FailMessage = Server.string_to_char(FailMessageValue);

					}
					else if(!ChildOfChild->GetValue(0).compare("Bound"))
					{
						std::string BoundValue = ChildOfChild->GetValue(1);
						goldenpot.Bound = BoundValue;
					}
					else if(!ChildOfChild->GetValue(0).compare("FailChance"))
					{
						std::string FailChanceValue = ChildOfChild->GetValue(1);
						goldenpot.FailChance = FailChanceValue;
					}
				}
				GoldenPot.push_back(goldenpot);
			}
			else if(!FirstChild->GetValue(0).compare("LunaS"))
			{
				for(unsigned int childs = 0; childs < FirstChild->ChildSize(); childs++)
				{
					IKalDBSection * ChildOfChild = FirstChild->Get(childs);

					if(!ChildOfChild->GetValue(0).compare("TeleportItem"))
					{
						std::string TeleportItemOptValue = ChildOfChild->GetValue(1);
						lunas.TeleportItemOpt = TeleportItemOptValue;
					}
					else if(!ChildOfChild->GetValue(0).compare("SpawnTimer"))
					{
						std::string SpawnTimerOptValue = ChildOfChild->GetValue(1);
						lunas.SpawnTimerOpt = SpawnTimerOptValue;
					}
					else if(!ChildOfChild->GetValue(0).compare("GoldenPot"))
					{
						std::string GoldenPotOptValue = ChildOfChild->GetValue(1);
						lunas.GoldenPotOpt = GoldenPotOptValue;
					}
					else if(!ChildOfChild->GetValue(0).compare("CastleWar"))
					{
						std::string CastleWarOptValue = ChildOfChild->GetValue(1);
						lunas.SpawnTimerOpt = CastleWarOptValue;
					}
					else if(!ChildOfChild->GetValue(0).compare("SpecialityAccs"))
					{
						std::string SpecialityAccsOptValue = ChildOfChild->GetValue(1);
						lunas.SpecialityAccsOpt = SpecialityAccsOptValue;
					}
					else if(!ChildOfChild->GetValue(0).compare("GuildTeleportItem"))
					{
						std::string GuildTeleportItemOptValue = ChildOfChild->GetValue(1);
						lunas.GuildTeleportItemOpt = GuildTeleportItemOptValue;
					}
				}
				LunaS.push_back(lunas);
			}
			else if(!FirstChild->GetValue(0).compare("TeleportCommand"))
			{
				for(unsigned int childs = 0; childs < FirstChild->ChildSize(); childs++)
				{
					IKalDBSection * ChildOfChild = FirstChild->Get(childs);
					if(!ChildOfChild->GetValue(0).compare("RequiredLevel"))
					{
						std::string RequiredLevelValue = ChildOfChild->GetValue(1);
						telecommand.RequiredLevel = atoi(RequiredLevelValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("Command"))
					{
						std::string TeleportCommandValue = ChildOfChild->GetValue(1);
						telecommand.Command = TeleportCommandValue;
					}
					else if (!ChildOfChild->GetValue(0).compare("RequiredItem"))
					{
						std::string RequiredItemIndexValue = ChildOfChild->GetValue(1);
						std::string RequiredItemAmountValue = ChildOfChild->GetValue(2);
						telecommand.RequiredItemIndex = atoi(RequiredItemIndexValue.c_str());
						telecommand.RequiredItemAmount = atoi(RequiredItemAmountValue.c_str());
					}
					else if (!ChildOfChild->GetValue(0).compare("DeleteReqiredItem"))
					{
						std::string DeleteReqiredItemValue = ChildOfChild->GetValue(1);
						telecommand.DeleteRequiredItem = DeleteReqiredItemValue;
					}
					else if(!ChildOfChild->GetValue(0).compare("Coordinates"))
					{
						string TeleportCommandMapValue = ChildOfChild->GetValue(1);
						string TeleportCommandXValue = ChildOfChild->GetValue(2);
						string TeleportCommandYValue = ChildOfChild->GetValue(3);
						telecommand.Map = atoi(TeleportCommandMapValue.c_str());
						telecommand.X = atoi(TeleportCommandXValue.c_str());
						telecommand.Y = atoi(TeleportCommandYValue.c_str());
					}
					else if (!ChildOfChild->GetValue(0).compare("Geon"))
					{
						std::string GeonValue = ChildOfChild->GetValue(1);
						telecommand.Geon = atoi(GeonValue.c_str());
					}
					else if(!ChildOfChild->GetValue(0).compare("Message"))
					{
						string TeleportCommandMessageValue = ChildOfChild->GetValue(1);
						telecommand.Message = Server.string_to_char(TeleportCommandMessageValue);
					}
					else if(!ChildOfChild->GetValue(0).compare("AssasinMessage"))
					{
						string TeleportCommandAssasinMessageValue = ChildOfChild->GetValue(1);
						telecommand.AssasinMessage = Server.string_to_char(TeleportCommandAssasinMessageValue);
					}
					else if(!ChildOfChild->GetValue(0).compare("RequiredItemMessage"))
					{
						string TeleportCommandRequiredItemMessageValue = ChildOfChild->GetValue(1);
						telecommand.RequiredItemMessage = Server.string_to_char(TeleportCommandRequiredItemMessageValue);
					}
				}
				TeleportCommand.push_back(telecommand);
			}
		}
	}
	delete Config;
}
