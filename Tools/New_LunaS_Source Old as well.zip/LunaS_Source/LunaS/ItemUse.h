#ifndef __ITEMUSE_H
#define __ITEMUSE_H
#undef UNICODE
#include "stdafx.h"
#include <KServer.h>
#include <KPlayer.h>
#include <KItem.h>
#include "Config.h"
#include <Memory.h>

#pragma comment(lib, "detours.lib")
#include <detours.h> 

class ItemUse{
	public:
		ItemUse();
		virtual ~ItemUse();
		void Load();
		void Restore();
	private:
};

namespace HookedItemUse
{
	signed int __fastcall UseItem(void *ItemPointer, void *_edx,  int PlayerPointer);
}

#endif