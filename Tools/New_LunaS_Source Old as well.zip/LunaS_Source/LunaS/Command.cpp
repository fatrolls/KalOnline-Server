#include "stdafx.h"
#include "Command.h"


void LunaCommand::Speed()
{
	if(this->command->beginWith("/speed") && this->player->isSupporter())
	{
		int speedvalue = this->command->GetIntValue(1);
		if(speedvalue > 1000){this->player->PlayerMessage("LunaS","#Max Speed value is 1000"); speedvalue = 1000;}
		else if(speedvalue < -2000){this->player->PlayerMessage("LunaS","#Min Speed value is -2000"); speedvalue = -2000;}
		this->player->Buff(12, 3600, speedvalue);
	}
}


void LunaCommand::Coords()
{
	if(this->command->beginWith("/coords"))
	{
		int X = this->player->GetX();
		int Y = this->player->GetY();
		int Z = this->player->GetZ();
		int Map = this->player->GetMap();
		char Coords[100];
		sprintf_s(Coords, "X:[%i], Y:[%i], Z:[%i], Map:[%i]",X,Y,Z,Map);
		this->player->PlayerMessage("LunaS", Coords);
	}
}

void LunaCommand::ReloadConfig()
{
	if(this->command->beginWith("/reloadcfg") && this->player->isAdmin())
	{
		Config config;
		config.ReadConfig();
	}
}

void LunaCommand::Teleport()
{
	int PlayerLevel = this->player->GetLevel();
	for(TeleportCommandIt = TeleportCommand.begin(); TeleportCommandIt != TeleportCommand.end(); TeleportCommandIt++)
	{
		if(this->command->beginWith(TeleportCommandIt->Command))
		{
			if(!this->player->isGstate(ASSASSIN))
			{
				if(TeleportCommandIt->RequiredItemIndex == 0 && PlayerLevel >= TeleportCommandIt->RequiredLevel)
				{
					if(TeleportCommandIt->Geon == 0)
					{
						this->player->Teleport(TeleportCommandIt->Map, TeleportCommandIt->X, TeleportCommandIt->Y);
						this->player->Notice(TeleportCommandIt->Message);
					}
					else if(TeleportCommandIt->Geon != 0)
					{
						if(this->player->FindItem(31, TeleportCommandIt->Geon))
						{
							this->player->Teleport(TeleportCommandIt->Map, TeleportCommandIt->X, TeleportCommandIt->Y);
							this->player->Notice(TeleportCommandIt->Message);
							this->player->RemoveItem(31, TeleportCommandIt->Geon);
						}
						else
						{
							this->player->Notice("You don't have enough geon.");
						}
					}
				}
				else if(TeleportCommandIt->RequiredItemIndex > 0 && PlayerLevel >= TeleportCommandIt->RequiredLevel)
				{
					if(this->player->FindItem(TeleportCommandIt->RequiredItemIndex, TeleportCommandIt->RequiredItemAmount))
					{
						if(TeleportCommandIt->Geon == 0)
						{
							this->player->Teleport(TeleportCommandIt->Map, TeleportCommandIt->X, TeleportCommandIt->Y);
							this->player->Notice(TeleportCommandIt->Message);
								if(TeleportCommandIt->DeleteRequiredItem == "true")
									this->player->RemoveItem(TeleportCommandIt->RequiredItemIndex, TeleportCommandIt->RequiredItemAmount);
						}
						else if(TeleportCommandIt->Geon != 0)
						{
							if(this->player->FindItem(31, TeleportCommandIt->Geon))
							{
								this->player->Teleport(TeleportCommandIt->Map, TeleportCommandIt->X, TeleportCommandIt->Y);
								this->player->Notice(TeleportCommandIt->Message);
								this->player->RemoveItem(31, TeleportCommandIt->Geon);
								if(TeleportCommandIt->DeleteRequiredItem == "true")
									this->player->RemoveItem(TeleportCommandIt->RequiredItemIndex, TeleportCommandIt->RequiredItemAmount);
							}
							else
							{
								this->player->Notice("You don't have enough geon.");
							}
						}
					}
					else if(!this->player->FindItem(TeleportCommandIt->RequiredItemIndex, TeleportCommandIt->RequiredItemAmount))
					{
						this->player->Notice(TeleportCommandIt->RequiredItemMessage);
					}
				}
			}
			else if(this->player->isGstate(ASSASSIN))
			{
				this->player->Notice(TeleportCommandIt->AssasinMessage);
			}
		}
	}
}

void LunaCommand::BuffAll()
{
	if(this->command->beginWith("/BuffAll") && this->player->isAdmin())
	{
		int BuffID = this->command->GetIntValue(1);
		int BuffCD = this->command->GetIntValue(2);
		int BuffIC = this->command->GetIntValue(3);

		if(BuffID <= 0){this->player->PlayerMessage("LunaS_Buff","Set a Buff ID.");}
		else if(BuffCD <= 0){this->player->PlayerMessage("LunaS_Buff","Set a Buff Cooldown value.");}
		else if(BuffIC <=0){this->player->PlayerMessage("LunaS_Buff","Set a Buff Stat Increase value.");}

		else if(BuffID > 0 && BuffCD > 0 && BuffIC > 0){
			ENTER_CRIT
			GET_PLAYER_LIST{
				KPlayer Target(PLAYER_POINTER);
				Target.Buff(BuffID,BuffCD,BuffIC);
			}
			LEAVE_CRIT
		}
	}
}
LunaCommand::~LunaCommand()
{
};