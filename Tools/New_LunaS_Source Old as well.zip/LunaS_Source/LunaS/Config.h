
#ifndef __CONFIG_H
#define __CONFIG_H
#undef UNICODE
#pragma comment(lib, "KosaLib.lib")
#include "stdafx.h"
#include <vector>

#include <KConfig.h>
#include <KServer.h>
#include "ItemUse.h"


using namespace std;



class Config
{
public:
	void ReadConfig();
};

class LunaS_class
{
public:
	string TeleportItemOpt;
	string SpawnTimerOpt;
	string GoldenPotOpt;
	string CastleWarOpt;
	string SpecialityAccsOpt;
	string GuildTeleportItemOpt;
};

class TeleportItem_class
{
public:
	int MainIndex;
	int RequiredLevel;
	int RequiredItemIndex;
	int RequiredItemAmount;
	int Map;
	int X;
	int Y;
	char* AssasinMessage;
	char* FailMessage;
	string DeleteReqiredItem;
};



class SpawnTimer_class
{
public:
	int MonsterIndex;
	int MonsterAmount;
	int Map;
	int X;
	int Y;
	int Hour;
	int Min;
	int Sec;
	int Day;

	char* Notice;
};

class GoldenPot_class
{
public:
	int Index;
	int InIndex1;
	int InPrefix1;
	int InAmount1;

	int InIndex2;
	int InPrefix2;
	int InAmount2;

	int InIndex3;
	int InPrefix3;
	int InAmount3;

	int InIndex4;
	int InPrefix4;
	int InAmount4;

	int InIndex5;
	int InPrefix5;
	int InAmount5;

	int InIndex6;
	int InPrefix6;
	int InAmount6;

	char* SuccsesMessage;
	char* FailMessage;
	string Bound;
	string FailChance;
};

class TeleportCommand_class
{
public:
	int RequiredLevel;
	string Command;
	int RequiredItemIndex;
	int RequiredItemAmount;
	string DeleteRequiredItem;
	int Map;
	int X;
	int Y;
	int Geon;
	char* Message;
	char* AssasinMessage;
	char* RequiredItemMessage;
};

#pragma region Vectors
extern vector<TeleportItem_class> TeleportItem;
extern vector<TeleportItem_class>::iterator TeleitemIt;

extern vector<SpawnTimer_class> SpawnTimer;
extern vector<SpawnTimer_class>::iterator SpawnTimerIt;

extern vector<GoldenPot_class> GoldenPot;
extern vector<GoldenPot_class>::iterator GoldenPotIt;

extern vector<TeleportCommand_class> TeleportCommand;
extern vector<TeleportCommand_class>::iterator TeleportCommandIt;

#pragma endregion


#endif