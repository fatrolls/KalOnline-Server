#ifndef __COMMAND_H
#define __COMMAND_H
#undef UNICODE
#pragma comment(lib, "KosaLib.lib")
#include "stdafx.h"

#include <KServer.h>
#include <KPlayer.h>
#include <KCommand.h>

#include "Config.h"

using namespace std;
class LunaCommand
{
private:
	KPlayer *player;
	KCommand *command;
	int *playerp;

public:
	LunaCommand(int *playerptr, char *comm)
	{
		this->player = new KPlayer(playerptr);
		this->playerp = playerptr;
		this->command = new KCommand(comm);
	} 

	void ReloadConfig();
	void Coords();
	void Teleport();
	void Speed();
	void BuffAll();

	virtual ~LunaCommand();
};
#endif