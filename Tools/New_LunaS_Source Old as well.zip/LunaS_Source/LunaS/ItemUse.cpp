#include "stdafx.h"
#include "ItemUse.h"
using namespace Server;

ItemUse::ItemUse()
{
}

ItemUse::~ItemUse()
{
}

void ItemUse::Load()
{
	DetourTransactionBegin();
	DetourUpdateThread(GetCurrentThread());
	DetourAttach(&(PVOID&)Server::CItem::UseItem, HookedItemUse::UseItem);
	DetourTransactionCommit();
}
void ItemUse::Restore()
{
	DetourTransactionBegin();
	DetourUpdateThread(GetCurrentThread());
	DetourDetach(&(PVOID&)Server::CItem::UseItem, HookedItemUse::UseItem);
	DetourTransactionCommit();
}



signed int __fastcall HookedItemUse::UseItem(void *ItemPointer, void *_edx,  int PlayerPointer)
 {
		KPlayer Player((int*)PlayerPointer);
		KItem Item((int*)ItemPointer, (int*)PlayerPointer);
		KServer Server;
		int result = CItem::UseItem(ItemPointer, PlayerPointer);

		int ItemIndex = Item.GetIndex();
		int PlayerGstate = Player.GetGstate();
		int PlayerLevel = Player.GetLevel();
		int PlayerGID = Player.GetGID();
		int PlayerX = Player.GetX();
		int PlayerY = Player.GetY();
		int PlayerMap = Player.GetMap();

		for ( TeleitemIt = TeleportItem.begin(); TeleitemIt != TeleportItem.end(); TeleitemIt++ )
		{
			if(ItemIndex == TeleitemIt->MainIndex)
			{
				if(!Player.isGstate(ASSASSIN))
				{
					if(TeleitemIt->RequiredItemIndex == 0 && PlayerLevel >= TeleitemIt->RequiredLevel)
					{
						if(Player.RemoveItem(TeleitemIt->MainIndex, 1))
						{
							Player.Teleport(TeleitemIt->Map, TeleitemIt->X, TeleitemIt->Y);
						}
					}
					else if(TeleitemIt->RequiredItemIndex > 0 && PlayerLevel >= TeleitemIt->RequiredLevel)
					{
							if(Player.FindItem(TeleitemIt->RequiredItemIndex, TeleitemIt->RequiredItemAmount))
							{
								if(Player.RemoveItem(TeleitemIt->MainIndex, 1))
								{
									if(TeleitemIt->DeleteReqiredItem == "true")
									{
										if(Player.RemoveItem(TeleitemIt->RequiredItemIndex, TeleitemIt->RequiredItemAmount))
										{
											Player.Teleport(TeleitemIt->Map, TeleitemIt->X, TeleitemIt->Y);
										}
									}
									else{Player.Teleport(TeleitemIt->Map, TeleitemIt->X, TeleitemIt->Y);}
								}
							}
							else if(!Player.FindItem(TeleitemIt->RequiredItemIndex, TeleitemIt->RequiredItemAmount))
							{
								Player.Notice(TeleitemIt->FailMessage);
							}
					}
				}
				else if(Player.isGstate(ASSASSIN))
				{
					Player.Notice(TeleitemIt->AssasinMessage);
				}
			}
		}
return result;
}