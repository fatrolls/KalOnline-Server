BLP2toTGA README

Technetium's BLP2 to TGA convertor
--
Instructions:
Drag one or more BLP2 files over the exe to convert them to TGA format.
The newly created TGA files will have the exact same name as the BLP2 file,
but the extension will be changed to ".tga"

Credits:
The BLP2 format was cracked by Technetium with the help of DaishiOfDeath.
Convertor DLL written by Technetium.
BLP2toTGA written by Technetium.

Contact:
Technetium
	AIM: xccmx
	e-mail: compact_trash@msn.com
DaishiOfDeath
	e-mail: daishiofdeath@hotmail.com

