#ifndef __ENGINETOOLS_H
#define __ENGINETOOLS_H
#include <Windows.h>
#include <vector>
#include <string>

#pragma warning(disable: 4996)
#pragma comment(lib, "libeay32.lib")

#include <iostream>  
#include <sstream>  
#include <iomanip>  
#include <stdio.h>  
#include <openssl/sha.h>  

using namespace std;

class ETools
{
	public:
		
		enum _INSTRUCTIONS
		{
			_I_NOP = 0x90,
			_I_CALL = 0xe8,
			_I_JMP = 0xe9,
			_I_JMP_SHORT = 0xeb,
			_I_JE_SHORT = 0x74,
			_I_JNZ_SHORT = 0x75,
			//_I_PUSH = 0x68,
		};

		virtual void* MemcpyEx(void *Dest, void* Source, size_t Size);
		virtual void* MemcpyExS(void *Dest, void* Source, size_t Size);
		virtual void* MemcpyExD(void *Dest, void* Source, size_t Size);
		virtual void FillMemoryEx(void* Destination, unsigned char Fill, size_t Size);
		virtual void FillMemoryEx(unsigned long Destination, unsigned char Fill, size_t Size);
		virtual void SetMemoryEx(void* Destination, const char* Data, size_t Size);
		virtual void SetMemoryEx(unsigned long Destination, const char* Data, size_t Size);
		virtual unsigned long Intercept(unsigned char instruction, void* source, void* destination, size_t length);

		vector<string> Explode(string String, string Separator);

		//void DetourFunc(BYTE* src, BYTE* prolog, const int len = 4);

		void* DetourFunction(BYTE *src, const BYTE *dst, const int len);
		bool bDataCompare(const BYTE* pData, const BYTE* bMask, const char* szMask);
		DWORD dwFindPattern(DWORD dwAddress, DWORD dwLen, BYTE *bMask, char * szMask);
		unsigned long GetCaller(size_t Depth);


		string sha256(const std::string str);
		void GetSha256_string_hash(unsigned char hash[SHA256_DIGEST_LENGTH], char outputBuffer[65]);
		int GetSha256_File_Hash(char* path, char output[65]);
		string GetHWID();

};

#endif