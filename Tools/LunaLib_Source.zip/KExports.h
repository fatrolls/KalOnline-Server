#ifndef __EXPORTS_H
#define __EXPORTS_H
#include <Windows.h>
#include <string>

class SExports
{
	public:
		static FARPROC p[15*4];
		static unsigned long _p;
		virtual void Initialize();
		HINSTANCE hL;
	private:
		
		
};


class EngineExports
{
	public:
		static FARPROC P[15*4];
		static unsigned long _P;
		virtual void Initialize();
		HINSTANCE _hL;
	private:
		

};

#endif