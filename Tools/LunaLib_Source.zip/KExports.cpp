#include "KExports.h"


FARPROC SExports::p[];
unsigned long SExports::_p;

void SExports::Initialize(){
	wchar_t *_system = new wchar_t[MAX_PATH];
	GetSystemDirectoryW(_system, MAX_PATH);
	std::wstring _syspath = _system;
	delete _system;
	_syspath += L"\\gdi32.dll";
	this->hL = LoadLibraryW(_syspath.c_str());

	p[0] = GetProcAddress(this->hL, "SetTextColor");
	p[1] = GetProcAddress(this->hL, "TextOutA");
	p[2] = GetProcAddress(this->hL, "GetTextMetricsA");
}
extern "C" __declspec(naked) void __stdcall __E__0__() { SExports::_p = (unsigned long)SExports::p[0]; __asm jmp SExports::_p }
extern "C" __declspec(naked) void __stdcall __E__1__() { SExports::_p = (unsigned long)SExports::p[1]; __asm jmp SExports::_p }
extern "C" __declspec(naked) void __stdcall __E__2__() { SExports::_p = (unsigned long)SExports::p[2]; __asm jmp SExports::_p }






FARPROC EngineExports::P[];
unsigned long EngineExports::_P;

void EngineExports::Initialize()
{
	wchar_t *_system = new wchar_t[MAX_PATH];
	GetSystemDirectoryW(_system, MAX_PATH);
	std::wstring _syspath = _system;
	delete _system;
	_syspath += L"\\version.dll";
	this->_hL = LoadLibraryW(_syspath.c_str());

	P[0] = GetProcAddress(this->_hL, "GetFileVersionInfoA");
	P[1] = GetProcAddress(this->_hL, "GetFileVersionInfoByHandle");
	P[2] = GetProcAddress(this->_hL, "GetFileVersionInfoExW");
	P[3] = GetProcAddress(this->_hL, "GetFileVersionInfoSizeA");
	P[4] = GetProcAddress(this->_hL, "GetFileVersionInfoExW");
	P[5] = GetProcAddress(this->_hL, "GetFileVersionInfoSizeW");
	P[6] = GetProcAddress(this->_hL, "GetFileVersionInfoW");
	P[7] = GetProcAddress(this->_hL, "VerFindFileA");
	P[8] = GetProcAddress(this->_hL, "VerFindFileW");
	P[9] = GetProcAddress(this->_hL, "VerInstallFileA");
	P[10] = GetProcAddress(this->_hL, "VerInstallFileW");
	P[11] = GetProcAddress(this->_hL, "VerLanguageNameA");
	P[12] = GetProcAddress(this->_hL, "VerLanguageNameW");
	P[13] = GetProcAddress(this->_hL, "VerQueryValueA");
	P[14] = GetProcAddress(this->_hL, "VerQueryValueW");
}
extern "C" __declspec(naked) void __stdcall ___E__0__() { EngineExports::_P = (unsigned long)EngineExports::P[0]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__1__() { EngineExports::_P = (unsigned long)EngineExports::P[1]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__2__() { EngineExports::_P = (unsigned long)EngineExports::P[2]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__3__() { EngineExports::_P = (unsigned long)EngineExports::P[3]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__4__() { EngineExports::_P = (unsigned long)EngineExports::P[4]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__5__() { EngineExports::_P = (unsigned long)EngineExports::P[5]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__6__() { EngineExports::_P = (unsigned long)EngineExports::P[6]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__7__() { EngineExports::_P = (unsigned long)EngineExports::P[7]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__8__() { EngineExports::_P = (unsigned long)EngineExports::P[8]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__9__() { EngineExports::_P = (unsigned long)EngineExports::P[9]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__10__() { EngineExports::_P = (unsigned long)EngineExports::P[10]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__11__() { EngineExports::_P = (unsigned long)EngineExports::P[11]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__12__() { EngineExports::_P = (unsigned long)EngineExports::P[12]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__13__() { EngineExports::_P = (unsigned long)EngineExports::P[13]; __asm jmp EngineExports::_P }
extern "C" __declspec(naked) void __stdcall ___E__14__() { EngineExports::_P = (unsigned long)EngineExports::P[14]; __asm jmp EngineExports::_P }


