#include "KCommand.h"

void KCommand::SetCommStr(string x){
	this->command = (x);
}


bool KCommand::beginWith(std::string begin)
{
    if (this->command.size() >= begin.size())
    {
        if (this->command.substr(0, begin.size()) == begin)
            return true;
    }
    return false;
}



std::string KCommand::GetStrValue(unsigned int offset){
	string ret = "";
	strvalues.clear();
	string tempcommand = this->command;
	string whitespace = " ";

	if(tempcommand.find(whitespace)){
		while(tempcommand.find(whitespace) != string::npos){
			strvalues.push_back(tempcommand.substr(0, tempcommand.find(whitespace)).c_str());
			 tempcommand = tempcommand.substr(tempcommand.find(whitespace) + 1);
		}
		 if(tempcommand.length())
				strvalues.push_back(tempcommand.c_str());

		 if(strvalues.size() >= offset){
			 ret = strvalues[offset];
		 }
		 else{ret = "Empty";}
	}
	else{ret = "Empty";}
	return ret;
}

int KCommand::GetIntValue(unsigned int offset){
	intvalues.clear();
	string tempcommand = this->command;
	string whitespace = " ";

	if(tempcommand.find(whitespace)){
		while(tempcommand.find(whitespace) != string::npos){
			 intvalues.push_back(atoi(tempcommand.substr(0, tempcommand.find(whitespace)).c_str()));
			 tempcommand = tempcommand.substr(tempcommand.find(whitespace) + whitespace.length());
		}
		 if(tempcommand.length())
				intvalues.push_back(atoi(tempcommand.c_str()));

		 return intvalues[offset];
	}
	else{return 0;}
}


string KCommand::GetFullStr(){
	string TempStr = this->command;

	TempStr.erase(0, TempStr.find(' ') + 1);

	return TempStr;
}