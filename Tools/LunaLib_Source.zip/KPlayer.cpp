#include "KPlayer.h"

using namespace Server;
using namespace std;

KPlayer::KPlayer(int* PointerToArray){
	this->SetArray(PointerToArray);
}
KPlayer::~KPlayer(){
	this->SetArray(0);
}

int* KPlayer::GetArray(void){
	return this->PlayerArray;
}
void KPlayer::SetArray(int* PointerToArray){
	this->PlayerArray = PointerToArray;
}



void KPlayer::CIOCriticalSectionEnter(void){
    Server::CIOCriticalSection::Enter((void*)((DWORD)this->PlayerArray + 1020));
}

void KPlayer::CIOCriticalSectionLeave(void){
    Server::CIOCriticalSection::Leave((void*)((DWORD)this->PlayerArray + 1020));
}


bool KPlayer::isGood(){
	return (this->PlayerArray != 0) ? true : false;
}



char* KPlayer::GetName(){
	return (char*)this->PlayerArray + 32;
}

int KPlayer::GetLevel(){
	return this->PlayerArray[15];
}

int KPlayer::GetAdmin(){
	return this->PlayerArray[114];
}

int KPlayer::GetClass(){
	return this->PlayerArray[115];
}

int KPlayer::GetID(){
	return this->PlayerArray[7];
}

int KPlayer::GetPID(){
	return this->PlayerArray[113];
}

int KPlayer::GetUID(){
	return this->PlayerArray[112];
}

int KPlayer::GetType(){
	return this->PlayerArray[6];
}

int KPlayer::GetX(){
	return this->PlayerArray[83];
}

int KPlayer::GetY(){
	return this->PlayerArray[84];
}

int KPlayer::GetZ(){
	return this->PlayerArray[85];
}

int KPlayer::GetMap(){
	return this->PlayerArray[79];
}

bool KPlayer::IsOnMap(int map_){
	if(this->GetMap() == map_) 
		return true;
	else
		return false;
}

bool KPlayer::IsOnTile(int x){
	return CSMap::IsOnTile((int*)this->PlayerArray[80], (int)&this->PlayerArray[83], x) ? true : false;
}

bool KPlayer::IsValidTile(int x){
	return false;
	//return CSMap::IsValidTile((int*)this->PlayerArray[80], (int)&this->PlayerArray[83], x) ? true : false;
}

bool KPlayer::IsKnight(){
	return (this->GetClass() == CClass::Knight) ? true : false;
}

bool KPlayer::IsMage(){
	return (this->GetClass() == CClass::Mage) ? true : false;
}

bool KPlayer::IsArcher(){
	return (this->GetClass() == CClass::Archer) ? true : false;
}

bool KPlayer::IsThief(){
	return (this->GetClass() == CClass::Thief) ? true : false;
}

int KPlayer::GetCurHp(){
	return this->PlayerArray[68];
}
int KPlayer::GetCurMp(){
	return this->PlayerArray[69];
}
int KPlayer::GetMaxHp(){
	return Server::CChar::GetMaxHp(this->PlayerArray);
}
int KPlayer::GetMaxMp(){
	return Server::CChar::GetMaxMp(this->PlayerArray);
}
int KPlayer::GetStr(void){
	return Server::CChar::GetStr(this->PlayerArray);
}
int KPlayer::GetHth(void){
	return Server::CChar::GetHth(this->PlayerArray);
}
int KPlayer::GetAgi(void){
	return Server::CChar::GetDex(this->PlayerArray);
}
int KPlayer::GetInt(void){
	return Server::CChar::GetInt(this->PlayerArray);
}
int KPlayer::GetWis(void){
	return Server::CChar::GetWis(this->PlayerArray);
}
int KPlayer::GetMaxPhyAtk(void){
	return Server::CChar::GetMaxAttack(this->PlayerArray);
}
int KPlayer::GetMinPhyAtk(void){
	return Server::CChar::GetMinAttack(this->PlayerArray);
}
int KPlayer::GetMaxMagAtk(void){
	return Server::CChar::GetMaxMagic(this->PlayerArray);
}
int KPlayer::GetMinMagAtk(void){
	return Server::CChar::GetMinMagic(this->PlayerArray);
}
int KPlayer::GetResist(unsigned char Type){
	return Server::CChar::GetResist(this->PlayerArray,Type);
}
int KPlayer::GetHit(void){
	return Server::CChar::GetHit(this->PlayerArray);
}
int KPlayer::GetDodge(void){
	return Server::CChar::GetDodge(this->PlayerArray);
}
int KPlayer::GetDefense(void){
	return Server::CChar::GetDefense(this->PlayerArray);
}
int KPlayer::GetFinalDefense(int arg){
	return Server::CChar::GetFinalDefense(this->PlayerArray,arg);
}
int KPlayer::GetAttackSpeed(void){
	return Server::CChar::GetASpeed(this->PlayerArray);
}
int KPlayer::GetAbsorb(void){
	return Server::CChar::GetAbsorb(this->PlayerArray);
}
int KPlayer::GetAttack(void){
	return Server::CChar::GetAttack(this->PlayerArray);
}
int KPlayer::GetMagic(void){
	return Server::CChar::GetMagic(this->PlayerArray);
}

int KPlayer::GetStatPoints(){
	return this->PlayerArray[136];
}

int KPlayer::GetSkillPoints(){
	return this->PlayerArray[137];
}

int KPlayer::GetSpeciality(void){
	return this->PlayerArray[116];
}

int KPlayer::GetContribute(void){
	return this->PlayerArray[117];
}

int KPlayer::GetGRole(void){
    return this->PlayerArray[134];
}

int KPlayer::GetKilled(){
   return this->PlayerArray[138];
}

int KPlayer::GetRage(){
    return this->PlayerArray[145];
}

int KPlayer::GetGState(){
    return this->PlayerArray[70];
}

bool KPlayer::isNormal(){
	return (this->GetAdmin() == ADMIN_TYPE::USER) ? true : false;
 }

bool KPlayer::isSupporter(){
	return (this->GetAdmin() >= ADMIN_TYPE::SUPPORTER) ? true : false;
}

bool KPlayer::isGM(){
	return (this->GetAdmin() >= ADMIN_TYPE::GM) ? true : false;
}

bool KPlayer::isAdmin(){
	return (this->GetAdmin() >= ADMIN_TYPE::ADMIN) ? true : false; 
}

void KPlayer::Teleport(bool AssassinSave, int map, int x, int y, int z){
	COORDINATES *Point = (new COORDINATES);
	int nMap = map;
	Point->x = (x);
	Point->y = (y);

	if(AssassinSave){
		if(this->IsGstate(GSTATE_TYPE::ASSASSIN)){
			this->ChatMessage("Server", "You can't Teleport in Assassin mode!");
		}
		else{
			CPlayer::Teleport((int)this->PlayerArray, nMap, Point, z, 0);
		}
	}
	else{
		CPlayer::Teleport((int)this->PlayerArray, nMap, Point, z, 0);
	}
	delete Point;
}

int KPlayer::UpdateProperty(int Type, int Amount){
	return CPlayer::UpdateProperty(this->PlayerArray, Type, 1, Amount);
}
int KPlayer::UpdatePrtyPer(int type, int DeIn, int Amount){
	return CPlayer::UpdatePrtyPer(this->PlayerArray, type, DeIn, Amount, 0);
}


void KPlayer::ChatMessage(char* Name, char* Text, ...){
	static char TBuffer[2048];
	va_list Args;
	va_start(Args, Text);
	vsprintf_s(TBuffer, Text, Args);
	va_end(Args);
	CPlayer::Write(this->PlayerArray, 0x3c, "ss", Name, TBuffer);
}

void KPlayer::PrivateNotice(char* Text, ...){
	static char TBuffer[2048];
	va_list Args;
	va_start(Args, Text);
	vsprintf_s(TBuffer, Text, Args);
	va_end(Args);
	CPlayer::Write(this->PlayerArray, 0xF, "s", TBuffer);
}


void KPlayer::Notice(bool Private, bool ShowName, int Color, const char* Text, ...){
	static char TBuffer[2048];
	string fText;
	string CharName = (string)this->GetName();

	va_list Args;
	va_start(Args, Text);
	vsprintf_s(TBuffer, Text, Args);
	va_end(Args);

	string nContent(TBuffer);

	if (ShowName){ fText = ("[" + CharName + "] " + nContent); }
	else{ fText = (nContent); }
	
	if (Private){ CChar::Write(this->PlayerArray, MyPHeader::ADD_NOTICE_STRING, "sd", fText.c_str(), Color); }
	else{ CPlayer::WriteAll(MyPHeader::ADD_NOTICE_STRING, "sd", fText.c_str(), Color); }
}

void KPlayer::ScreenInfo(bool Private, bool ShowName, int Type, const char* Text, ...){
	static char TBuffer[2048];
	string fText;
	string CharName = (string)this->GetName();

	va_list Args;
	va_start(Args, Text);
	vsprintf_s(TBuffer, Text, Args);
	va_end(Args);

	string nContent(TBuffer);

	if (ShowName){ fText = ("[" + CharName + "] " + nContent); }
	else{ fText = (nContent); }

	if (Private){ CChar::Write(this->PlayerArray, MyPHeader::SET_SCREEN_INFO, "sd", fText.c_str(), Type); }
	else{ CPlayer::WriteAll(MyPHeader::SET_SCREEN_INFO, "sd", fText.c_str(), Type); }
}

void KPlayer::InfoMessage(int color, char* Text, ...){
	static char TBuffer[2048];
	va_list Args;
	va_start(Args, Text);
	vsprintf_s(TBuffer, Text, Args);
	va_end(Args);
	CChar::Write(this->PlayerArray, MyPHeader::ADD_INFO_MESSAGE, "sdd", TBuffer, color, 1);
}

bool KPlayer::IsGstate(unsigned long State){
	return (CChar::IsGState(this->PlayerArray, State)) ? true : false;
}


int KPlayer::InsertItem(int Index, int Prefix, int Amount, bool Bound){
	KServer Server;
	int result = (0);
	unsigned int NewItem = (0);

	if(!Bound){result = (CItem::CreateItem(Index, Prefix, Amount, -1));}
	else{result = (CItem::CreateOwnItem(Index, Prefix, Amount, -1));}
	NewItem = (result);

	if (result && this->isGood()){
		CIOObject::AddRef(result);
		if (CPlayer::InsertItem((int)this->PlayerArray, 21, NewItem) != 1 ){
			Server.ConsoleWrite(TextColor::ORANGE_RED, "KPlayer::InsertItem() Failed to insert item (PID:%d, Name:%s, Index:%d, Amount:%d)", this->GetPID(), this->GetName(), Index, Amount);
			CBase::Delete((void *)NewItem);
		}
		result = CIOObject::Release(NewItem);
	}
	return result;
}

void KPlayer::CancelBuff(int id){
	if(this->isGood()){
		CChar::CancelBuff(this->PlayerArray, id);
	}
}

void KPlayer::Kick(){
	Server::CChar::Write(PlayerArray, 0x2D, "b", 1);
}




void KPlayer::ShowMessageBox(char*Text, int Type, int Action, int Dest1, int Dest2){
	CChar::Write(this->PlayerArray, MyPHeader::MESSAGE_BOX, "sdddd", Text, Type, Action, Dest1, Dest2);
}


void KPlayer::Block(){
	
}




void KPlayer::SetAdmin(int x){
	this->PlayerArray[114] = x;
}



void KPlayer::Levelup(int level, int statpoint, int skillpoint){
	this->UpdateProperty(PROPERTY_TYPE::P_LEVEL, level);
	this->UpdateProperty(PROPERTY_TYPE::P_PUPOINT, statpoint);
	this->UpdateProperty(PROPERTY_TYPE::P_SUPOINT, skillpoint);
	*((unsigned long *)this->PlayerArray + 138) = 0;
	CPlayer::SaveAllProperty((void*)this->PlayerArray, 1);
	Unknown::sub_47FF00((void*)this->PlayerArray, 0);
	CPlayer::MLMPayMoney((void*)this->PlayerArray, 2);
	CPlayer::MLMLevelUp((void*)this->PlayerArray);
}




void KPlayer::InsertBuffIcon(int Time, int Type, int nMsg, int Key){
	if (this->isGood())
	{
		CChar::Write(this->PlayerArray, MyPHeader::INSERT_BUFF, "ddddd", Time, 500, Type, nMsg, Key);
	}
}


void KPlayer::RemoveBuffIcon(int Time, int Type, int nMsg, int Key){
	if (this->isGood())
	{
		CChar::Write(this->PlayerArray, MyPHeader::INSERT_BUFF, "ddddd", Time, 600, Type, nMsg, Key);
	}
}







bool KPlayer::IsinRect(int x1, int y1, int x2, int y2){
	bool ret = false;
	int PlayerX = this->GetX();
	int PlayerY = this->GetY();
	
	if (PlayerX >= x1 && PlayerY >= y1 && PlayerX <= x2 && PlayerY <= y2)
		return true;
	else
		return false;
}


bool KPlayer::IsPetInRange(int PetID, int area)
{
	bool ret = false;
	void* Object = CMonster::FindMonster(PetID);
	auto_ptr<KMonster> Monster(new KMonster((int*)Object));
	if (Object
		&& Monster->GetX() < this->GetX() + area
		&& Monster->GetX() > this->GetX() - area
		&& Monster->GetY() < this->GetY() + area
		&& Monster->GetY() > this->GetY() - area)
	{
		ret = true;
	}
	else
	{
		ret = false;
	}
	return ret;
}

bool KPlayer::RemoveItem(int Index, int Amount){
	if (CPlayer::RemoveItem(this->PlayerArray, 9, Index, Amount))
		return true;
	else
	return false;
}

void KPlayer::ShowScreenOverlay(bool Private, const char* FileName, int Time, int D3DColor, int Type){
	if (Private){
		CChar::Write(this->PlayerArray, MyPHeader::SCREEN_OVERLAY, "sddd", FileName, Time, D3DColor, Type);
	}
	else{
		CPlayer::WriteAll(MyPHeader::SCREEN_OVERLAY, "sddd", FileName, Time, D3DColor, Type);
	}
		
}



bool KPlayer::IsGuildLeader(){
	int* Leaderptr = (int*)CGuild::FindLeaderPlayer((void*)CGuild::FindGuild(CPlayer::GetGuildName(this->PlayerArray)));
	if (Leaderptr == this->PlayerArray)
		return true;
	else
		return false;
}