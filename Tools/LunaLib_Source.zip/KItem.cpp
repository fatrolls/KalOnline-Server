#include "KItem.h"

KItem::KItem(int* offset){
	this->ItemArray = offset;
}
KItem::~KItem(){
}

int* KItem::GetArray(void){
	return this->ItemArray;
}
void KItem::SetArray(int* offset){
	this->ItemArray = offset;
}


int KItem::GetIndex(){
	return ((int*)((int*) this->ItemArray)[10])[16];
}

int KItem::GetPid(){
	return this->ItemArray[32];
}

int KItem::GetID(){
	return this->ItemArray[36];
}

int KItem::GetAttack(){
	return this->ItemArray[25];
}

int KItem::GetMagicAttack(){
	return this->ItemArray[26];
}

int KItem::GetPrefix(){
	return this->ItemArray[11];	
}

int KItem::GetInfo(){
	return this->ItemArray[12];
}

int KItem::GetIID(){
	return this->ItemArray[9];
}

int KItem::GetOTP(){
	return this->ItemArray[28];
}

int KItem::GetEva(){
	return this->ItemArray[29];
}

int KItem::GetDef(){
	return this->ItemArray[27];
}

int KItem::GetEB(){
	return this->ItemArray[31];
}

int KItem::GetAmount(){
	return this->ItemArray[13];
}

int KItem::SetAttack(int x){
	return this->ItemArray[25] = x;
}

int KItem::SetMagicAttack(int x){
	return this->ItemArray[26] = x;
}

int KItem::SetInfo(int x){
	return this->ItemArray[12] = x;
}

int KItem::SetOTP(int x){
	return this->ItemArray[28] = x;
}

int KItem::SetEva(int x){
	return this->ItemArray[29] = x;
}

int KItem::SetDef(int x){
	return this->ItemArray[27] = x;
}
