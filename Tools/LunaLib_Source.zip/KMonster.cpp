#include "KMonster.h"


KMonster::KMonster(int* PointerToArray){
	this->SetArray(PointerToArray);
}
KMonster::~KMonster(){
	this->SetArray(0);
}

int* KMonster::GetArray(void){
	return this->MonsterArray;
}
void KMonster::SetArray(int* PointerToArray){
	this->MonsterArray = (PointerToArray);
}

bool KMonster::Check(){
	return (this->MonsterArray != 0) ? true : false;
}

int KMonster::GetIndex(){
	return ((int*)((int*)this->MonsterArray)[110])[15];
}
//BASE ID
int KMonster::GetBaseID(){
	return this->MonsterArray[7];
}

int KMonster::GetPID(){
	return this->MonsterArray[113];
}

//120 AI????
int KMonster::GetX(){
	return this->MonsterArray[83];
}

int KMonster::GetY(){
	return this->MonsterArray[84];
}

int KMonster::GetDirection(){
	return this->MonsterArray[87];
}

int KMonster::GetCurHp(){
	return this->MonsterArray[68];
}

int KMonster::GetMaxHp(){
	return Server::CChar::GetMaxHp(this->MonsterArray);
}

int KMonster::GetGstate(){
	return this->MonsterArray[70];
}

int KMonster::GetMstate(){
	return this->MonsterArray[72];
}

int KMonster::GetRace(){
	return ((int*)((int*)this->MonsterArray)[110])[16];
}

int KMonster::GetGID(){
	return this->MonsterArray[131];
}

int* KMonster::GetTargetptr(){
	return (int*)this->MonsterArray[116];
}

unsigned int KMonster::GetEndtick()
{
	return this->MonsterArray[117];
}

void KMonster::Lock(){
	Server::CChar::Lock(this->GetArray());
}
void KMonster::Unlock(){
	Server::CChar::Unlock(this->GetArray());
}

void KMonster::AddGstate(unsigned int Gstate){
	Server::CChar::AddGState((void*)this->GetArray(), Gstate);
}

void KMonster::Remove(){
	if (this->GetSummonType() == SummonType::System){
		Server::CChar::WriteInSight(this->GetArray(), 0x49, "db", this->GetBaseID(), 0x34);
		Server::CChar::WriteInSight(this->GetArray(), 0x38, "db", this->GetBaseID(), 7);
		(*(int(__thiscall **)(int*, int))(*(unsigned int *)(unsigned int)this->GetArray() + 188))(this->GetArray(), 0);
		Server::CMonster::OnDelete(this->GetArray());
		Server::CBase::Delete(this->GetArray());
	}
	else{
		Server::CChar::WriteInSight(this->GetArray(), 0x49, "db", this->GetBaseID(), 0x34);
		Server::CChar::WriteInSight(this->GetArray(), 0x38, "db", this->GetBaseID(), 7);
		(*(int(__thiscall **)(int*, int))(*(unsigned int *)(unsigned int)this->GetArray() + 188))(this->GetArray(), 0);
		Server::CMonster::OnDelete(this->GetArray());
		Server::CBase::Delete(this->GetArray());
		//remove from vector
	}
}


bool KMonster::IsSummon()
{
	bool ret = false;
	for (SummonVecIt = SummonVec.begin(); SummonVecIt != SummonVec.end(); SummonVecIt++)
	{
		if (SummonVecIt->MobID == this->GetBaseID())
		{
			ret = true;
			break;
		}
	}
	return ret;
}

unsigned int KMonster::GetSummonTick()
{
	unsigned int ret = 0;
	for (SummonVecIt = SummonVec.begin(); SummonVecIt != SummonVec.end(); SummonVecIt++)
	{
		if (SummonVecIt->MobID == this->GetBaseID())
		{
			ret = SummonVecIt->endtick;
			break;
		}
	}
	return ret;
	//return this->GetEndtick();
}

int* KMonster::GetCasterptr()
{
	int* ret = 0;
	for (SummonVecIt = SummonVec.begin(); SummonVecIt != SummonVec.end(); SummonVecIt++)
	{
		if (SummonVecIt->MobID == this->GetBaseID())
		{
			KServer Server;
			if (SummonVecIt->CasterID != 0){
				ret = Server.GetPlayerptrFromBaseID(SummonVecIt->CasterID);
			}
			break;
		}
	}
	return ret;
}

int KMonster::GetSummonType(){
	int ret = 0;
	for (SummonVecIt = SummonVec.begin(); SummonVecIt != SummonVec.end(); SummonVecIt++)
	{
		if (SummonVecIt->MobID == this->GetBaseID())
		{
			ret = SummonVecIt->Type;
			break;
		}
	}
	return ret;
}




void KMonster::RemoveFromSummonVec() {
	SummonVec.erase(
		std::remove_if(SummonVec.begin(), SummonVec.end(), [&](Summon_Base const & summon) {
		return summon.MobID == this->GetBaseID();
	}),
		SummonVec.end());
}



bool KMonster::IsSummonType(int Summontype){
	bool ret = false;
	if (this->GetSummonType() == Summontype){
		ret = true;
	}
	return ret;
}
