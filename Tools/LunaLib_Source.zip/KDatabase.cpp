#include "KDatabase.h"



vector<Block_class> BlockList;
vector<Block_class>::iterator BlockListIt;

vector<HonorStats_class> HonorStatsVec;
vector<HonorStats_class>::iterator HonorStatsVecIt;

vector<BuffRemain_class> BuffRemainVec;
vector<BuffRemain_class>::iterator BuffRemainVecIt;

vector<HWIDBlock_class> HWIDBlockVec;
vector<HWIDBlock_class>::iterator HWIDBlockVecIt;


vector<BeadOfFireItems_class> BeadOfFireItemsVec;
vector<BeadOfFireItems_class>::iterator BeadOfFireItemsIt;



void KDatabase::Connect(const char *dbname)
{
	auto_ptr<KServer> server;
	server->ConsoleWrite(TextColor::ORANGE, "Connecting [%s]", dbname);
	SQLAllocEnv(&henv);
	SQLAllocConnect(henv, &hdbc);
	rc = SQLConnectA(hdbc, (unsigned char*)dbname, SQL_NTS, 0, 0, 0, 0);
	this->CheckConnection(rc, dbname);
}

void KDatabase::CheckConnection(int i, const char *dbname)
{
	auto_ptr<KServer> server;
	switch (i)
	{
	case -2:
		server->ConsoleWrite(TextColor::DARK_ORANGE, "%s [Connection Error: invalid handle]", dbname);
	case -1:
		server->ConsoleWrite(TextColor::DARK_ORANGE, "%s [Connection Error]", dbname);
	case 0:
		server->ConsoleWrite(TextColor::GREEN, "%s [Connection successfully established]", dbname);
	case 1:
		server->ConsoleWrite(TextColor::GREEN, "%s [Connection successfully established]", dbname);
	}


}
 



void KDatabase::GetBlockList()
{
	rc = SQLAllocStmt(hdbc, &hstmt);
	sprintf_s(Query, "SELECT UID, isBlocked FROM Login");
	rc = SQLExecDirectA(hstmt, (unsigned char*)Query, SQL_NTS);
	bool found = (false);
	Block_class blocklist_class;

	for (rc = SQLFetch(hstmt); rc == SQL_SUCCESS; rc = SQLFetch(hstmt))
	{
		int UID, isBlocked;
		SQLGetData(hstmt, 1, SQL_INTEGER, &UID, sizeof(int), &cbData);
		SQLGetData(hstmt, 2, SQL_INTEGER, &isBlocked, sizeof(bool), &cbData);
		for (BlockListIt = BlockList.begin(); BlockListIt != BlockList.end(); BlockListIt++)
		{
			if (BlockListIt->UID == UID)
			{
				found = true;
				BlockListIt->isBlocked = (isBlocked);
			}
		}
		if (!found)
		{
			blocklist_class.UID = (UID);
			blocklist_class.isBlocked = (isBlocked);
			BlockList.push_back(blocklist_class);
		}
	}
}

void KDatabase::GetHonorInfos()
{
	rc = SQLAllocStmt(hdbc, &hstmt);
	sprintf_s(Query, "SELECT PID, HonorPoints FROM Player");
	rc = SQLExecDirectA(hstmt, (unsigned char*)Query, SQL_NTS);
	bool found = (false);
	HonorStats_class honorstats_class;
	for (rc = SQLFetch(hstmt); rc == SQL_SUCCESS; rc = SQLFetch(hstmt))
	{
		int PID, HPoints;
		SQLGetData(hstmt, 1, SQL_INTEGER, &PID, sizeof(int), &cbData);
		SQLGetData(hstmt, 2, SQL_INTEGER, &HPoints, sizeof(int), &cbData);

		for (HonorStatsVecIt = HonorStatsVec.begin(); HonorStatsVecIt != HonorStatsVec.end(); HonorStatsVecIt++)
		{
			if (HonorStatsVecIt->PID == PID)
			{
				found = true;
				HonorStatsVecIt->HonorPoints = (HPoints);
			}
		}
		if (!found)
		{
			honorstats_class.PID = (PID);
			honorstats_class.HonorPoints = (HPoints);
			HonorStatsVec.push_back(honorstats_class);
		}
	}
}



void KDatabase::GetBuffRemainInfos()
{

	// create another SQL statement
	rc = SQLAllocStmt(hdbc, &hstmt);
	sprintf_s(Query, "SELECT PID, Type, Remain FROM BuffRemain");
	rc = SQLExecDirectA(hstmt, (unsigned char*)Query, SQL_NTS);
	bool found = (false);
	BuffRemain_class buffremain_class;
	for (rc = SQLFetch(hstmt); rc == SQL_SUCCESS; rc = SQLFetch(hstmt))
	{
		int PID, Type, Remain;
		SQLGetData(hstmt, 1, SQL_INTEGER, &PID, sizeof(int), &cbData);
		SQLGetData(hstmt, 2, SQL_INTEGER, &Type, sizeof(int), &cbData);
		SQLGetData(hstmt, 3, SQL_INTEGER, &Remain, sizeof(int), &cbData);

		for (BuffRemainVecIt = BuffRemainVec.begin(); BuffRemainVecIt != BuffRemainVec.end(); BuffRemainVecIt++)
		{
			if (BuffRemainVecIt->PID == PID && BuffRemainVecIt->BuffID == Type)
			{
				found = true;
				BuffRemainVecIt->Remain = (Remain);
			}
		}
		if (!found)
		{
			buffremain_class.PID = (PID);
			buffremain_class.BuffID = (Type);
			buffremain_class.Remain = (Remain);
			BuffRemainVec.push_back(buffremain_class);
		}
	}
}


void KDatabase::DecreaseBuffRemain()
{
	for (BuffRemainVecIt = BuffRemainVec.begin(); BuffRemainVecIt != BuffRemainVec.end(); BuffRemainVecIt++)
	{
		if (BuffRemainVecIt->Remain > 0)
		{
			rc = SQLAllocStmt(hdbc, &hstmt);
			sprintf_s(Query, "UPDATE BuffRemain SET Remain = '%i' WHERE PID = '%i' AND Type = '%i'", (BuffRemainVecIt->Remain - 1), BuffRemainVecIt->PID, BuffRemainVecIt->BuffID);
			rc = SQLExecDirectA(hstmt, (unsigned char*)Query, SQL_NTS);
		}
		else if (BuffRemainVecIt->Remain <= 0)
		{
			rc = SQLAllocStmt(hdbc, &hstmt);
			sprintf_s(Query, "DELETE FROM BuffRemain WHERE PID = '%i' AND Type = '%i'", BuffRemainVecIt->PID, BuffRemainVecIt->BuffID);
			rc = SQLExecDirectA(hstmt, (unsigned char*)Query, SQL_NTS);
		}
	}
}


void KDatabase::GetHWIDBlockList()
{
	// create another SQL statement
	rc = SQLAllocStmt(hdbc, &hstmt);
	sprintf_s(Query, "SELECT HWID FROM HWID_BlockList");
	rc = SQLExecDirectA(hstmt, (unsigned char*)Query, SQL_NTS);
	bool found = (false);
	HWIDBlock_class hwidblock_class;
	for (rc = SQLFetch(hstmt); rc == SQL_SUCCESS; rc = SQLFetch(hstmt))
	{
		string HWID;
		SQLGetData(hstmt, 1, SQL_CHAR, &HWID, sizeof(char), &cbData);
		for (HWIDBlockVecIt = HWIDBlockVec.begin(); HWIDBlockVecIt != HWIDBlockVec.end(); HWIDBlockVecIt++)
		{
			if (!HWIDBlockVecIt->HWID.compare(HWID))
			{
				found = true;
				HWIDBlockVecIt->HWID = (HWID);
			}
		}
		if (!found)
		{
			hwidblock_class.HWID = (HWID);
			HWIDBlockVec.push_back(hwidblock_class);
		}
	}
}


void KDatabase::UpdateOnlineStats()
{
	auto_ptr<KServer> Server;
	int Total = (0);
	int Knight = (0);
	int Mage = (0);
	int Archer = (0);
	int Thief = (0);

	for (PlayerListIt = PlayerList.begin(); PlayerListIt != PlayerList.end(); PlayerListIt++)
	{
		Total++;
		if (PlayerListIt->Class == CClass::Knight){ Knight++; }
		else if (PlayerListIt->Class == CClass::Mage){ Mage++; }
		else if (PlayerListIt->Class == CClass::Archer){ Archer++; }
		else if (PlayerListIt->Class == CClass::Thief){ Thief++; }
	}

	rc = SQLAllocStmt(hdbc, &hstmt);
	sprintf_s(Query, "UPDATE PlayerOnline SET Total = '%i', Knight = '%i', Mage = '%i', Archer = '%i', Thief = '%i' WHERE Num = '1'", Total, Knight, Mage, Archer, Thief);
	rc = SQLExecDirectA(hstmt, (unsigned char*)Query, SQL_NTS);
}





void KDatabase::GetBofItems()
{
	// create another SQL statement
	rc = SQLAllocStmt(hdbc, &hstmt);
	sprintf_s(Query, "SELECT PID, IID, Bof FROM Item");
	rc = SQLExecDirectA(hstmt, (unsigned char*)Query, SQL_NTS);
	bool found = (false);
	BeadOfFireItems_class beadoffireitems;
	for (rc = SQLFetch(hstmt); rc == SQL_SUCCESS; rc = SQLFetch(hstmt))
	{
		int PID, IID, Bof;
		SQLGetData(hstmt, 1, SQL_INTEGER, &PID, sizeof(int), &cbData);
		SQLGetData(hstmt, 2, SQL_INTEGER, &IID, sizeof(int), &cbData);
		SQLGetData(hstmt, 3, SQL_INTEGER, &Bof, sizeof(int), &cbData);

		for (BeadOfFireItemsIt = BeadOfFireItemsVec.begin(); BeadOfFireItemsIt != BeadOfFireItemsVec.end(); BeadOfFireItemsIt++)
		{
			if (BeadOfFireItemsIt->Pid == PID && BeadOfFireItemsIt->IID == IID)
			{
				found = true;
				BeadOfFireItemsIt->Bof = (Bof);
			}
		}
		if (!found)
		{
			beadoffireitems.Pid = (PID);
			beadoffireitems.IID = (IID);
			beadoffireitems.Bof = (Bof);
			BeadOfFireItemsVec.push_back(beadoffireitems);
		}
	}
}