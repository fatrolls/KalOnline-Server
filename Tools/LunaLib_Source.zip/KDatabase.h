#ifndef __KDATABASE_H
#define __KDATABASE_H
#include <Windows.h>
#include <sql.h>
#include <sqltypes.h>
#include <sqlext.h>
#include <Odbcinst.h>
#include <process.h>
#include <stdio.h>
#include <string>
#include "KServer.h"

#pragma once


#pragma comment( lib, "odbc32.lib" )



class KDatabase
{
	public:
		RETCODE rc;        // ODBC return code
		HENV henv;         // Environment
		HDBC hdbc;         // Connection handle
		HSTMT hstmt;       // Statement handle
		SDWORD cbData;     // Output length of data
		char Query[1024];
		//KDatabase(const char *dbname){};
		void Connect(const char *dbname);
		void CheckConnection(int i, const char *dbname);
		void GetBlockList();
		void GetHonorInfos();

		void GetBuffRemainInfos();
		void DecreaseBuffRemain();

		void GetHWIDBlockList();

		void UpdateOnlineStats();
		void GetBofItems();
};


class HonorStats_class{
public:
	int PID;
	int HonorPoints;
};


class Block_class{
public:
	int UID;
	int isBlocked;
};

class HWIDBlock_class{
public:
	string HWID;
};


class BuffRemain_class{
public:
	int PID;
	int BuffID;
	int Remain;
};

class BeadOfFireItems_class{
public:
	int Pid;
	int IID;
	int Bof;
};


extern vector<BeadOfFireItems_class> BeadOfFireItemsVec;
extern vector<BeadOfFireItems_class>::iterator BeadOfFireItemsIt;

extern vector<Block_class> BlockList;
extern vector<Block_class>::iterator BlockListIt;

extern vector<HonorStats_class> HonorStatsVec;
extern vector<HonorStats_class>::iterator HonorStatsVecIt;

extern vector<BuffRemain_class> BuffRemainVec;
extern vector<BuffRemain_class>::iterator BuffRemainVecIt;

extern vector<HWIDBlock_class> HWIDBlockVec;
extern vector<HWIDBlock_class>::iterator HWIDBlockVecIt;

#endif