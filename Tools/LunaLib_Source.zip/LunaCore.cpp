
#include "LunaCore.h"


void LunaCore::Register(PVOID *source, PVOID dest){
    if (this->call_reason == DLL_PROCESS_ATTACH){
        this->sources.push_back(source);
        this->destinations.push_back(dest);
    }
}

void LunaCore::RegisterHook(unsigned long source, PVOID dest){
    if (this->call_reason == DLL_PROCESS_ATTACH){
        this->hook_sources.push_back(source);
        this->hook_destinations.push_back(dest);
    }
}

void LunaCore::RegisterCustom(void (*pfunc)()){
    if (this->call_reason == DLL_PROCESS_ATTACH){
        DetourTransactionBegin();
        DetourUpdateThread(GetCurrentThread());
        pfunc();
        DetourTransactionCommit();
    }
}

void LunaCore::RegisterIntercept(unsigned char instruction, void* source, void* dest, size_t length){
    if (this->call_reason == DLL_PROCESS_ATTACH){
		this->intercept_instruction.push_back(instruction);
		this->intercept_sources.push_back(source);
		this->intercept_destinations.push_back(dest);
		this->intercept_length.push_back(length);
    }
}


void LunaCore::Attach(){
		auto_ptr<IMemory> Memory;

			DetourTransactionBegin();
			DetourUpdateThread(GetCurrentThread());
		for(unsigned int i = 0; i < this->sources.size() && i < this->destinations.size(); i++){
			DetourAttach(this->sources[i], this->destinations[i]);}
			DetourTransactionCommit();

		for(unsigned int i = 0; i < this->hook_sources.size() && i < this->hook_destinations.size(); i++){
			Memory->Hook(this->hook_sources[i],this->hook_destinations[i]);
		}
		for(unsigned int i = 0; i < this->intercept_sources.size() && i < this->intercept_destinations.size(); i++){
			Memory->Intercept(this->intercept_instruction[i], this->intercept_sources[i], this->intercept_destinations[i], this->intercept_length[i]);
		}
}

void LunaCore::Detach(){
	auto_ptr<IMemory> Memory;
		DetourTransactionBegin();
		DetourUpdateThread(GetCurrentThread());
    for (unsigned int i = 0; i < this->sources.size() && i < this->destinations.size(); i++){
		DetourDetach(this->sources[i], this->destinations[i]);}
		DetourTransactionCommit();

    for (unsigned int i = 0; i < this->hook_sources.size() && i < this->hook_destinations.size(); i++){
        Memory->Restore(this->hook_sources[i]);
    }
}


void LunaCore::SetExportsType(int exportstype){
	this->ExportsType = exportstype;
}

void LunaCore::SetCallReason(DWORD call_reason){
	 this->call_reason = call_reason;
}

void LunaCore::Init(DWORD call_reason, int exportstype){
    this->call_reason = call_reason;
	this->ExportsType = exportstype;
}

void LunaCore::InitExports(){
	if(this->ExportsType == EXPORTS_TYPE::_SERVER){
		   auto_ptr<SExports> sexports(new SExports()); sexports->Initialize();
	}
	else if(this->ExportsType == EXPORTS_TYPE::_CLIENT){
			auto_ptr<EngineExports> EExports(new EngineExports()); EExports->Initialize();
	}
}



bool LunaCore::Run()
{
    switch (this->call_reason)
    {
    case DLL_PROCESS_ATTACH:
        {	
			this->InitExports();
            this->Attach();
            break;
        }
    case DLL_PROCESS_DETACH:
        {
            this->Detach();
            break;
        }
    }
    return TRUE;
}