#ifndef __KMONSTER_H
#define __KMONSTER_H
#include "KServer.h"
#include "KSummon.h"

class KMonster
{
public:
	int* MonsterArray;
	KMonster(){};
	KMonster(int* PointerToArray);
	virtual ~KMonster();

	int* GetArray(void);
	void SetArray(int* PointerToArray);
	bool Check();

	int GetIndex();
	int GetBaseID();
	int GetPID();
	int GetX();
	int GetY();
	int GetDirection();
	int GetCurHp();
	int GetMaxHp();
	int GetGstate();
	int GetMstate();
	int GetRace();
	int GetGID();
	int* GetTargetptr();
	unsigned int GetEndtick();
	void Lock();
	void Unlock();
	void Remove();
	bool IsSummon();
	unsigned int GetSummonTick();
	int* GetCasterptr();
	int GetSummonType();
	void AddGstate(unsigned int Gstate);
	void RemoveFromSummonVec();
	bool IsSummonType(int Summontype);
};

#endif