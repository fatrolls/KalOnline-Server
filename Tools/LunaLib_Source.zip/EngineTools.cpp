#include "EngineTools.h"



void ETools::SetMemoryEx(void* Destination, const char* Data, size_t Size)
{
	this->MemcpyExD(Destination, (void*)Data, Size);
}
void ETools::SetMemoryEx(unsigned long Destination, const char* Data, size_t Size)
{
	this->SetMemoryEx((void*)Destination, Data, Size);
}

void* ETools::MemcpyEx(void *Dest, void* Source, size_t Size)
{
    unsigned long oldSourceProt, oldDestProt;
    VirtualProtect(Source, Size, PAGE_EXECUTE_READWRITE, &oldSourceProt);
    VirtualProtect(Dest, Size, PAGE_EXECUTE_READWRITE, &oldDestProt);
    memcpy(Dest, Source, Size);
    VirtualProtect(Dest, Size, oldDestProt, &oldDestProt);
    VirtualProtect(Source, Size, oldSourceProt, &oldSourceProt);
    return Dest;
}
void* ETools::MemcpyExS(void *Dest, void* Source, size_t Size)
{
    unsigned long oldSourceProt;
    VirtualProtect(Source, Size, PAGE_EXECUTE_READWRITE, &oldSourceProt);
    memcpy(Dest, Source, Size);
    VirtualProtect(Source, Size, oldSourceProt, &oldSourceProt);
    return Dest;
}
void* ETools::MemcpyExD(void *Dest, void* Source, size_t Size)
{
    unsigned long oldDestProt;
    VirtualProtect((LPVOID)Dest, Size, PAGE_EXECUTE_READWRITE, &oldDestProt);
    memcpy(Dest, Source, Size);
    VirtualProtect(Dest, Size, oldDestProt, &oldDestProt);
    return Dest;
}
void ETools::FillMemoryEx(void* Destination, unsigned char Fill, size_t Size)
{
	unsigned long oldDestProt;
    VirtualProtect(Destination, Size, PAGE_EXECUTE_READWRITE, &oldDestProt);
    FillMemory(Destination, Size, Fill);
    VirtualProtect(Destination, Size, oldDestProt, &oldDestProt);
}
void ETools::FillMemoryEx(unsigned long Destination, unsigned char Fill, size_t Size)
{
	unsigned long oldDestProt;
    VirtualProtect((void*)Destination, Size, PAGE_EXECUTE_READWRITE, &oldDestProt);
    FillMemory((void*)Destination, Size, Fill);
    VirtualProtect((void*)Destination, Size, oldDestProt, &oldDestProt);
}

unsigned long ETools::Intercept(unsigned char instruction, void* source, void* destination, size_t length)
{
	unsigned long realTarget;
	LPBYTE buffer = new BYTE[length];
	memset(buffer,0x90,length);
	if (instruction != ETools::_I_NOP && length >= 5)
	{
		buffer[(length-5)] = instruction;
		unsigned long dwJMP = (unsigned long)destination - ((unsigned long)source + 5 + (length-5));
		memcpy(&realTarget,(void*)((unsigned long)source+1),4);
		realTarget = realTarget + (unsigned long)source + 5;
		memcpy(buffer + 1 + (length - 5),&dwJMP,4);
	}
	if (instruction == ETools::_I_JE_SHORT)
	{
		buffer[0] = instruction;
		buffer[1] = (BYTE)destination;
	}
	if (instruction == 0x00)
		buffer[0] = (BYTE)destination;

	this->MemcpyExD(source, buffer, length);
	delete[] buffer;
	return realTarget;
}



vector<string> ETools::Explode(string String, string Separator)
{
	vector<string> r;
	int p = String.find(Separator);
	while(p != string::npos)
	{
		if(p) r.push_back(String.substr(0, p));
		String = String.substr(p + Separator.length());
		p = String.find(Separator);
	}
	if(String.length()) r.push_back(String);
	return r;
}



/*
void ETools::DetourFunc(BYTE* src, BYTE* prolog, const int len)
{
	DWORD dwOldProtection;
	BYTE* trampoline = (BYTE*)malloc(len + 5);
	VirtualProtect(trampoline, len + 5, PAGE_EXECUTE_READWRITE, &dwOldProtection);
	VirtualProtect(src, len, PAGE_EXECUTE_READWRITE, &dwOldProtection);
	memcpy(trampoline, src, len);
	trampoline += len;
	trampoline[0] = 0xE9;
	*(DWORD*)(trampoline + 1) = (DWORD)(src + len - trampoline) - 5;
	Jumpback = (DWORD)(trampoline - len);
	src[0] = 0xE9;
	*(DWORD*)(src + 1) = (DWORD)(prolog - src) - 5;
	VirtualProtect(src, len, dwOldProtection, &dwOldProtection);
}
*/



void *ETools::DetourFunction(BYTE *src, const BYTE *dst, const int len)
{
	BYTE *jmp;
	DWORD dwback;
	DWORD jumpto, newjump;

	VirtualProtect(src, len, PAGE_READWRITE, &dwback);

	if (src[0] == 0xE9){
		jmp = (BYTE*)malloc(10);
		jumpto = (*(DWORD*)(src + 1)) + ((DWORD)src) + 5;
		newjump = (jumpto - (DWORD)(jmp + 5));
		jmp[0] = 0xE9;
		*(DWORD*)(jmp + 1) = newjump;
		jmp += 5;
		jmp[0] = 0xE9;
		*(DWORD*)(jmp + 1) = (DWORD)(src - jmp);
	}
	else{
		jmp = (BYTE*)malloc(5 + len);
		memcpy(jmp, src, len);
		jmp += len;
		jmp[0] = 0xE9;
		*(DWORD*)(jmp + 1) = (DWORD)(src + len - jmp) - 5;
	}
	src[0] = 0xE9;
	*(DWORD*)(src + 1) = (DWORD)(dst - src) - 5;

	for (int i = 5; i < len; i++)
		src[i] = 0x90;

	VirtualProtect(src, len, dwback, &dwback);

	return (jmp - len);
}


bool ETools::bDataCompare(const BYTE* pData, const BYTE* bMask, const char* szMask)
{
	for (; *szMask; ++szMask, ++pData, ++bMask)
		if (*szMask == 'x' && *pData != *bMask)
			return false;
	return (*szMask) == NULL;
}

DWORD ETools::dwFindPattern(DWORD dwAddress, DWORD dwLen, BYTE *bMask, char * szMask)
{
	for (DWORD i = 0; i < dwLen; i++)
		if (this->bDataCompare((BYTE*)(dwAddress + i), bMask, szMask))
			return (DWORD)(dwAddress + i);

	return 0;
}



unsigned long ETools::GetCaller(size_t Depth)
{
	unsigned long _Ebp, Addr;
	if (!Depth){
		__asm mov eax, [ebp]
			__asm mov _Ebp, eax
	}
	else{
		__asm mov eax, ebp
		__asm mov _Ebp, eax
	}

	for (size_t i = 0; i < Depth; i++){
		__asm mov eax, _Ebp
		__asm mov eax, [eax]
			__asm mov _Ebp, eax
	}
	__asm mov eax, _Ebp
	__asm mov eax, [eax + 4]
		__asm mov Addr, eax
	return Addr - 5;
}







std::string ETools::sha256(const std::string str)
{
	unsigned char hash[SHA256_DIGEST_LENGTH];
	SHA256_CTX sha256;
	SHA256_Init(&sha256);
	SHA256_Update(&sha256, str.c_str(), str.size());

	SHA256_Final(hash, &sha256);

	std::stringstream ss;
	for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
	{
		ss << std::hex << std::setw(2) << std::setfill('0') << (int)hash[i];
	}

	return ss.str();
}

void ETools::GetSha256_string_hash(unsigned char hash[SHA256_DIGEST_LENGTH], char outputBuffer[65])
{
	int i = 0;

	for (i = 0; i < SHA256_DIGEST_LENGTH; i++)
	{
		sprintf(outputBuffer + (i * 2), "%02x", hash[i]);
	}

	outputBuffer[64] = 0;
}

int ETools::GetSha256_File_Hash(char* path, char output[65])
{
	FILE* file = fopen(path, "rb");
	if (!file) return -1;

	unsigned  char hash[SHA256_DIGEST_LENGTH];
	SHA256_CTX sha256;
	SHA256_Init(&sha256);
	const int bufSize = 32768;
	char* buffer = new char[bufSize];
	int bytesRead = 0;
	if (!buffer) return -1;
	while ((bytesRead = fread(buffer, 1, bufSize, file)))
	{
		SHA256_Update(&sha256, buffer, bytesRead);
	}
	SHA256_Final(hash, &sha256);

	this->GetSha256_string_hash(hash, output);
	fclose(file);
	delete[] buffer;
	return 0;
}


string ETools::GetHWID()
{
	char              szWindowsDir[128];
	char              szVolumeName[MAX_PATH + 1];
	char              szFileSysName[MAX_PATH + 1];
	char              szRawHWID[512];
	DWORD             dwVolumeSerial;
	HW_PROFILE_INFOA  hwProfile;
	
	string			  ret;

	if (GetWindowsDirectoryA(szWindowsDir, 128))
	{
		for (DWORD i = 0; i < strlen(szWindowsDir); ++i) {
			if (szWindowsDir[i] == '\\')
				szWindowsDir[i + 1] = 0;
		}

		if (GetVolumeInformationA(szWindowsDir, szVolumeName, MAX_PATH + 1, &dwVolumeSerial, 0, 0, szFileSysName, MAX_PATH + 1))
		{
			if (GetCurrentHwProfileA(&hwProfile))
			{
				sprintf_s(szRawHWID, "%s", hwProfile.szHwProfileGuid);
				string HWIDstr(szRawHWID);
				ret = HWIDstr;
			}
		}
	}
	return ret;
}