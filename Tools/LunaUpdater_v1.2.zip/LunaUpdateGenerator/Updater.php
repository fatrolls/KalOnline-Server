<?php

$id = $_REQUEST['id'];

switch ($id) {
    case "GetChangelog":
        $file = file_get_contents('./Changelog.txt', true);
        echo"$file";
        break;
    case "GetNews":
        echo "LunaClient Updater";
        break;
    case "GetNewsColor":
        echo 10;
        break;
    case "GetFileListPath":
        echo "http://www.YourDomain.com/LunaUpdater/FileList.xml";
        break;
    case "GetDeleteListPath":
        echo "http://www.YourDomain.com/LunaUpdater/DeleteList.xml";
        break;
    case "InfoWindowState":
        echo 1;
        break;
    case "GetInfoHtmlPath":
        echo "http://www.YourDomain.com/LunaUpdater/Info.html";
        break;
}
?>