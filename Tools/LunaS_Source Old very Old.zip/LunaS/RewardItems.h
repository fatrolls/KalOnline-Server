#undef UNICODE
#include <cstdio>
#include <windows.h>
#include "stdafx.h"
#include <process.h>
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#pragma comment(lib, "KosaLib.lib")
#include <KServer.h>
#include <KPlayer.h>
#include <KCommand.h>

#include "ReadConfig.h"



namespace RewardItem
{
	

	#pragma region ReadIni
	CIniReader iniReader(".\\.\\LunaS\\RewardItems.ini");
	bool OnOff = iniReader.ReadBoolean("RewardItem_Options", "Enabled", false);
	char *RMessageName = iniReader.ReadString("Buff_System", "MessageName", "[Server]");

	int level_01 = iniReader.ReadInteger("RewardItem_01", "Level", 0);
	int index_01 = iniReader.ReadInteger("RewardItem_01", "Index", 0);
	int amount_01 = iniReader.ReadInteger("RewardItem_01", "Amount", 0);
	char *rm_01 = iniReader.ReadString("RewardItem_01", "Message", "");
	int CP_01 = iniReader.ReadInteger("RewardItem_01", "ContributePoints", 0);
	int SP_01 = iniReader.ReadInteger("RewardItem_01", "SkillPoints", 0);

	int level_02 = iniReader.ReadInteger("RewardItem_02", "Level", 0);
	int index_02 = iniReader.ReadInteger("RewardItem_02", "Index", 0);
	int amount_02 = iniReader.ReadInteger("RewardItem_02", "Amount", 0);
	char *rm_02 = iniReader.ReadString("RewardItem_02", "Message", "");
	int CP_02 = iniReader.ReadInteger("RewardItem_02", "ContributePoints", 0);
	int SP_02 = iniReader.ReadInteger("RewardItem_02", "SkillPoints", 0);

	int level_03 = iniReader.ReadInteger("RewardItem_03", "Level", 0);
	int index_03 = iniReader.ReadInteger("RewardItem_03", "Index", 0);
	int amount_03 = iniReader.ReadInteger("RewardItem_03", "Amount", 0);
	char *rm_03 = iniReader.ReadString("RewardItem_03", "Message", "");
	int CP_03 = iniReader.ReadInteger("RewardItem_03", "ContributePoints", 0);
	int SP_03 = iniReader.ReadInteger("RewardItem_03", "SkillPoints", 0);

	int level_04 = iniReader.ReadInteger("RewardItem_04", "Level", 0);
	int index_04 = iniReader.ReadInteger("RewardItem_04", "Index", 0);
	int amount_04 = iniReader.ReadInteger("RewardItem_04", "Amount", 0);
	char *rm_04 = iniReader.ReadString("RewardItem_04", "Message", "");
	int CP_04 = iniReader.ReadInteger("RewardItem_04", "ContributePoints", 0);
	int SP_04 = iniReader.ReadInteger("RewardItem_04", "SkillPoints", 0);

	int level_05 = iniReader.ReadInteger("RewardItem_05", "Level", 0);
	int index_05 = iniReader.ReadInteger("RewardItem_05", "Index", 0);
	int amount_05 = iniReader.ReadInteger("RewardItem_05", "Amount", 0);
	char *rm_05 = iniReader.ReadString("RewardItem_05", "Message", "");
	int CP_05 = iniReader.ReadInteger("RewardItem_05", "ContributePoints", 0);
	int SP_05 = iniReader.ReadInteger("RewardItem_05", "SkillPoints", 0);

	int level_06 = iniReader.ReadInteger("RewardItem_06", "Level", 0);
	int index_06 = iniReader.ReadInteger("RewardItem_06", "Index", 0);
	int amount_06 = iniReader.ReadInteger("RewardItem_06", "Amount", 0);
	char *rm_06 = iniReader.ReadString("RewardItem_06", "Message", "");
	int CP_06 = iniReader.ReadInteger("RewardItem_06", "ContributePoints", 0);
	int SP_06 = iniReader.ReadInteger("RewardItem_06", "SkillPoints", 0);

	int level_07 = iniReader.ReadInteger("RewardItem_07", "Level", 0);
	int index_07 = iniReader.ReadInteger("RewardItem_07", "Index", 0);
	int amount_07 = iniReader.ReadInteger("RewardItem_07", "Amount", 0);
	char *rm_07 = iniReader.ReadString("RewardItem_07", "Message", "");
	int CP_07 = iniReader.ReadInteger("RewardItem_07", "ContributePoints", 0);
	int SP_07 = iniReader.ReadInteger("RewardItem_07", "SkillPoints", 0);

	int level_08 = iniReader.ReadInteger("RewardItem_08", "Level", 0);
	int index_08 = iniReader.ReadInteger("RewardItem_08", "Index", 0);
	int amount_08 = iniReader.ReadInteger("RewardItem_08", "Amount", 0);
	char *rm_08 = iniReader.ReadString("RewardItem_08", "Message", "");
	int CP_08 = iniReader.ReadInteger("RewardItem_08", "ContributePoints", 0);
	int SP_08 = iniReader.ReadInteger("RewardItem_08", "SkillPoints", 0);

	int level_09 = iniReader.ReadInteger("RewardItem_09", "Level", 0);
	int index_09 = iniReader.ReadInteger("RewardItem_09", "Index", 0);
	int amount_09 = iniReader.ReadInteger("RewardItem_09", "Amount", 0);
	char *rm_09 = iniReader.ReadString("RewardItem_09", "Message", "");
	int CP_09 = iniReader.ReadInteger("RewardItem_09", "ContributePoints", 0);
	int SP_09 = iniReader.ReadInteger("RewardItem_09", "SkillPoints", 0);

	int level_10 = iniReader.ReadInteger("RewardItem_10", "Level", 0);
	int index_10 = iniReader.ReadInteger("RewardItem_10", "Index", 0);
	int amount_10 = iniReader.ReadInteger("RewardItem_10", "Amount", 0);
	char *rm_10 = iniReader.ReadString("RewardItem_10", "Message", "");
	int CP_10 = iniReader.ReadInteger("RewardItem_10", "ContributePoints", 0);
	int SP_10 = iniReader.ReadInteger("RewardItem_10", "SkillPoints", 0);

	int level_11 = iniReader.ReadInteger("RewardItem_11", "Level", 0);
	int index_11 = iniReader.ReadInteger("RewardItem_11", "Index", 0);
	int amount_11 = iniReader.ReadInteger("RewardItem_11", "Amount", 0);
	char *rm_11 = iniReader.ReadString("RewardItem_11", "Message", "");
	int CP_11 = iniReader.ReadInteger("RewardItem_11", "ContributePoints", 0);
	int SP_11 = iniReader.ReadInteger("RewardItem_11", "SkillPoints", 0);

	int level_12 = iniReader.ReadInteger("RewardItem_12", "Level", 0);
	int index_12 = iniReader.ReadInteger("RewardItem_12", "Index", 0);
	int amount_12 = iniReader.ReadInteger("RewardItem_12", "Amount", 0);
	char *rm_12 = iniReader.ReadString("RewardItem_12", "Message", "");
	int CP_12 = iniReader.ReadInteger("RewardItem_12", "ContributePoints", 0);
	int SP_12 = iniReader.ReadInteger("RewardItem_12", "SkillPoints", 0);

	int level_13 = iniReader.ReadInteger("RewardItem_13", "Level", 0);
	int index_13 = iniReader.ReadInteger("RewardItem_13", "Index", 0);
	int amount_13 = iniReader.ReadInteger("RewardItem_13", "Amount", 0);
	char *rm_13 = iniReader.ReadString("RewardItem_13", "Message", "");
	int CP_13 = iniReader.ReadInteger("RewardItem_13", "ContributePoints", 0);
	int SP_13 = iniReader.ReadInteger("RewardItem_13", "SkillPoints", 0);

	int level_14 = iniReader.ReadInteger("RewardItem_14", "Level", 0);
	int index_14 = iniReader.ReadInteger("RewardItem_14", "Index", 0);
	int amount_14 = iniReader.ReadInteger("RewardItem_14", "Amount", 0);
	char *rm_14 = iniReader.ReadString("RewardItem_14", "Message", "");
	int CP_14 = iniReader.ReadInteger("RewardItem_14", "ContributePoints", 0);
	int SP_14 = iniReader.ReadInteger("RewardItem_14", "SkillPoints", 0);

	int level_15 = iniReader.ReadInteger("RewardItem_15", "Level", 0);
	int index_15 = iniReader.ReadInteger("RewardItem_15", "Index", 0);
	int amount_15 = iniReader.ReadInteger("RewardItem_15", "Amount", 0);
	char *rm_15 = iniReader.ReadString("RewardItem_15", "Message", "");
	int CP_15 = iniReader.ReadInteger("RewardItem_15", "ContributePoints", 0);
	int SP_15 = iniReader.ReadInteger("RewardItem_15", "SkillPoints", 0);

	int level_16 = iniReader.ReadInteger("RewardItem_16", "Level", 0);
	int index_16 = iniReader.ReadInteger("RewardItem_16", "Index", 0);
	int amount_16 = iniReader.ReadInteger("RewardItem_16", "Amount", 0);
	char *rm_16 = iniReader.ReadString("RewardItem_16", "Message", "");
	int CP_16 = iniReader.ReadInteger("RewardItem_16", "ContributePoints", 0);
	int SP_16 = iniReader.ReadInteger("RewardItem_16", "SkillPoints", 0);

	int level_17 = iniReader.ReadInteger("RewardItem_17", "Level", 0);
	int index_17 = iniReader.ReadInteger("RewardItem_17", "Index", 0);
	int amount_17 = iniReader.ReadInteger("RewardItem_17", "Amount", 0);
	char *rm_17 = iniReader.ReadString("RewardItem_17", "Message", "");
	int CP_17 = iniReader.ReadInteger("RewardItem_17", "ContributePoints", 0);
	int SP_17 = iniReader.ReadInteger("RewardItem_17", "SkillPoints", 0);

	int level_18 = iniReader.ReadInteger("RewardItem_18", "Level", 0);
	int index_18 = iniReader.ReadInteger("RewardItem_18", "Index", 0);
	int amount_18 = iniReader.ReadInteger("RewardItem_18", "Amount", 0);
	char *rm_18 = iniReader.ReadString("RewardItem_18", "Message", "");
	int CP_18 = iniReader.ReadInteger("RewardItem_18", "ContributePoints", 0);
	int SP_18 = iniReader.ReadInteger("RewardItem_18", "SkillPoints", 0);

	int level_19 = iniReader.ReadInteger("RewardItem_19", "Level", 0);
	int index_19 = iniReader.ReadInteger("RewardItem_19", "Index", 0);
	int amount_19 = iniReader.ReadInteger("RewardItem_19", "Amount", 0);
	char *rm_19 = iniReader.ReadString("RewardItem_19", "Message", "");
	int CP_19 = iniReader.ReadInteger("RewardItem_19", "ContributePoints", 0);
	int SP_19 = iniReader.ReadInteger("RewardItem_19", "SkillPoints", 0);

	int level_20 = iniReader.ReadInteger("RewardItem_20", "Level", 0);
	int index_20 = iniReader.ReadInteger("RewardItem_20", "Index", 0);
	int amount_20 = iniReader.ReadInteger("RewardItem_20", "Amount", 0);
	char *rm_20 = iniReader.ReadString("RewardItem_20", "Message", "");
	int CP_20 = iniReader.ReadInteger("RewardItem_20", "ContributePoints", 0);
	int SP_20 = iniReader.ReadInteger("RewardItem_20", "SkillPoints", 0);

	int level_21 = iniReader.ReadInteger("RewardItem_21", "Level", 0);
	int index_21 = iniReader.ReadInteger("RewardItem_21", "Index", 0);
	int amount_21 = iniReader.ReadInteger("RewardItem_21", "Amount", 0);
	char *rm_21 = iniReader.ReadString("RewardItem_21", "Message", "");
	int CP_21 = iniReader.ReadInteger("RewardItem_21", "ContributePoints", 0);
	int SP_21 = iniReader.ReadInteger("RewardItem_21", "SkillPoints", 0);

	int level_22 = iniReader.ReadInteger("RewardItem_22", "Level", 0);
	int index_22 = iniReader.ReadInteger("RewardItem_22", "Index", 0);
	int amount_22 = iniReader.ReadInteger("RewardItem_22", "Amount", 0);
	char *rm_22 = iniReader.ReadString("RewardItem_22", "Message", "");
	int CP_22 = iniReader.ReadInteger("RewardItem_22", "ContributePoints", 0);
	int SP_22 = iniReader.ReadInteger("RewardItem_22", "SkillPoints", 0);

	int level_23 = iniReader.ReadInteger("RewardItem_23", "Level", 0);
	int index_23= iniReader.ReadInteger("RewardItem_23", "Index", 0);
	int amount_23 = iniReader.ReadInteger("RewardItem_23", "Amount", 0);
	char *rm_23 = iniReader.ReadString("RewardItem_23", "Message", "");
	int CP_23 = iniReader.ReadInteger("RewardItem_23", "ContributePoints", 0);
	int SP_23 = iniReader.ReadInteger("RewardItem_23", "SkillPoints", 0);

	int level_24 = iniReader.ReadInteger("RewardItem_24", "Level", 0);
	int index_24 = iniReader.ReadInteger("RewardItem_24", "Index", 0);
	int amount_24 = iniReader.ReadInteger("RewardItem_24", "Amount", 0);
	char *rm_24 = iniReader.ReadString("RewardItem_24", "Message", "");
	int CP_24 = iniReader.ReadInteger("RewardItem_24", "ContributePoints", 0);
	int SP_24 = iniReader.ReadInteger("RewardItem_24", "SkillPoints", 0);

	int level_25 = iniReader.ReadInteger("RewardItem_25", "Level", 0);
	int index_25 = iniReader.ReadInteger("RewardItem_25", "Index", 0);
	int amount_25 = iniReader.ReadInteger("RewardItem_25", "Amount", 0);
	char *rm_25 = iniReader.ReadString("RewardItem_25", "Message", "");
	int CP_25 = iniReader.ReadInteger("RewardItem_25", "ContributePoints", 0);
	int SP_25 = iniReader.ReadInteger("RewardItem_25", "SkillPoints", 0);

	int level_26 = iniReader.ReadInteger("RewardItem_26", "Level", 0);
	int index_26 = iniReader.ReadInteger("RewardItem_26", "Index", 0);
	int amount_26 = iniReader.ReadInteger("RewardItem_26", "Amount", 0);
	char *rm_26 = iniReader.ReadString("RewardItem_26", "Message", "");
	int CP_26 = iniReader.ReadInteger("RewardItem_26", "ContributePoints", 0);
	int SP_26 = iniReader.ReadInteger("RewardItem_26", "SkillPoints", 0);

	int level_27 = iniReader.ReadInteger("RewardItem_27", "Level", 0);
	int index_27 = iniReader.ReadInteger("RewardItem_27", "Index", 0);
	int amount_27 = iniReader.ReadInteger("RewardItem_27", "Amount", 0);
	char *rm_27 = iniReader.ReadString("RewardItem_27", "Message", "");
	int CP_27 = iniReader.ReadInteger("RewardItem_27", "ContributePoints", 0);
	int SP_27 = iniReader.ReadInteger("RewardItem_27", "SkillPoints", 0);

	int level_28 = iniReader.ReadInteger("RewardItem_28", "Level", 0);
	int index_28 = iniReader.ReadInteger("RewardItem_28", "Index", 0);
	int amount_28 = iniReader.ReadInteger("RewardItem_28", "Amount", 0);
	char *rm_28 = iniReader.ReadString("RewardItem_28", "Message", "");
	int CP_28 = iniReader.ReadInteger("RewardItem_28", "ContributePoints", 0);
	int SP_28 = iniReader.ReadInteger("RewardItem_28", "SkillPoints", 0);

	int level_29 = iniReader.ReadInteger("RewardItem_29", "Level", 0);
	int index_29 = iniReader.ReadInteger("RewardItem_29", "Index", 0);
	int amount_29 = iniReader.ReadInteger("RewardItem_29", "Amount", 0);
	char *rm_29 = iniReader.ReadString("RewardItem_29", "Message", "");
	int CP_29 = iniReader.ReadInteger("RewardItem_29", "ContributePoints", 0);
	int SP_29 = iniReader.ReadInteger("RewardItem_29", "SkillPoints", 0);

	int level_30 = iniReader.ReadInteger("RewardItem_30", "Level", 0);
	int index_30 = iniReader.ReadInteger("RewardItem_30", "Index", 0);
	int amount_30 = iniReader.ReadInteger("RewardItem_30", "Amount", 0);
	char *rm_30 = iniReader.ReadString("RewardItem_30", "Message", "");
	int CP_30 = iniReader.ReadInteger("RewardItem_30", "ContributePoints", 0);
	int SP_30 = iniReader.ReadInteger("RewardItem_30", "SkillPoints", 0);
#pragma endregion

	void __fastcall Hooked_LevelUp(void *PlayerPointer,void* _edx)
    {
		KPlayer *player = new KPlayer(PlayerPointer);
        Server::CPlayer::LevelUp(PlayerPointer);
		
            if (level_01 == player->GetLevel())
				{
					player->InsertItem(index_01, amount_01);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_01);
					player->SetContribute(CurrentCP + CP_01);
					player->PlayerMessage(RMessageName, rm_01);
				}
			if (level_02 == player->GetLevel())
				{
					player->InsertItem(index_02, amount_02);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_02);
					player->SetContribute(CurrentCP + CP_02);
					player->PlayerMessage(RMessageName, rm_02);

				} 
			if (level_03 == player->GetLevel())
				{
					player->InsertItem(index_03, amount_03);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_03);
					player->SetContribute(CurrentCP + CP_03);
					player->PlayerMessage(RMessageName, rm_03);

				} 
			if (level_04 == player->GetLevel())
				{
					player->InsertItem(index_04, amount_04);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_04);
					player->SetContribute(CurrentCP + CP_04);
					player->PlayerMessage(RMessageName, rm_04);

				} 
			if (level_05 == player->GetLevel())
				{
					player->InsertItem(index_05, amount_05);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_05);
					player->SetContribute(CurrentCP + CP_05);
					player->PlayerMessage(RMessageName, rm_05);

				} 
			if (level_06 == player->GetLevel())
				{
					player->InsertItem(index_06, amount_06);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_06);
					player->SetContribute(CurrentCP + CP_06);
					player->PlayerMessage(RMessageName, rm_06);

				} 
			if (level_07 == player->GetLevel())
				{
					player->InsertItem(index_07, amount_07);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_07);
					player->SetContribute(CurrentCP + CP_07);
					player->PlayerMessage(RMessageName, rm_07);

				} 
			if (level_08 == player->GetLevel())
				{
					player->InsertItem(index_08, amount_08);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_08);
					player->SetContribute(CurrentCP + CP_08);
					player->PlayerMessage(RMessageName, rm_08);

				} 
			if (level_09 == player->GetLevel())
				{
					player->InsertItem(index_09, amount_09);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_09);
					player->SetContribute(CurrentCP + CP_09);
					player->PlayerMessage(RMessageName, rm_09);

				} 
			if (level_10 == player->GetLevel())
				{
					player->InsertItem(index_10, amount_10);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_10);
					player->SetContribute(CurrentCP + CP_10);
					player->PlayerMessage(RMessageName, rm_10);

				} 
			if (level_11 == player->GetLevel())
				{
					player->InsertItem(index_11, amount_11);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_11);
					player->SetContribute(CurrentCP + CP_11);
					player->PlayerMessage(RMessageName, rm_11);

				} 
			if (level_12 == player->GetLevel())
				{
					player->InsertItem(index_12, amount_12);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_12);
					player->SetContribute(CurrentCP + CP_12);
					player->PlayerMessage(RMessageName, rm_12);

				} 
			if (level_13 == player->GetLevel())
				{
					player->InsertItem(index_13, amount_13);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_13);
					player->SetContribute(CurrentCP + CP_13);
					player->PlayerMessage(RMessageName, rm_13);

				} 
			if (level_14 == player->GetLevel())
				{
					player->InsertItem(index_14, amount_14);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_14);
					player->SetContribute(CurrentCP + CP_14);
					player->PlayerMessage(RMessageName, rm_14);

				} 
			if (level_15 == player->GetLevel())
				{
					player->InsertItem(index_15, amount_15);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_15);
					player->SetContribute(CurrentCP + CP_15);
					player->PlayerMessage(RMessageName, rm_15);

				} 
			if (level_16 == player->GetLevel())
				{
					player->InsertItem(index_16, amount_16);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_16);
					player->SetContribute(CurrentCP + CP_16);
					player->PlayerMessage(RMessageName, rm_16);

				} 
			if (level_17 == player->GetLevel())
				{
					player->InsertItem(index_17, amount_17);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_17);
					player->SetContribute(CurrentCP + CP_17);
					player->PlayerMessage(RMessageName, rm_17);

				} 
			if (level_18 == player->GetLevel())
				{
					player->InsertItem(index_18, amount_18);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_18);
					player->SetContribute(CurrentCP + CP_18);
					player->PlayerMessage(RMessageName, rm_18);

				} 
			if (level_19 == player->GetLevel())
				{
					player->InsertItem(index_19, amount_19);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_19);
					player->SetContribute(CurrentCP + CP_19);
					player->PlayerMessage(RMessageName, rm_19);

				} 
			if (level_20 == player->GetLevel())
				{
					player->InsertItem(index_20, amount_20);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_20);
					player->SetContribute(CurrentCP + CP_20);
					player->PlayerMessage(RMessageName, rm_20);

				} 
			if (level_21 == player->GetLevel())
				{
					player->InsertItem(index_21, amount_21);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_21);
					player->SetContribute(CurrentCP + CP_21);
					player->PlayerMessage(RMessageName, rm_21);

				} 
			if (level_22 == player->GetLevel())
				{
					player->InsertItem(index_22, amount_22);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_22);
					player->SetContribute(CurrentCP + CP_22);
					player->PlayerMessage(RMessageName, rm_22);

				} 
			if (level_23 == player->GetLevel())
				{
					player->InsertItem(index_23, amount_23);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_23);
					player->SetContribute(CurrentCP + CP_23);
					player->PlayerMessage(RMessageName, rm_23);

				} 
			if (level_24 == player->GetLevel())
				{
					player->InsertItem(index_24, amount_24);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_24);
					player->SetContribute(CurrentCP + CP_24);
					player->PlayerMessage(RMessageName, rm_24);

				} 
			if (level_25 == player->GetLevel())
				{
					player->InsertItem(index_25, amount_25);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_25);
					player->SetContribute(CurrentCP + CP_25);
					player->PlayerMessage(RMessageName, rm_25);

				} 
			if (level_26 == player->GetLevel())
				{
					player->InsertItem(index_26, amount_26);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_26);
					player->SetContribute(CurrentCP + CP_26);
					player->PlayerMessage(RMessageName, rm_26);

				} 
			if (level_27 == player->GetLevel())
				{
					player->InsertItem(index_27, amount_27);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_27);
					player->SetContribute(CurrentCP + CP_27);
					player->PlayerMessage(RMessageName, rm_27);

				} 
			if (level_28 == player->GetLevel())
				{
					player->InsertItem(index_28, amount_28);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_28);
					player->SetContribute(CurrentCP + CP_28);
					player->PlayerMessage(RMessageName, rm_28);

				} 
			if (level_29 == player->GetLevel())
				{
					player->InsertItem(index_29, amount_29);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_29);
					player->SetContribute(CurrentCP + CP_29);
					player->PlayerMessage(RMessageName, rm_29);

				} 
			if (level_30 == player->GetLevel())
				{
					player->InsertItem(index_30, amount_30);
					int CurrentCP = player->GetContribute();
					int CurrentSP = player->GetSkillPoints();
					player->SetSkillPoints(CurrentSP + SP_30);
					player->SetContribute(CurrentCP + CP_30);
					player->PlayerMessage(RMessageName, rm_30);

				} 

	 }



	 void EnabledMessage()
	 {
		 	if(RewardItem::OnOff == false)
			{
				Server::Console::WriteRed("[LunaS] --> Reward Item System Disabled.");
			};
		if(RewardItem::OnOff == true)
			{
				Server::Console::WriteBlue("[LunaS] --> Reward Item System Enabled.");
			};
	 }


}