#include "stdafx.h"


class Core
{

};
