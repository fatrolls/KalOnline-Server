﻿========================================================================
    DYNAMIC LINK LIBRARY: LunaS-Projektübersicht
========================================================================

Diese LunaS-DLL wurde vom Anwendungs-Assistenten für 
Sie erstellt.

Diese Datei bietet eine Übersicht über den Inhalt der einzelnen Dateien, 
aus denen Ihre LunaS-Anwendung besteht.


LunaS.vcxproj
    Dies ist die Hauptprojektdatei für VC++-Projekte, die mit dem 
    Anwendungs-Assistenten generiert werden.
    Sie enthält Informationen zur Visual C++-Version, mit der die Datei 
    generiert wurde, sowie Informationen zu Plattformen, Konfigurationen und 
    Projektfunktionen, die mit dem Anwendungs-Assistenten ausgewählt wurden.

LunaS.vcxproj.filters
    Dies ist die Filterdatei für VC++-Projekte, die mithilfe eines 
    Anwendungs-Assistenten erstellt werden. 
    Sie enthält Informationen über die Zuordnung zwischen den Dateien im 
    Projekt und den Filtern. Diese Zuordnung wird in der IDE zur Darstellung 
    der Gruppierung von Dateien mit ähnlichen Erweiterungen unter einem 
    bestimmten Knoten verwendet (z. B. sind CPP-Dateien dem Filter 
    "Quelldateien" zugeordnet).

LunaS.cpp
    Dies ist die Hauptquelldatei der DLL.

	Diese DLL exportiert keine Symbole, deshalb wird beim Erstellen keine
 	LIB-Datei generiert. Wenn dieses Projekt eine Projektabhängigkeit eines 
        anderen Projekts sein soll, müssen Sie Code hinzufügen, um Symbole aus 
        der DLL zu exportieren, damit eine Exportbibliothek erstellt wird, oder 
        Sie können die Eigenschaft "Eingabebibliothek ignorieren" auf der 
        Eigenschaftenseite "Allgemein" in den Projekteigenschaften auf "Ja" 
        festlegen. Dialogfeld "Seiten".

/////////////////////////////////////////////////////////////////////////////
Andere Standarddateien:

StdAfx.h, StdAfx.cpp
    Diese Dateien werden verwendet, um eine vorkompilierte Headerdatei
    (PCH-Datei) mit dem Namen "LunaS.pch und eine 
    vorkompilierte Typendatei mit dem Namen "StdAfx.obj" zu erstellen.

/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent weist Sie mit "TODO:"-Kommentaren auf Teile des
Quellcodes hin, die Sie ergänzen oder anpassen sollten.

/////////////////////////////////////////////////////////////////////////////
