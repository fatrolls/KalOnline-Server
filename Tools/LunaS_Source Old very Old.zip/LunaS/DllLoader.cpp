#include "StdAfx.h"
#include "DllLoader.h"
#include <string>
IPlugins Plugins;
IPlugins::IPlugins()
{
	this->Load();
}

void IPlugins::Load()
{
	// Loading modules in ./dlls/

	std::wstring Path = L"./LunaLibery/";
	WIN32_FIND_DATA DataFound;
	HANDLE hFind = INVALID_HANDLE_VALUE;

	CreateDirectory(Path.c_str(), NULL);

	Path += L"*.dll";
	hFind = FindFirstFile(Path.c_str(), &DataFound);

	if (hFind != INVALID_HANDLE_VALUE)
	{
		do 
		{
			if (!(DataFound.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
			{
				// found a dll, let's load it.
				std::wstring FullName = L"./LunaLibery/" + (std::wstring)DataFound.cFileName;
				LoadLibrary(FullName.c_str());
			}
		} while (FindNextFile(hFind, &DataFound));
	}
	FindClose(hFind);
}
