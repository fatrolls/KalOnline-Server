#undef UNICODE
#pragma comment(lib, "detours.lib")
#pragma comment(lib, "KosaLib.lib")
#include <windows.h>
#include <stdio.h>
#include "stdafx.h"
#include <detours.h> 

#include "Core.h"
#include "Exports.h"
#include "Command.h"
#include "RewardItems.h"
#include "DllLoader.h"
#include "CSkill.h"



void __stdcall Hooked_ServerStart(int start)
{
				Server::CIOServer::Start(start);
				Server::Console::WriteBlue("[LunaS] --> Started.");
				RewardItem::EnabledMessage();
				Command::EnabledMessage();
}



BOOL APIENTRY DllMain( HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved )
{
	IExports *Exports = new IExports();

    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        {
				Exports->Initialize();
				DetourTransactionBegin();
				DetourUpdateThread(GetCurrentThread());
				DetourAttach(&(PVOID&)Server::CIOServer::Start, Hooked_ServerStart);
				DetourAttach(&(PVOID&)Server::CSkill::ExecuteSkill, CPlayerSkill::Hooked_ExecuteSkill);

				

				if(Command::OnOff == true)
					{
						DetourAttach(&(PVOID&)Server::CPlayer::ChatCommand, Command::Hooked_ChatCommand);
					};

				if(RewardItem::OnOff == true)
					{
						DetourAttach(&(PVOID&)Server::CPlayer::LevelUp, RewardItem::Hooked_LevelUp);
					};

				DetourTransactionCommit();
				break;

		}
    case DLL_PROCESS_DETACH:
        {
            DetourTransactionBegin();
            DetourUpdateThread(GetCurrentThread());
            DetourDetach(&(PVOID&)Server::CIOServer::Start, Hooked_ServerStart);
			DetourDetach(&(PVOID&)Server::CSkill::ExecuteSkill, CPlayerSkill::Hooked_ExecuteSkill);
			if(Command::OnOff == true)
				{
					DetourDetach(&(PVOID&)Server::CPlayer::ChatCommand, Command::Hooked_ChatCommand);
				};
			
			
			
			if(RewardItem::OnOff == true)
				{
					DetourDetach(&(PVOID&)Server::CPlayer::LevelUp, RewardItem::Hooked_LevelUp);
				};
			
            DetourTransactionCommit();
            break;
        }
    }
    return TRUE;
}





