#pragma once
#pragma comment(lib, "KosaLib.lib")
#include <windows.h>
#include <KServer.h>
#include <KPlayer.h>
#include <KCommand.h>
#include <KMonster.h>


#define WIN32_LEAN_AND_MEAN         


#define KNIGHT  0
#define MAGE    1
#define ARCHER  2
#define THIEF   3
#define MAX_SKILL_ID 84


#define RUN 0
#define BEHEAD 1
#define SPIN_SPLASH 85
#define DEREF_VAL(pointer,val) *(DWORD *)(((int*)pointer)[val])




namespace CPlayerSkill 
{

#pragma region KNIGHT_SKILLS
	int __fastcall Knight_Behead(void* PlayerPointer, char* PacketPointer, char* PositionPointer)
		{
					//KPlayer *player = new KPlayer(PlayerPointer);
					//const int PlayerID = *(int*)(unsigned(PlayerPointer)+0x1c);

					const int nSkillID = 1; /// Skill Id
					const int nSkillGrade = 1; // Skill Grade

					int result;
					int TargetId;
					char Type;
					void* PlayerID = 0;
					void* TargetID = 0;
					void* MonsterID = 0;


							Server::CIOServer::ReadPacket(PacketPointer, PositionPointer, "bd", &Type, &TargetId);
							void *MonsterPointer = Server::CMonster::FindMonster(TargetId);
							Monster *monster = new Monster(MonsterPointer);
							KPlayer *player = new KPlayer(PlayerPointer);
							result = (int) MonsterPointer;


								if(MonsterPointer)
								{

									 int PlayerMaxHP = Server::CChar::GetMaxHp(PlayerPointer);
									 (*(void (__cdecl **)(void *, signed int, signed int, int))
									 //(*(void (__cdecl **)(void*, int, int, int))
									 (*(DWORD*)PlayerPointer + 88))(PlayerPointer, 7, 1, PlayerMaxHP / 8);

									  int PlayerMaxMP = Server::CChar::GetMaxMp(PlayerPointer);
									 (*(void (__cdecl **)(void *, signed int, signed int, int))
									 //(*(void (__cdecl **)(void*, int, int, int))
									 (*(DWORD*)PlayerPointer + 88))(PlayerPointer, 8, 1, PlayerMaxMP / 8);



									 PlayerID = Server::CBase::Id(PlayerPointer);
									 TargetID = Server::CBase::Id(MonsterPointer);
									 Server::CChar::WriteInSight(PlayerPointer,0x3F, "bddbb", 1, PlayerID, TargetID, 0, 1);

									 MonsterID = Server::CBase::Id(MonsterPointer);
									 Server::CChar::WriteInSight(MonsterPointer, 0x3D, "db", MonsterID, 0xA);
									 Server::CBase::Delete(MonsterPointer);
							}
								                


						//delete player; player = 0;
						return result;
}


	/*int __fastcall Knight_SpinSplash(void* PlayerPointer, char* PacketPointer, char* PositionPointer)
		{

								                
}*/

#pragma endregion

#pragma region MAGE_SKILLS
#pragma endregion

#pragma region ARCHER_SKILLS
#pragma endregion

#pragma region THIEF_SKILLS


		/*int __fastcall Thief_Run(void* PlayerPointer, char* PacketPointer, char* PositionPointer)
		{

					const int nSkillID = 0; /// Skill Id
					const int nSkillGrade = 1; // Skill Grade
					int result;

					//Mana Verbrauchen
					(*(void (__cdecl **)(void *, signed int, signed int, int))
					(*(DWORD*)PlayerPointer + 88))(PlayerPointer, 8, 0, 6);
          
					return result;
}*/



		int __fastcall Thief_Behead(void* PlayerPointer, char* PacketPointer, char* PositionPointer)
		{
					//KPlayer *player = new KPlayer(PlayerPointer);
					//const int PlayerID = *(int*)(unsigned(PlayerPointer)+0x1c);

					const int nSkillID = 1; /// Skill Id
					const int nSkillGrade = 1; // Skill Grade

					int result;
					int TargetId;
					char Type;
					void* PlayerID = 0;
					void* TargetID = 0;
					void* MonsterID = 0;


							Server::CIOServer::ReadPacket(PacketPointer, PositionPointer, "bd", &Type, &TargetId);
							void *MonsterPointer = Server::CMonster::FindMonster(TargetId);
							Monster *monster = new Monster(MonsterPointer);
							KPlayer *player = new KPlayer(PlayerPointer);
							result = (int) MonsterPointer;


								if(MonsterPointer)
								{

									 int PlayerMaxHP = Server::CChar::GetMaxHp(PlayerPointer);
									 (*(void (__cdecl **)(void *, signed int, signed int, int))
									 //(*(void (__cdecl **)(void*, int, int, int))
									 (*(DWORD*)PlayerPointer + 88))(PlayerPointer, 7, 1, PlayerMaxHP / 20);

									  int PlayerMaxMP = Server::CChar::GetMaxMp(PlayerPointer);
									 (*(void (__cdecl **)(void *, signed int, signed int, int))
									 //(*(void (__cdecl **)(void*, int, int, int))
									 (*(DWORD*)PlayerPointer + 88))(PlayerPointer, 8, 1, PlayerMaxMP / 20);

									 Server::CChar::CChar__SetDirection(PlayerPointer, 
										 monster->GetXCoord() - player->GetXCoord() , 
										 monster->GetYCoord() - player->GetYCoord() );

									 PlayerID = Server::CBase::Id(PlayerPointer);
									 TargetID = Server::CBase::Id(MonsterPointer);
									 Server::CChar::WriteInSight(PlayerPointer,0x3F, "bddbb", 1, PlayerID, TargetID, 0, 1);

									 MonsterID = Server::CBase::Id(MonsterPointer);
									 Server::CChar::WriteInSight(MonsterPointer, 0x3D, "db", MonsterID, 0xA);
									 Server::CBase::Delete(MonsterPointer);
									// result = Server::CIOObject::ObjectRelease(MonsterPointer, LONG(MonsterID) + 0x160);
										 //ReleaseN(MonsterPointer, monster->GetRelease());
							}
								                


						//delete player; player = 0;
						return result;
}


		

#pragma endregion


		int __fastcall Hooked_ExecuteSkill(void* PlayerCSkill, void *edx_, signed int SkillID, int PacketPointer,int PositionPointer)
        {
					void* PlayerPointer = (void*)*(DWORD*)(int)PlayerCSkill;
					int Class = *(DWORD*)((int)PlayerPointer + 460);
					KPlayer *player = new KPlayer(PlayerCSkill);
					int result; 
					result = Server::CSkill::ExecuteSkill(PlayerCSkill, SkillID, PacketPointer, PositionPointer);

					
					if(Class == KNIGHT)
					{
						if(SkillID == BEHEAD)
						{
							Knight_Behead((int*)PlayerPointer,(char*)PacketPointer,(char*)PositionPointer);	
						}
						if(SkillID == SPIN_SPLASH)
						{
							//Knight_SpinSplash((int*)PlayerPointer,(char*)PacketPointer,(char*)PositionPointer);	
						}
					}


					if(Class == MAGE)
					{
						if(SkillID == BEHEAD)
						{
						
						}
					}


					if(Class == ARCHER)
					{
						if(SkillID == BEHEAD)
						{
						
						}
					}

					if(Class == THIEF)
					{
						if(SkillID == RUN)
						{
							//Thief_Run((int*)PlayerPointer,(char*)PacketPointer,(char*)PositionPointer);	
						}
						if(SkillID == BEHEAD)
						{
							Thief_Behead((int*)PlayerPointer,(char*)PacketPointer,(char*)PositionPointer);		
						}

					}
					return result;
		}
}