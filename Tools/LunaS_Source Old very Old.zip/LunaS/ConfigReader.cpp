#include "StdAfx.h"

#include <string>
#include <fstream>



#include "ConfigReader.h"


// (meow (blow (this "shit") (off 511845)) (moo (kikoo "lol") (wtf "omg")))

DBSection::DBSection(std::string Name, std::string _Section) : _sValue(""), _Name(Name)
{

	this->_vfValues.clear();
	this->_SectionList.clear();

	bool InString = false;
	bool ValueOnly = true;
	std::string Key;

	// Searching for possible subsections
	for(size_t i=1; i < _Section.size(); i++)
	{
		if (_Section[i] == '"') InString = !InString;
		if ((_Section[i] == '(') && (!InString)) { ValueOnly = false; break; }
	}

	// Parsing Section name
	bool __found = false;
	for(size_t i=0, begin=0; i < _Section.size(); i++)
	{
		char c = _Section[i];
		if (c != '(' && c != ')' && c != ' ' && c != '\t' && c != '\r' && c != '\n')
		{
			if (!__found)
			{
				begin = i;
				__found = true;
			}
		}
		else
		{
			if (__found) { Key = _Section.substr(begin, i-begin); break; }
		}
	}

	__found = false;
	if (ValueOnly) // Parsing value
	{
		size_t offset = _Section.find(Key) + Key.length();
		size_t str_offset = _Section.find('"', offset);
		// Check if string
		if (str_offset != std::string::npos)
		{
			size_t str_end = _Section.find('"', str_offset+1);
			this->_sValue = _Section.substr(str_offset, str_end-str_offset+1);
			this->_Name = Key;
		}
	}

	else // Parsing subsections
	{
		size_t Depth = 0;
		InString = false;
		for(size_t last=1, i=1, current=0; i < _Section.length(); i++, current++)
		{
			char c = _Section[i];
			if (c == '"') InString = !InString;

			if (!InString)
			{
				if (c == '(')
				{
					Depth++;
					if (Depth == 1) { last = i; current = 0; }
				}
				else if (c == ')')
				{
					Depth--;
					if (Depth == 0)
					{
						this->_Name = Key;
						this->_SectionList.push_back(new DBSection(Key, _Section.substr(last, current+1)));
						current = 0;
					}
					if (Depth == -1) break;
				}
			}
		}
	}
}

DBSection::~DBSection()
{
	for(size_t i=0; i < this->_SectionList.size(); i++)
		delete this->_SectionList[i];
}

size_t DBSection::Size() { return this->_SectionList.size(); }
DBSection *DBSection::Get(std::string Section)
{
	for(size_t i=0; i < this->_SectionList.size(); i++)
		if (this->_SectionList[i]->_Name == Section) return this->_SectionList[i];
	return NULL;
}
DBSection *DBSection::Get(size_t Offset)
{
	if (this->_SectionList.size() < Offset) return NULL;
	else return this->_SectionList[Offset];
}

std::string DBSection::GetString()
{
	return this->_sValue;
}
double DBSection::GetFloat()
{
	return this->_vfValues[0];
}
int DBSection::GetInt()
{
	return (int)this->_vfValues[0];
}
std::vector<double> DBSection::GetArray()
{
	std::vector<double> _vNew = this->_vfValues;
	return _vNew;
}
std::string DBSection::GetName()
{
	return this->_Name;
}

DBSection& DBSection::operator[](const std::string& Section)
{
	DBSection *Ret = NULL;;
	for(size_t i=0; i < this->_SectionList.size(); i++)
		if (this->_SectionList[i]->_Name == Section) { Ret = this->_SectionList[i]; break; }

	if (!Ret) throw "Unexisting Section Name";
	return *Ret;
}
