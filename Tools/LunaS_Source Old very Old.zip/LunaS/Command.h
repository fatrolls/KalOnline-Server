#undef UNICODE
#include "stdafx.h"
#include <cstdio>
#include <windows.h>
#include "stdafx.h"
#include <process.h>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#pragma comment(lib, "KosaLib.lib")
#include <KServer.h>
#include <KPlayer.h>
#include <KCommand.h>
#include "IniReader.h"


	//CIniReader iniReader(".\\Commands.ini");
	//char *szName = iniReader.ReadString("Setting", "Name", "");   
	//int iAge = iniReader.ReadInteger("Setting", "Age", 25); 
	//float fltHieght = iniReader.ReadFloat("Setting", "Height", 1.80f); 
	//bool bMarriage = iniReader.ReadBoolean("Setting", "Marriage", true);
namespace Command
{
#pragma region INI Reader
	CIniReader iniReader(".\\.\\LunaS\\Commands.ini");
	bool OnOff = iniReader.ReadBoolean("Main", "Enabled", false);
	int TAdmin = iniReader.ReadInteger("TelePort_Option", "Admin", 0);
	char *TMessageName = iniReader.ReadString("TelePort_Option", "MessageName", "[Server]");
	char *AssasinMessage = iniReader.ReadString("TelePort_Option", "Assasin_Message", "#You can't teleport in Assasin mode.");
	int Move2Admin = iniReader.ReadInteger("Move2", "Admin", 0);
	char *Move2Command = iniReader.ReadString("Move2", "Command", "/move2");

	char *Command_01 = iniReader.ReadString("Teleport_01", "Command", "/Command1");
	int Map_01 = iniReader.ReadInteger("Teleport_01", "Map", 0);
	int X_01 = iniReader.ReadInteger("Teleport_01", "X", 0);
	int Y_01 = iniReader.ReadInteger("Teleport_01", "Y", 0);
	char *Message_01 = iniReader.ReadString("Teleport_01", "Message", "Teleported");


	char *Command_02 = iniReader.ReadString("Teleport_02", "Command", "/Command2");
	int Map_02 = iniReader.ReadInteger("Teleport_02", "Map", 0);
	int X_02 = iniReader.ReadInteger("Teleport_02", "X", 0);
	int Y_02 = iniReader.ReadInteger("Teleport_02", "Y", 0);
	char *Message_02 = iniReader.ReadString("Teleport_02", "Message", "Teleported");

	char *Command_03 = iniReader.ReadString("Teleport_03", "Command", "/Command3");
	int Map_03 = iniReader.ReadInteger("Teleport_03", "Map", 0);
	int X_03 = iniReader.ReadInteger("Teleport_03", "X", 0);
	int Y_03 = iniReader.ReadInteger("Teleport_03", "Y", 0);
	char *Message_03 = iniReader.ReadString("Teleport_03", "Message", "Teleported");

	char *Command_04 = iniReader.ReadString("Teleport_04", "Command", "/Command4");
	int Map_04 = iniReader.ReadInteger("Teleport_04", "Map", 0);
	int X_04 = iniReader.ReadInteger("Teleport_04", "X", 0);
	int Y_04 = iniReader.ReadInteger("Teleport_04", "Y", 0);
	char *Message_04 = iniReader.ReadString("Teleport_04", "Message", "Teleported");

	char *Command_05 = iniReader.ReadString("Teleport_05", "Command", "/Command5");
	int Map_05 = iniReader.ReadInteger("Teleport_05", "Map", 0);
	int X_05 = iniReader.ReadInteger("Teleport_05", "X", 0);
	int Y_05 = iniReader.ReadInteger("Teleport_05", "Y", 0);
	char *Message_05 = iniReader.ReadString("Teleport_05", "Message", "Teleported");

	char *Command_06 = iniReader.ReadString("Teleport_06", "Command", "/Command6");
	int Map_06 = iniReader.ReadInteger("Teleport_06", "Map", 0);
	int X_06 = iniReader.ReadInteger("Teleport_06", "X", 0);
	int Y_06 = iniReader.ReadInteger("Teleport_06", "Y", 0);
	char *Message_06 = iniReader.ReadString("Teleport_06", "Message", "Teleported");

	char *Command_07 = iniReader.ReadString("Teleport_07", "Command", "/Command7");
	int Map_07 = iniReader.ReadInteger("Teleport_07", "Map", 0);
	int X_07 = iniReader.ReadInteger("Teleport_07", "X", 0);
	int Y_07 = iniReader.ReadInteger("Teleport_07", "Y", 0);
	char *Message_07 = iniReader.ReadString("Teleport_07", "Message", "Teleported");

	char *Command_08 = iniReader.ReadString("Teleport_08", "Command", "/Command8");
	int Map_08 = iniReader.ReadInteger("Teleport_08", "Map", 0);
	int X_08 = iniReader.ReadInteger("Teleport_08", "X", 0);
	int Y_08 = iniReader.ReadInteger("Teleport_08", "Y", 0);
	char *Message_08 = iniReader.ReadString("Teleport_08", "Message", "Teleported");

	char *Command_09 = iniReader.ReadString("Teleport_09", "Command", "/Command9");
	int Map_09 = iniReader.ReadInteger("Teleport_09", "Map", 0);
	int X_09 = iniReader.ReadInteger("Teleport_09", "X", 0);
	int Y_09 = iniReader.ReadInteger("Teleport_09", "Y", 0);
	char *Message_09 = iniReader.ReadString("Teleport_09", "Message", "Teleported");

	char *Command_10 = iniReader.ReadString("Teleport_10", "Command", "/Command10");
	int Map_10 = iniReader.ReadInteger("Teleport_10", "Map", 0);
	int X_10 = iniReader.ReadInteger("Teleport_10", "X", 0);
	int Y_10 = iniReader.ReadInteger("Teleport_10", "Y", 0);
	char *Message_10 = iniReader.ReadString("Teleport_10", "Message", "Teleported");

	char *Command_11 = iniReader.ReadString("Teleport_11", "Command", "/Command11");
	int Map_11 = iniReader.ReadInteger("Teleport_11", "Map", 0);
	int X_11 = iniReader.ReadInteger("Teleport_11", "X", 0);
	int Y_11 = iniReader.ReadInteger("Teleport_11", "Y", 0);
	char *Message_11 = iniReader.ReadString("Teleport_11", "Message", "Teleported");

	char *Command_12 = iniReader.ReadString("Teleport_12", "Command", "/Command12");
	int Map_12 = iniReader.ReadInteger("Teleport_12", "Map", 0);
	int X_12 = iniReader.ReadInteger("Teleport_12", "X", 0);
	int Y_12 = iniReader.ReadInteger("Teleport_12", "Y", 0);
	char *Message_12 = iniReader.ReadString("Teleport_12", "Message", "Teleported");

	char *Command_13 = iniReader.ReadString("Teleport_13", "Command", "/Command13");
	int Map_13 = iniReader.ReadInteger("Teleport_13", "Map", 0);
	int X_13 = iniReader.ReadInteger("Teleport_13", "X", 0);
	int Y_13 = iniReader.ReadInteger("Teleport_13", "Y", 0);
	char *Message_13 = iniReader.ReadString("Teleport_13", "Message", "Teleported");

	char *Command_14 = iniReader.ReadString("Teleport_14", "Command", "/Command14");
	int Map_14 = iniReader.ReadInteger("Teleport_14", "Map", 0);
	int X_14 = iniReader.ReadInteger("Teleport_14", "X", 0);
	int Y_14 = iniReader.ReadInteger("Teleport_14", "Y", 0);
	char *Message_14 = iniReader.ReadString("Teleport_14", "Message", "Teleported");

	char *Command_15 = iniReader.ReadString("Teleport_15", "Command", "/Command15");
	int Map_15 = iniReader.ReadInteger("Teleport_15", "Map", 0);
	int X_15 = iniReader.ReadInteger("Teleport_15", "X", 0);
	int Y_15 = iniReader.ReadInteger("Teleport_15", "Y", 0);
	char *Message_15 = iniReader.ReadString("Teleport_15", "Message", "Teleported");

	char *Command_16 = iniReader.ReadString("Teleport_16", "Command", "/Command16");
	int Map_16 = iniReader.ReadInteger("Teleport_16", "Map", 0);
	int X_16 = iniReader.ReadInteger("Teleport_16", "X", 0);
	int Y_16 = iniReader.ReadInteger("Teleport_16", "Y", 0);
	char *Message_16 = iniReader.ReadString("Teleport_16", "Message", "Teleported");

	char *Command_17 = iniReader.ReadString("Teleport_17", "Command", "/Command17");
	int Map_17 = iniReader.ReadInteger("Teleport_17", "Map", 0);
	int X_17 = iniReader.ReadInteger("Teleport_17", "X", 0);
	int Y_17 = iniReader.ReadInteger("Teleport_17", "Y", 0);
	char *Message_17 = iniReader.ReadString("Teleport_17", "Message", "Teleported");

	char *Command_18 = iniReader.ReadString("Teleport_18", "Command", "/Command18");
	int Map_18 = iniReader.ReadInteger("Teleport_18", "Map", 0);
	int X_18 = iniReader.ReadInteger("Teleport_18", "X", 0);
	int Y_18 = iniReader.ReadInteger("Teleport_18", "Y", 0);
	char *Message_18 = iniReader.ReadString("Teleport_18", "Message", "Teleported");

	char *Command_19 = iniReader.ReadString("Teleport_19", "Command", "/Command19");
	int Map_19 = iniReader.ReadInteger("Teleport_19", "Map", 0);
	int X_19 = iniReader.ReadInteger("Teleport_19", "X", 0);
	int Y_19 = iniReader.ReadInteger("Teleport_19", "Y", 0);
	char *Message_19 = iniReader.ReadString("Teleport_19", "Message", "Teleported");

	char *Command_20 = iniReader.ReadString("Teleport_20", "Command", "/Command10");
	int Map_20 = iniReader.ReadInteger("Teleport_20", "Map", 0);
	int X_20 = iniReader.ReadInteger("Teleport_20", "X", 0);
	int Y_20 = iniReader.ReadInteger("Teleport_20", "Y", 0);
	char *Message_20 = iniReader.ReadString("Teleport_20", "Message", "Teleported");

	int GAdmin = iniReader.ReadInteger("Geon", "Admin", 0);
	char *GeonCommand = iniReader.ReadString("Geon", "Command", "/geon");


	#define BLESSING_OF_STRENGTH  46
    #define BLESSING_OF_HEALTH 47
	#define BLESSING_OF_AGILITY 48
	#define BLESSING_OF_INTELLIGENCE 49
	#define BLESSING_OF_CRITICALHIT 50
	#define DEFENCE_IMPROVEMENT 37
	#define REFINE_WEAPON 36
	#define SPEED 12

	int BAdmin = iniReader.ReadInteger("Buff_System", "Admin", 0);
	char *BuffCommand = iniReader.ReadString("Buff_System", "Command", "/buff");
	char *CustomBuffCommand = iniReader.ReadString("Buff_System", "CustomCommand", "/cbuff");
	char *BMessageName = iniReader.ReadString("Buff_System", "MessageName", "[Server]");
	char *BuffPlayerMessage = iniReader.ReadString("Buff_System", "Message", "Buffed");

	bool StrengthEnabled = iniReader.ReadBoolean("Buff_System", "Blessing_Of_Strength", false);
	int StrengthCoolDown = iniReader.ReadInteger("Buff_System", "Blessing_Of_Strength_CoolDown", 1800);
	int StrengthStatIncrease = iniReader.ReadInteger("Buff_System", "Blessing_Of_Strength_StatIncrease", 50);

	bool HealthEnabled = iniReader.ReadBoolean("Buff_System", "Blessing_Of_Health", false);
	int HealthCoolDown = iniReader.ReadInteger("Buff_System", "Blessing_Of_Health_CoolDown", 1800);
	int HealthStatIncrease = iniReader.ReadInteger("Buff_System", "Blessing_Of_Health_StatIncrease", 50);

	bool AgilityEnabled = iniReader.ReadBoolean("Buff_System", "Blessing_Of_Agility", false);
	int AgilityCoolDown = iniReader.ReadInteger("Buff_System", "Blessing_Of_Agility_CoolDown", 1800);
	int AgilityStatIncrease = iniReader.ReadInteger("Buff_System", "Blessing_Of_Agility_StatIncrease", 50);

	bool IntelligenceEnabled = iniReader.ReadBoolean("Buff_System", "Blessing_Of_Intelligence", false);
	int IntelligenceCoolDown = iniReader.ReadInteger("Buff_System", "Blessing_Of_Intelligence_CoolDown", 1800);
	int IntelligenceStatIncrease = iniReader.ReadInteger("Buff_System", "Blessing_Of_Intelligence_StatIncrease", 50);

	bool CriticalHitEnabled = iniReader.ReadBoolean("Buff_System", "Blessing_Of_CriticalHit", false);
	int CriticalHitCoolDown = iniReader.ReadInteger("Buff_System", "Blessing_Of_CriticalHit_CoolDown", 1800);
	int CriticalHitStatIncrease = iniReader.ReadInteger("Buff_System", "Blessing_Of_CriticalHit_StatIncrease", 50);

	bool DefenceImprovementEnabled = iniReader.ReadBoolean("Buff_System", "Defence_Improvement", false);
	int DefenceImprovementCoolDown = iniReader.ReadInteger("Buff_System", "Defence_Improvement_CoolDown", 1800);
	int DefenceImprovementStatIncrease = iniReader.ReadInteger("Buff_System", "Defence_Improvement_StatIncrease", 50);

	bool RefineWeaponEnabled = iniReader.ReadBoolean("Buff_System", "Refine_Weapon", false);
	int RefineWeaponCoolDown = iniReader.ReadInteger("Buff_System", "Refine_Weapon_CoolDown", 1800);
	int RefineWeaponStatIncrease = iniReader.ReadInteger("Buff_System", "Refine_Weapon_StatIncrease", 50);

	bool SpeedEnabled = iniReader.ReadBoolean("Buff_System", "Speed", false);
	int SpeedCoolDown = iniReader.ReadInteger("Buff_System", "Speed_CoolDown", 1800);
	int SpeedStatIncrease = iniReader.ReadInteger("Buff_System", "Speed_StatIncrease", 50);

	bool Custom1Enabled = iniReader.ReadBoolean("Buff_System", "CustomBuff_01", false);
	int Custom1Index = iniReader.ReadInteger("Buff_System", "CustomBuff_01_Index", 12);
	int Custom1CoolDown = iniReader.ReadInteger("Buff_System", "CustomBuff_01_CoolDown", 1800);
	int Custom1StatIncrease = iniReader.ReadInteger("Buff_System", "CustomBuff_01_StatIncrease", 50);

	bool Custom2Enabled = iniReader.ReadBoolean("Buff_System", "CustomBuff_02", false);
	int Custom2Index = iniReader.ReadInteger("Buff_System", "CustomBuff_02_Index", 12);
	int Custom2CoolDown = iniReader.ReadInteger("Buff_System", "CustomBuff_02_CoolDown", 1800);
	int Custom2StatIncrease = iniReader.ReadInteger("Buff_System", "CustomBuff_02_StatIncrease", 50);


	bool Custom3Enabled = iniReader.ReadBoolean("Buff_System", "CustomBuff_03", false);
	int Custom3Index = iniReader.ReadInteger("Buff_System", "CustomBuff_03_Index", 12);
	int Custom3CoolDown = iniReader.ReadInteger("Buff_System", "CustomBuff_03_CoolDown", 1800);
	int Custom3StatIncrease = iniReader.ReadInteger("Buff_System", "CustomBuff_03_StatIncrease", 50);
	
#pragma endregion

void __fastcall Hooked_ChatCommand(void *thispointer, void *_edx, char *comm)
		{
			KCommand command(comm);
			KPlayer *player = new KPlayer(thispointer);

#pragma region Teleport_Command

			
				
	if(player->GetAdmin() >= Move2Admin)
		{
			if (command.beginWith(Move2Command))
					{

					std::string str = comm;
					std::string findm = ("-m");
					unsigned mval = str.find(findm)+3;
					std::string Stringmval = str.substr(mval);
					int mval1 = atoi(Stringmval.c_str());

					std::string findx = ("-x");
					unsigned xval = str.find(findx)+3;
					std::string Stringxval = str.substr(xval);
					int xval1 = atoi(Stringxval.c_str());

					std::string findy = ("-y");
					unsigned yval = str.find(findy)+3;
					std::string Stringyval = str.substr(yval);
					int yval1 = atoi(Stringyval.c_str());

					if(xval1 <= 0)
					{
						player->PlayerMessage("Server", "#You have to set the X Coordinate.");
					}
						if(yval1 <= 0)
						{
							player->PlayerMessage("Server", "#You have to set the Y Coordinate.");
						}

							if(xval1 > 0 && yval1 > 0)
							{
								player->Teleport(mval1, xval1, yval1);
								player->PlayerMessage("Server", "*You are successfully teleported.");
							}


		
			}
	}


			if(player->GetAdmin() >= TAdmin)
			{
				


				if (command.beginWith(Command_01) && player->GetGState() != 256)
					{
						player->Teleport(Map_01,X_01,Y_01);
						player->PlayerMessage(TMessageName, Message_01);
					}
				else if(command.beginWith(Command_01) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};
				

				if (command.beginWith(Command_02) && player->GetGState() != 256)
					{
						player->Teleport(Map_02,X_02,Y_02);
						player->PlayerMessage(TMessageName, Message_02);

					}
				else if(command.beginWith(Command_02) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};


				if (command.beginWith(Command_03) && player->GetGState() != 256)
					{
						player->Teleport(Map_03,X_03,Y_03);
						player->PlayerMessage(TMessageName, Message_03);
					}
				else if(command.beginWith(Command_03) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};


				if (command.beginWith(Command_04) && player->GetGState() != 256)
					{
						player->Teleport(Map_04,X_04,Y_04);
						player->PlayerMessage(TMessageName, Message_04);
					}
				else if(command.beginWith(Command_04) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};


				if (command.beginWith(Command_05) && player->GetGState() != 256)
					{
						player->Teleport(Map_05,X_05,Y_05);
						player->PlayerMessage(TMessageName, Message_05);
					}
				else if(command.beginWith(Command_05) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};


				if (command.beginWith(Command_06) && player->GetGState() != 256)
					{
						player->Teleport(Map_06,X_06,Y_06);
						player->PlayerMessage(TMessageName, Message_06);
					}
				else if(command.beginWith(Command_06) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};


				if (command.beginWith(Command_07) && player->GetGState() != 256)
					{
						player->Teleport(Map_07,X_07,Y_07);
						player->PlayerMessage(TMessageName, Message_07);
					}
				else if(command.beginWith(Command_07) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};


				if (command.beginWith(Command_08) && player->GetGState() != 256)
					{
						player->Teleport(Map_08,X_08,Y_08);
						player->PlayerMessage(TMessageName, Message_08);

					}
				else if(command.beginWith(Command_08) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};


				if (command.beginWith(Command_09) && player->GetGState() != 256)
					{
						player->Teleport(Map_09,X_09,Y_09);
						player->PlayerMessage(TMessageName, Message_09);
					}
				else if(command.beginWith(Command_09) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};


				if (command.beginWith(Command_10) && player->GetGState() != 256)
					{
						player->Teleport(Map_10,X_10,Y_10);
						player->PlayerMessage(TMessageName, Message_10);
					}
				else if(command.beginWith(Command_10) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};

				if (command.beginWith(Command_11) && player->GetGState() != 256)
					{
						player->Teleport(Map_11,X_11,Y_11);
						player->PlayerMessage(TMessageName, Message_11);
					}
				else if(command.beginWith(Command_11) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};

				if (command.beginWith(Command_12) && player->GetGState() != 256)
					{
						player->Teleport(Map_12,X_12,Y_12);
						player->PlayerMessage(TMessageName, Message_12);
					}
				else if(command.beginWith(Command_12) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};

				if (command.beginWith(Command_13) && player->GetGState() != 256)
					{
						player->Teleport(Map_13,X_13,Y_13);
						player->PlayerMessage(TMessageName, Message_13);
					}
				else if(command.beginWith(Command_13) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};

				if (command.beginWith(Command_14) && player->GetGState() != 256)
					{
						player->Teleport(Map_14,X_14,Y_14);
						player->PlayerMessage(TMessageName, Message_14);
					}
				else if(command.beginWith(Command_14) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};

				if (command.beginWith(Command_15) && player->GetGState() != 256)
					{
						player->Teleport(Map_15,X_15,Y_15);
						player->PlayerMessage(TMessageName, Message_15);
					}
				else if(command.beginWith(Command_15) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};

				if (command.beginWith(Command_16) && player->GetGState() != 256)
					{
						player->Teleport(Map_16,X_16,Y_16);
						player->PlayerMessage(TMessageName, Message_16);
					}
				else if(command.beginWith(Command_16) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};

				if (command.beginWith(Command_17) && player->GetGState() != 256)
					{
						player->Teleport(Map_17,X_17,Y_17);
						player->PlayerMessage(TMessageName, Message_17);
					}
				else if(command.beginWith(Command_17) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};

				if (command.beginWith(Command_18) && player->GetGState() != 256)
					{
						player->Teleport(Map_18,X_18,Y_18);
						player->PlayerMessage(TMessageName, Message_18);
					}
				else if(command.beginWith(Command_18) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};

				if (command.beginWith(Command_19) && player->GetGState() != 256)
					{
						player->Teleport(Map_19,X_19,Y_19);
						player->PlayerMessage(TMessageName, Message_19);
					}
				else if(command.beginWith(Command_19) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};

				if (command.beginWith(Command_20) && player->GetGState() != 256)
					{
						player->Teleport(Map_20,X_20,Y_20);
						player->PlayerMessage(TMessageName, Message_20);
					}
				else if(command.beginWith(Command_20) && player->GetGState() == 256)
				{
						player->PlayerMessage(TMessageName, AssasinMessage);
				};



	}
#pragma endregion
				//Server::Console::Print(%i %i %i %i,a1,a2,a3,a4);

#pragma region Geon/BuffCommand



			if(player->GetAdmin() >= GAdmin)
				{

				if (command.beginWith(GeonCommand))
				{
					std::string str = comm;
					std::string find = ("-a");
					unsigned geonval = str.find(find)+2;
					std::string StringGeonval = str.substr(geonval);
					int geonval1 = atoi(StringGeonval.c_str());

					player->InsertItem(31, geonval1);
				}

			}


			if(player->GetAdmin() >= BAdmin)
			{
				if (command.beginWith("/help"))
				{
					player->PlayerMessage("Server-Help","*LunaS Command Information's");
					player->PlayerMessage(CustomBuffCommand,"*-id for Buff ID // -cd for Buff CoolDown // -ic for Buff Stat Increase");
					player->PlayerMessage(Move2Command,"*-m for Map // -x for X Coordinate // -y for Y Coordinate");
				}


				if (command.beginWith(CustomBuffCommand))
				{

					std::string str = comm;
					std::string findid = ("-id");
					unsigned idval = str.find(findid)+3;
					std::string Stringidval = str.substr(idval);
					int idval1 = atoi(Stringidval.c_str());

					std::string findcd = ("-cd");
					unsigned cdval = str.find(findcd)+3;
					std::string Stringcdval = str.substr(cdval);
					int cdval1 = atoi(Stringcdval.c_str());

					std::string findic = ("-ic");
					unsigned icval = str.find(findic)+3;
					std::string Stringicval = str.substr(icval);
					int icval1 = atoi(Stringicval.c_str());

					if(idval1 <= 0)
					{
						player->PlayerMessage("Server", "#You have to set a Buff ID.");
					}
						if(cdval1 <= 0)
						{
							player->PlayerMessage("Server", "#You have to set a CoolDown Value.");
						}
							if(icval1 <= 0)
							{
								player->PlayerMessage("Server", "#You have to set a Stat Increase Value.");
							}


			if(idval1 > 0 && cdval1 > 0 && icval1 > 0)
			{
					Server::CIOCriticalSection::Enter((void*)0x4e2078);
					Server::CIOCriticalSection::Enter((void*)0x4e2098);
					Server::CIOCriticalSection::MoveTo((void*)0x4e200c,(int)0x4e2004);
					Server::CIOCriticalSection::Leave((void*)0x4e2098);
					void* PlayerPointer = 0;
					for ( unsigned long i = *(unsigned long*)0x4e2004; i != 0x4e2004; i = *(unsigned long*)i)
						{
							PlayerPointer = (void*)(i-428);

								player->CancelBuff(PlayerPointer,idval1);
								player->Buff(PlayerPointer, idval1, cdval1, icval1);

					}
					Server::CIOCriticalSection::Leave((void*)0x4e2078);

			}

				}




				if(command.beginWith(BuffCommand))
				{
					Server::CIOCriticalSection::Enter((void*)0x4e2078);
					Server::CIOCriticalSection::Enter((void*)0x4e2098);
					Server::CIOCriticalSection::MoveTo((void*)0x4e200c,(int)0x4e2004);
					Server::CIOCriticalSection::Leave((void*)0x4e2098);
					void* PlayerPointer = 0;
					for ( unsigned long i = *(unsigned long*)0x4e2004; i != 0x4e2004; i = *(unsigned long*)i)
						{
							PlayerPointer = (void*)(i-428);
							
							if(StrengthEnabled == true)
							{
								player->CancelBuff(PlayerPointer,BLESSING_OF_STRENGTH);
								player->Buff(PlayerPointer, BLESSING_OF_STRENGTH, StrengthCoolDown, StrengthStatIncrease);
							}
							if(HealthEnabled == true)
							{
								player->CancelBuff(PlayerPointer,BLESSING_OF_HEALTH);
								player->Buff(PlayerPointer, BLESSING_OF_HEALTH, HealthCoolDown, HealthStatIncrease);
							}
							if(AgilityEnabled == true)
							{
								player->CancelBuff(PlayerPointer,BLESSING_OF_AGILITY);
								player->Buff(PlayerPointer, BLESSING_OF_AGILITY, AgilityCoolDown, AgilityStatIncrease);
							}
							if(IntelligenceEnabled == true)
							{
								player->CancelBuff(PlayerPointer,BLESSING_OF_INTELLIGENCE);
								player->Buff(PlayerPointer, BLESSING_OF_INTELLIGENCE, IntelligenceCoolDown, IntelligenceStatIncrease);
							}
							if(CriticalHitEnabled == true)
							{
								player->CancelBuff(PlayerPointer,BLESSING_OF_CRITICALHIT);
								player->Buff(PlayerPointer, BLESSING_OF_CRITICALHIT, CriticalHitCoolDown, CriticalHitStatIncrease);
							}
							if(DefenceImprovementEnabled == true)
							{
								player->CancelBuff(PlayerPointer,DEFENCE_IMPROVEMENT);
								player->Buff(PlayerPointer, DEFENCE_IMPROVEMENT, DefenceImprovementCoolDown, DefenceImprovementStatIncrease);
							}
							if(RefineWeaponEnabled == true)
							{
								player->CancelBuff(PlayerPointer,REFINE_WEAPON);
								player->Buff(PlayerPointer, REFINE_WEAPON, RefineWeaponCoolDown, RefineWeaponStatIncrease);
							}
							if(SpeedEnabled == true)
							{
								player->CancelBuff(PlayerPointer,SPEED);
								player->Buff(PlayerPointer, SPEED, SpeedCoolDown, SpeedStatIncrease);
							}
							if(Custom1Enabled == true)
							{
								player->CancelBuff(PlayerPointer,Custom1Index);
								player->Buff(PlayerPointer, Custom1Index, Custom1CoolDown, Custom1StatIncrease);
							}
							if(Custom2Enabled == true)
							{
								player->CancelBuff(PlayerPointer,Custom2Index);
								player->Buff(PlayerPointer, Custom2Index, Custom2CoolDown, Custom2StatIncrease);
							}
							if(Custom3Enabled == true)
							{
								player->CancelBuff(PlayerPointer,Custom3Index);
								player->Buff(PlayerPointer, Custom3Index, Custom3CoolDown, Custom3StatIncrease);
							}

							player->PlayerMessage(BMessageName ,BuffPlayerMessage);
					}
					Server::CIOCriticalSection::Leave((void*)0x4e2078);
		}

}
#pragma endregion





			Server::CPlayer::ChatCommand(thispointer,comm);
		}

	void EnabledMessage()
	 {
		if(Command::OnOff == false)
			{
				Server::Console::WriteRed("[LunaS] --> Command System Disabled.");
			};
		if(Command::OnOff == true)
			{
				Server::Console::WriteBlue("[LunaS] --> Command System Enabled.");
			};
	 }

};