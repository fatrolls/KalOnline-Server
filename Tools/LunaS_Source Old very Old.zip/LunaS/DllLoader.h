#include <vector>
#include <string>


class IPlugins
{
public:
IPlugins();
void Load();
};
