#ifndef __DEFLECT_H
#define __DEFLECT_H

namespace Deflection
{
	enum
	{
		CSocketProcess,
		CPlayerWrite,
		MonsterBlob,
	};
}

#endif