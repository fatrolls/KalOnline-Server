#include "StdAfx.h"

#include "Interface.h"

// Symbol definition
InterfaceManager *InterfaceManager::_pInstance = NULL;