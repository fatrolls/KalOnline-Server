#ifndef __SERVER_H
#define __SERVER_H

namespace Server
{
	namespace CSocket
	{
		static void (__thiscall *Process)(void *Socket, const char* Data) = (void (__thiscall*)(void*, const char*))0x00494930;
		static void (__cdecl *Write)(void *Socket, unsigned char Type, const char* Format, ...) = (void (__cdecl*)(void*, unsigned char, const char*, ...))0x004948c0;
	}
	namespace CPlayer
	{
		static void (__cdecl *Write)(void *Player, unsigned char Type, const char* Format, ...) = (void (__cdecl*)(void*, unsigned char, const char*, ...))0x00452e60;
		static char* (__thiscall *GetGuildName)(void *Player) = (char* (__thiscall*)(void*))0x0046acd0;
		static char* (__thiscall *GetGuildClassTitle)(void *Player) = (char* (__thiscall*)(void*))0x0046ad70;
		static unsigned long (__cdecl *FindPlayer)(void *Player) = (unsigned long (__cdecl*)(void*))0x00450890;
		static int (__thiscall *IsPCBang)(void *Player) = (int (__thiscall*)(void*))0x0046c040;
		static void (__thiscall *Send)(void *Player, char* Data) = (void (__thiscall*)(void*, char*))0x00452e00;
	}
	namespace CChar
	{
		static void (__thiscall *Lock)(void *Char) = (void (__thiscall*)(void*))0x00412e90;
		static void (__thiscall *Unlock)(void *Char) = (void (__thiscall*)(void*))0x00412eb0;
		static int (__thiscall *IsGState)(void *Char, unsigned long State) = (int (__thiscall*)(void*, unsigned long))0x0040b310;
		static int (__thiscall *AddGState)(void *Char, unsigned long State) = (int (__thiscall*)(void*, unsigned long))0x00409910;
		static void (__cdecl *WriteInSight)(void *Char, unsigned char Type, const char* Format, ...) = (void (__cdecl*)(void*, unsigned char, const char*, ...))0x0040b9e0;
		static unsigned short (__thiscall *GetMaxMagic)(void *Char) = (unsigned short (__thiscall*)(void*))0x00458240;
		static unsigned short (__thiscall *GetMinMagic)(void *Char) = (unsigned short (__thiscall*)(void*))0x00458210;
		static unsigned short (__thiscall *GetMaxAttack)(void *Char) = (unsigned short (__thiscall*)(void*))0x0043d9d0;
		static unsigned short (__thiscall *GetMinAttack)(void *Char) = (unsigned short (__thiscall*)(void*))0x0043d9a0;
		static unsigned short (__thiscall *GetResist)(void *Char, unsigned char Type) = (unsigned short (__thiscall*)(void*, unsigned char))0x00438fa0;
	}
	namespace CObject
	{
		static long (__cdecl *WriteExclusive)(unsigned char Type, const char* Format, ...) = (long (__cdecl*)(unsigned char, const char*, ...))0x0044fce0;
	}
	namespace CMonster
	{
		static void (__thiscall *OnDelete)(void *Monster) = (void (__thiscall*)(void*))0x0043a3f0;
		static unsigned long (__thiscall *GetOperatorName)(void *Monster) = (unsigned long (__thiscall*)(void*))0x0043a720;
		static unsigned long (__thiscall *GetGuildName)(void *Monster) = (unsigned long (__thiscall*)(void*))0x00438eb0;
	}
	namespace CSMap
	{
		static unsigned long (__thiscall *GetCellMap)(void *_this, void*, void*) = (unsigned long (__thiscall*)(void*, void*, void*))0x00491360;
	}
	namespace CIOBuffer
	{
		static void (__thiscall *Release)(void *Buffer) = (void (__thiscall*)(void*))0x00401070;
	}
	namespace CBuff
	{
		static void* (__cdecl *CreateBuff)(int, int) = (void* (__cdecl*)(int, int))0x004402610;
	}
	namespace CDBSocket
	{
		static void (__cdecl *Write)(unsigned char Type, const char* Format, ...) = (void (__cdecl*)(unsigned char, const char*, ...))0x0040dc80;
	}
	namespace CIOCriticalSection
	{
		static void (__thiscall *Enter)(void *Section) = (void (__thiscall*)(void*))0x00423640;
		static void (__thiscall *Leave)(void *Section) = (void (__thiscall*)(void*))0x004236d0;
	}
	namespace CBase
	{
		static void* (__thiscall *Id)(void *base) = (void* (__thiscall*)(void*))0x00407760;
	}
	namespace CItem
	{
		static char* (__cdecl *PutByte)(char*, char) = (char* (__cdecl*)(char*, char))0x004189a0;
		static char* (__cdecl *PutWord)(char*, short) = (char* (__cdecl*)(char*, short))0x0042f960;
		static char* (__cdecl *PutDword)(char*, long) = (char* (__cdecl*)(char*, long))0x0044f9b0;
	}
	static void (__cdecl *WriteConsole)(const char*, ...) = (void (__cdecl*)(const char*, ...))0x004328c0;
	static char* (__cdecl *ReadPacketSecure)(char* Data, char* DataEnd, const char* Format, ...) = (char* (__cdecl*)(char*, char*, const char*, ...))0x004975f0;
}

#endif