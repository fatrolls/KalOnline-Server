#ifndef __KCOMMAND_H
#define __KCOMMAND_H

#pragma once
#include <string>
#include <vector>
using namespace std;
class KCommand
{
	private: 
	string command;
	vector<string> strvalues;
	vector<int> intvalues;

	public:
	KCommand(string command){this->command = command;}

	void SetCommStr(string x);
	bool beginWith(string begin);
	int GetIntValue(unsigned int offset);
	string GetStrValue(unsigned int offset);
	string GetFullStr();
};
#endif