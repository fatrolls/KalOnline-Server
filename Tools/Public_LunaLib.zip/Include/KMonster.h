#ifndef __KMONSTER_H
#define __KMONSTER_H
#include "KServer.h"

class KMonster
{
public:
	int* MonsterArray;
	KMonster(){};
	KMonster(int* PointerToArray);
	virtual ~KMonster();

	int* GetArray(void);
	void SetArray(int* PointerToArray);
	bool Check();

	int GetIndex();
	int GetPid();
	int GetPID();
	int GetX();
	int GetY();
	int GetDirection();
	int GetCurHp();
	int GetMaxHp();
	int GetGstate();
	int GetMstate();
	int GetRace();
	int GetGID();
};

#endif