#ifndef __DLL_LOADER_H
#define __DLL_LOADER_H
#include <Windows.h>
#include <string>
using namespace std;

class KLoader{
	private:
	public:
		void LoadDlls(wstring folderpath);
};
#endif