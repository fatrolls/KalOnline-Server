#ifndef __SERVER_H
#define __SERVER_H
#pragma comment(lib, "libeay32.lib")

#include <iostream>  
#include <sstream>  
#include <string>  
#include <iomanip>  
#include <stdio.h>  
#include <openssl/sha.h>  

#include <Windows.h>
#include <string>
#include <vector>
#include <fstream>  
#include <ctime>
#include "KPlayer.h"



#define ENTER_CRIT Server::CIOCriticalSection::Enter((void*)0x004e2078); Server::CIOCriticalSection::Enter((void*)0x004e2098); Server::CLink::MoveTo((void*)0x004e200c,(int)0x004e2004); Server::CIOCriticalSection::Leave((void*)0x004e2098);
#define GET_PLAYER_LIST for ( DWORD pp = *(DWORD*)0x004e2004; pp != 0x004e2004; pp = *(DWORD*)pp)
#define PLAYER_POINTER (int*)(pp-428)
#define LEAVE_CRIT Server::CIOCriticalSection::Leave((void*)0x004e2078);

#define ConsoleColAdr *(DWORD*)0x4D62A8

#define LUNA_CONST(x) const_cast<char*>(x.str().c_str())



using namespace std;
class KServer{
public:
	DWORD GetRealOffset(DWORD base, int arg);
	char* string_to_char(std::string content);
	int random(int low, int high);
	bool Success(int chance);
	void WriteLog(string FilePath, char* Message, ...);
	void ConsoleWrite(COLORREF Color, const char* Text, ...);
	void PartyBuffs(int* pPlayer, int* Skill, int BuffID, int SkillIndex, int BuffInc, char* PacketPointer, char* PositionPointer);
	void SetScreenInfo(int type, char* text, ...);
	void Notice(int color, char* text, ...);
	void SwitchNoticeType(string type, int color = 0);
	char* SwitchClass(int y);
	char* SwitchAdmin(int x);
	string ParseString(int* Playerptr, string str);
	bool replace(std::string& str, const std::string& from, const std::string& to);
	bool FilterBadWords(string& str, const string& word);
	bool FilterBadWords2(string str, string word);
	string GetSystemDate();
	string GetSystemTime();
	int GetSystemHour();
	int GetSystemMin();
	int GetSystemSec();
	int GetSystemday();
	string GetSystemDay();

	string sha256(const std::string str);
	void GetSha256_string_hash(unsigned char hash[SHA256_DIGEST_LENGTH], char outputBuffer[65]);
	int GetSha256_File_Hash(char* path, char output[65]);

	void GetPlayerList();

	void ChatLog(string FolderPath, char* Message, ...);
	string GetSystemDate1();
	int* GetPPtrFromPlayerList(string Name);
	int* GetPPtrFromPlayerList(int PID);
};



#pragma region strukts and enums
enum SummonType{
	Normal = 1, 
	Unique = 2, 
	Child = 3, 
	Skill = 4, 
	Pet = 5
};

enum ScreenInfoType{
	Blue = 0,
	Red = 1,
	Orange = 2,
};

enum GSTATE_TYPE{
	ASSASSIN = 256,
	PVP = 128,
	SITTING = 4,
	EGGTRANSFORM = 512,
};

enum CClass{
	Knight = 0,
	Mage = 1,
	Archer = 2,
	Thief = 3,
};

enum CSMapTile{
	SaveZone = 393216,
	CastleWar = 1048576,
};

enum ITEM_CLASS
{
  WEAPON = 0x0,
  DEFENSE = 0x1,
  ORNAMENT = 0x2,
  GENERAL = 0x3,
  QUEST = 0x4,
  MONEY = 0x5,
};

enum RESIST_TYPE
{
  FIRE = 0x0,
  ICE = 0x1,
  LITNING = 0x2,
  CURSE = 0x3,
  PALSY = 0x4,
};

enum ADMIN_TYPE
{
  USER = 0x0,
  SUPPORTER = 0x3,
  GM = 0x8,
  ADMIN = 0xb,
};

enum PROPERTY_TYPE{
  P_STR = 0x0,
  P_HTH = 0x1,
  P_INT = 0x2,
  P_WIS = 0x3,
  P_DEX = 0x4,
  P_HP = 0x5,
  P_MP = 0x6,
  P_CURHP = 0x7,
  P_CURMP = 0x8,
  P_HIT = 0x9,
  P_DODGE = 0xA,
  P_MINATTACK = 0xB,
  P_MAXATTACK = 0xC,
  P_MINMAGIC = 0xD,
  P_MAXMAGIC = 0xE,
  P_DEFENSE = 0xF,
  P_ABSORB = 0x10,
  P_ASPEED = 0x11,
  P_RESFIRE = 0x12,
  P_RESICE = 0x13,
  P_RESLITNING = 0x14,
  P_RESCURSE = 0x15,
  P_RESPALSY = 0x16,
  P_PUPOINT = 0x17,
  P_SUPOINT = 0x18,
  P_EXP = 0x19,
  P_LEVEL = 0x1A,
  P_MINMAXATTACK = 0x1B,
  P_MINMAXMAGIC = 0x1C,
  P_RESISTALL = 0x1D,
  P_DECREASE = 0x0,
  P_INCREASE = 0x1,
};

enum CSkillIds{
	SpeedUp = 26,
	RefiningWeapon = 38,
	DefenseImprovement = 39,
};

enum TextColor{
	GRAY = RGB(190, 190, 190),
	RED = RGB(255, 0, 0),
	DARK_RED = RGB(139, 0, 0),
	ORANGE_RED = RGB(255, 69, 0),
	BLUE = RGB(0, 128, 255),
	DARK_BLUE = RGB(0, 0, 139),
	DARK_SKYBLUE = RGB(0, 178, 238),
	STEAL_BLUE = RGB(99, 184, 255),
	YELLOW = RGB(238, 238, 0),
	GREEN_YELLOW = RGB(173, 255, 47),
	ORANGE = RGB(255, 165, 0),
	DARK_ORANGE = RGB(255, 140, 0),
	GREEN = RGB(0, 255, 0),
	LIME_GREEN = RGB(50, 205, 50),
	DARK_GREEN = RGB(0, 100, 0),
	LAWN_GREEN = RGB(124, 252, 0),
	FOREST_GREEN = RGB(34, 139, 34),
	CYAN = RGB(0, 255, 255),
	DARK_CYAN = RGB(0, 139, 139),
	SADDLE_BROWN = RGB(139, 69, 19),
	SANDY_BROWN = RGB(244, 164, 96),
	PERU = RGB(205, 133, 63),
	MAGENTA = RGB(255, 0, 255),
	DARK_MAGENTA = RGB(139, 0, 139),
	DARK_ORCHID = RGB(153, 50, 204),
	PURPLE = RGB(160, 32, 240),
	DEEP_PURPLE = RGB(255, 20, 147),
	GOLD = RGB(255, 215, 0),
	DARK_GOLD = RGB(184, 134, 11),

	_GENERAL = RGB(255, 255, 255),
	INFOMSG = RGB(70, 227, 232),
	SHUTDOWN = RGB(240, 116, 15),
	FAILED = RGB(250, 210, 0),
	CLASSMATE = RGB(0, 128, 0),
	PARTY = RGB(210, 64, 0),
	GUILD = RGB(10, 255, 229),
	ALLIANCE = RGB(128, 128, 192),

	TEXTCOLOR_ORANGE = RGB(255, 128, 64),
	TEXTCOLOR_BLUE = RGB(0, 128, 255),
	TEXTCOLOR_YELLOW = RGB(255, 255, 128),
	TEXTCOLOR_RED = RGB(255, 0, 0),
	TEXTCOLOR_GREEN = RGB(0, 255, 0),
	TEXTCOLOR_DARKGREEN = RGB(0, 170, 0),
	TEXTCOLOR_PUPIL = RGB(255, 128, 64),
	TEXTCOLOR_PINK = RGB(255, 155, 255),
};

struct COORDINATES{
	int x;
	int y;
};

enum CHAR_KIND
{
  PLAYER = 0x0,
  MONSTER = 0x1,
  NPC = 0x2,
  HORSE = 0x3,
};

struct GenMonster{
 int s_gen[22];
 int dummy[4];
};

enum EXPORTS_TYPE{
	_SERVER = 0,
	_CLIENT = 1,
};

struct AFKCheckMap{
	int pid;
	int x;
	int y;
	ULONGLONG cd;
	bool Warning;
};

enum HonorNameColor{
	Admin = RGB(255, 69, 0),
	GameMaster = RGB(255, 215, 0),
	Supporter = RGB(0, 191, 255),
	User = RGB(255, 255, 255),
};

enum MyHonorRanks{
	Recruit = 1,
	Private = 2,
	Specialist = 3,
	Coperal = 4,
	Sergeant = 5,
	Lietenant = 6,
	Captain = 7,
	Major = 8,
	Colonel = 9,
	General = 10,
	_SUPORRT = 50,
	_GM = 51,
	_ADMIN = 52,
};

enum MyPHeader{
	HONOR_CHECK = 238,
	AUTO_LOGIN = 239,
	ADD_PARTICLE_EFFECT = 240,
	SCREEN_OVERLAY = 241,
	TOGGEL_CLIENT_CONSOLE = 242,
	SECURITY_CHECK = 243,
	SEND_HASH = 244,
	SET_SCREEN_INFO = 245,
	ADD_INFO_MESSAGE = 246,
	ADD_NOTICE_STRING = 247,
	INSERT_BUFF = 248,
	MESSAGE_BOX = 249,
	PROGRESS_BAR = 250,
};


enum MarkoNameColor{
	_Admin = RGB(255, 0, 255),
	_Donation = RGB(3, 5, 1),
	_GameMaster = RGB(255, 0, 0),
	_Supporter = RGB(94, 30, 225),
	_User = RGB(255, 255, 255),
};
#pragma endregion
struct Packet
{
	unsigned short Size;
	unsigned char Type;
	char Data[8000];
};

class PlayerList_Class
{
	public:
		int Uid;
		int Pid;
		string Name;
		int Admin;
		int Class;
		int Level;
};


class HonorMap
{
public:
	string PlayerName;
	int HonorRank;
};

extern vector<PlayerList_Class> PlayerList;
extern vector<PlayerList_Class>::iterator PlayerListIt;

namespace Server
{
	static int(__cdecl* GetDistance)(int X, int XX) = (int(__cdecl*)(int X, int XX))0x00448870;
	
	static unsigned __int32(__thiscall *Connect)(int _this) = (unsigned __int32(__thiscall*)(int))0x00494450;
	static int(__thiscall *sub_47E620)(int a4) = (int(__thiscall*)(int a4))0x0047E620;
	static int(__cdecl *sub_47E700)() = (int(__cdecl*)())0x0047E700;
	static void(__thiscall *sub_495B20)(int a5) = (void(__thiscall*)(int a5))0x00495B20;

	static signed int(__cdecl *ReadingConfigs)() = (signed int(__cdecl*)())0x0044BEF0;
	static int(__thiscall *sub_420060)(int thispointer, int a2, int a3) = (int(__thiscall*)(int thispointer, int a2, int a3))0x00420060;

	static void*(__thiscall *sub_4065D0)(void *thispointer, int a2, int a3, int a4, int a5, int a6, int a7) = (void*(__thiscall*)(void *thispointerpointer, int a2, int a3, int a4, int a5, int a6, int a7))0x004065D0;
	static int(__thiscall *sub_406090)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00406090;

	static int(__cdecl *unknown_libname_1)(size_t a1) = (signed int(__cdecl*)(size_t))0x00401000;

	namespace CIOServer{
		static int (__stdcall* Shutdown)(int) = (int(__stdcall*)(int))0x435500;
		static void (__stdcall *Start)(int start) = (void (__stdcall*)(int start))0x00424A40;
		static char* (__cdecl* ReadPacket)(char *PacketPointer, char *PositionPointer, const char *sFormat, ...) = (char* (__cdecl*)(char*, char*, const char*, ...))0x4975F0;
		static int(__thiscall *AccountLogin)(void *a, signed int a2, int a3, int a4, int a5, int a6, const void *a7) = (int(__thiscall *)(void *, signed int, int, int, int, int, const void *))0x00495770;
		
	}
	namespace CSocket
	{
		static void(__thiscall *Process)(void *Socket, const char* Data) = (void(__thiscall*)(void*, const char*))0x00494930;
		static void(__cdecl *Write)(void *Socket, unsigned char Type, const char* Format, ...) = (void(__cdecl*)(void*, unsigned char, const char*, ...))0x004948c0;
	}
	namespace CDBSocket{
		static int (__cdecl* Write)(BYTE type, char* Format, ...) = (int(__cdecl*)(BYTE,char*,...))0x0040DC80;
	}

	namespace CIOSocket
	{
		static void(__thiscall *Close)() = (void(__thiscall*)())0x00424260;
		static int(__thiscall *GracefulClose)(int a1) = (int(__thiscall*)(int))0x004242E0;
		static void(__thiscall *OnCreate)(int a1) = (void(__thiscall*)(int))0x004243D0;
		static void(__cdecl *Write)(void *Socket, unsigned char Type, const char* Format, ...) = (void(__cdecl*)(void *Socket, unsigned char Type, const char* Format, ...))0x00424760;
	}
	namespace CIOObject{
		static int (__thiscall *AddRef)(int object) = (int (__thiscall*)(int))0x004010D0; 
		static int (__thiscall *Release)(int object) = (int (__thiscall*)(int))0x00401DE0;
	}	
	namespace CObject
	{
		static void(__thiscall *CObjectDB)(int thispointer) = (void(__thiscall*)(int thispointer))0x00425C40;
		static long(__cdecl *WriteExclusive)(unsigned char Type, const char* Format, ...) = (long(__cdecl*)(unsigned char, const char*, ...))0x0044fce0;
		static signed int(__thiscall *Open)(int thispointer, const char *a2) = (signed int(__thiscall*)(int thispointer, const char *a2))0x0044C300;
		static int(__cdecl *FindSymbol)(char a1) = (int(__cdecl*)(char a1))0x0044C550;
		static signed int(__fastcall *Load)(void *a1, int a2, int a3) = (signed int(__fastcall*)(void *a1, int a2, int a3))0x0044C5A0;
		static int(__thiscall *Close)() = (int(__thiscall*)())0x0044C8D0;
		static LONG(__cdecl *CanReload)() = (LONG(__cdecl*)())0x0044C960;
	}
	namespace CIOCriticalSection{
		static void (__thiscall *Enter)(void *Section) = (void (__thiscall*)(void*))0x00423640;
		static void (__thiscall *Leave)(void *Section) = (void (__thiscall*)(void*))0x004236d0;
		static void (__thiscall* MoveTo)(void *Object,int x) = (void (__thiscall*)(void*,int))0x00438C40;
	}

	namespace CBase{
		static void* (__thiscall *Id)(void *base) = (void* (__thiscall*)(void*))0x00407760;
		static signed int (__thiscall *Delete)(void *thispointer) = (signed int (__thiscall*)(void *thispointerpointer))0x00411780; 
	}

	namespace BaseList{
		static void (__thiscall *Push)(int a5) = (void (__thiscall*)(int))0x004023F0; 
		static int(__thiscall* Pop)(void* unknown) = (int(__thiscall*)(void* unknown))0x00402430;
	}

	namespace CLink{
		static void (__thiscall* Initialize)(void *Object) = (void (__thiscall*)(void*))0x00438A60;
		static void (__thiscall* MoveTo)(void *Object,int x) = (void (__thiscall*)(void*,int))0x00438C40;
	}

	namespace Console{
		static BOOL (__cdecl* WriteBlack)(char* text,  ...) = (BOOL (__cdecl*)(char* text, ...))0x00432890;
		static BOOL (__cdecl* WriteRed)(char* text,  ...) = (BOOL (__cdecl*)(char* text, ...))0x004328C0;
		static BOOL (__cdecl* WriteBlue)(const char* text,  ...) = (BOOL (__cdecl*)(const char* text, ...))0x00432860;
		static BOOL (__cdecl* Write)(signed int a1, const char *a2, va_list a3) = (BOOL (__cdecl*)(signed int a1, const char *a2, va_list a3))0x00432530;
	}

	namespace CItem{
		//static int(__thiscall *CItemGeneral__Use)(int a5) = (int(__thiscall*)(int a5))0x0042CFB0;
		static int(__thiscall *Use)(int* ItemPtr, int* PlayerPtr) = (int(__thiscall*)(int*, int*))0x0042CFB0;//0x0045DD00;
		static LONG (__thiscall *SendItemInfo)(void *a5,int, char a6) = (LONG (__thiscall*)(void *a5, int, char a6))0x00427430; 
		static int(__thiscall *IsState)(int Itemptr, int State) = (int(__thiscall*)(int, int))0x00427130;
		static DWORD (__cdecl* FindPrefix)(BYTE Prefix) = (DWORD(__cdecl*)(BYTE))0x00425CB0;
		static DWORD (__cdecl* CreateItem)(int index, int prefix, int amount, int dummy) = (DWORD(__cdecl*)(int,int,int,int))0x00426110;
		static DWORD (__cdecl* CreateCheatItem)(int index, int prefix, int amount, int dummy) = (DWORD(__cdecl*)(int,int,int,int))0x00426170;
		static int  (__cdecl *CreateOwnItem)(int index, int prefix, int amount, int dummy) = (int (__cdecl*)(int,int,int,int))0x00426210 ;
		static int (__stdcall *InsertItem)(int thispointer, int type, int index, int amount, int prefix, int iid) = (int (__stdcall*)(int,int,int,int,int,int))0x004274A0;
		
	}

	namespace CItemTransform{
		static void(__thiscall *UpdateExp)(int *ItemArray, int *PlayerArray, int Type) = (void(__thiscall*)(int *ItemArray, int *PlayerArray, int Type))0x0042F030;
		static void (__thiscall *SaveInfo)(int,int a4) = (void (__thiscall*)(int,int a4))0x0042F2C0; 
	}

	namespace CPlayer{
		static void(__thiscall *Process)(int *Playerptr, int PacketHeader, char *Packet, char *Pos) = (void(__thiscall*)(int*, int, char *, char *))0x00452ED0;
		static signed int(__thiscall *CPlayer__OnLoadPlayer)(int a5) = (signed int(__thiscall*)(int a5))0x00456C40;
		static void* (__cdecl *Write)(void* Playerptr, unsigned char Type, const char* Format, ...) = (void* (__cdecl*)(void*, unsigned char, const char*, ...))0x00452e60;
		static void* (__cdecl *WriteAll)(unsigned char Type, const char* Format, ...) = (void* (__cdecl*)(unsigned char, const char*, ...))0x00450910;

		static void (__thiscall *Teleport)(int playerptr, int map, COORDINATES* Point, int a8,int a9) = (void (__thiscall*)(int, int, COORDINATES*, int, int))0x0045CC90; 
		static int (__thiscall* InsertItem)(unsigned int playerptr, int type, unsigned int itemptr) = (int (__thiscall*)(unsigned int, int, unsigned int))0x0045DDC0;
		static void* (__cdecl* FindPlayerbyID) (int nID) = (void* (__cdecl*) (int))0x00450810;
		static DWORD (__cdecl* FindPlayerbyName)(const char* sName) = (DWORD (__cdecl*)(const char*))0x00450890;
		
		static int (__thiscall* SendMail)(void*,int, int, char *, char, int, int, int, int, int, int) = (int (__thiscall*)(void*,int, int, char *, char, int, int, int, int, int, int))0x00468280;
		static int (__thiscall *LevelUp)(int* playerptr) = (int (__thiscall*)(int*))0x0045CC00;
		static int (__cdecl *UpdateProperty)(int* playerptr, int type, int DeIn, signed __int64 amount) = (int(__cdecl*)(int*, int, int, signed __int64))0x00458800;
		static void (__thiscall *SaveAllProperty)(void *playerptr, int a5) = (void (__thiscall*)(void*,int a5))0x004586A0;
		static void (__thiscall *MLMPayMoney)(void*,int a5) = (void (__thiscall*)(void*,int a5))0x00467080; 
		static void (__thiscall *MLMLevelUp)(void*) = (void (__thiscall*)(void*))0x004674D0; 
		static int (__thiscall *ChatCommand)(int *playerptr, const char *command) = (int (__thiscall*)(int*,const char*))0x00461080;
		static signed int (__thiscall *RemoveItem)(int* Playerptr, int Type, int Index, int Amount) = (signed int (__thiscall*)(int*, int, int, int))0x0045DA90; 
		static int (__thiscall *FindItem)(int *playerptr, int index, int amount) = (int (__thiscall*)(int*, int, int))0x0045D1E0; 
		static int(__thiscall *AddBuff)(int* playerptr, int buff) = (int(__thiscall*)(int* playerptr, int buff))0x0046B390;

		static int(__thiscall* ProcessMsg)(int* Playerptr, char* text) = (int(__thiscall*)(int*, char*))0x00460A50;

	}
	namespace CPlayerObject
	{
		static int(__stdcall *OnTimer)(int a1) = (int(__stdcall*)(int))0x0044FDD0;
	}

	namespace CPlayerSkill{
		static int(__thiscall *Execute)(int* playerptr, signed int nSkillID, char* PacketPointer, char* PositionPointer) = (int(__thiscall*)(int*, signed int, char*, char*))0x0047FBB0;
	}

	namespace CChar
	{
		static bool (__thiscall *IsNormal)(int thispointer) = (bool (__thiscall*)(int thispointer))0x0040B280; 
		static void (__thiscall *Lock)(void *Char) = (void (__thiscall*)(void*))0x00412e90;
		static void (__thiscall *Unlock)(void *Char) = (void (__thiscall*)(void*))0x00412eb0;
		static int (__thiscall *IsGState)(void *Char, unsigned long State) = (int (__thiscall*)(void*, unsigned long))0x0040b310;
		static int (__thiscall *AddGState)(void *Char, unsigned long State) = (int (__thiscall*)(void*, unsigned long))0x00409910;
		static void (__cdecl *WriteInSight)(void *Char, unsigned char Type, const char* Format, ...) = (void (__cdecl*)(void*, unsigned char, const char*, ...))0x0040b9e0;
		static unsigned short (__thiscall *GetMaxMagic)(void *Char) = (unsigned short (__thiscall*)(void*))0x00458240;
		static unsigned short (__thiscall *GetMinMagic)(void *Char) = (unsigned short (__thiscall*)(void*))0x00458210;
		static unsigned short (__thiscall *GetMaxAttack)(void *Char) = (unsigned short (__thiscall*)(void*))0x0043d9d0;
		static unsigned short (__thiscall *GetMinAttack)(void *Char) = (unsigned short (__thiscall*)(void*))0x0043d9a0;
		static bool (__thiscall* CheckHit) (void* pPlayer, void* pTarget, int arg) = (bool (__thiscall*) (void*, void*, int))0x43DA00;
		static int (__thiscall *GetMaxHp)(void *Char) = (int (__thiscall*)(void*))0x0043A200;
		static int (__thiscall *GetMaxMp)(void *Char) = (int (__thiscall*)(void*))0x0043AF90;
		static int (__thiscall *GetStr)(void *Char) = (int (__thiscall*)(void*))0x0043BE20;
		static int (__thiscall *GetHth)(void *Char) = (int (__thiscall*)(void*))0x0043BE60;
		static int (__thiscall *GetDex)(void *Char) = (int (__thiscall*)(void*))0x0043BF20;
		static int (__thiscall *GetInt)(void *Char) = (int (__thiscall*)(void*))0x0043BEA0;
		static int (__thiscall *GetWis)(void *Char) = (int (__thiscall*)(void*))0x0043BEE0;
		static int (__thiscall *GetHit)(void *Char) = (int (__thiscall*)(void*))0x0048E510;
		static int (__thiscall *GetDodge)(void *Char) = (int (__thiscall*)(void*))0x0043DB90;
		static int (__thiscall *GetDefense)(void *Char) = (int (__thiscall*)(void*))0x00438F30;
		static int (__thiscall *GetFinalDefense)(void *Char, int arg) = (int (__thiscall*)(void*, int))0x00451F40 ;
		static int (__thiscall *GetASpeed)(void *Char) = (int (__thiscall*)(void*))0x0043D8E0;
		static int (__thiscall *GetAbsorb)(void *Char) = (int (__thiscall*)(void*))0x00438F70;
		static int (__thiscall *GetAttack)(void *Char) = (int (__thiscall*)(void*))0x0043D970;
		static int (__thiscall *GetMagic)(void *Char) = (int (__thiscall*)(void*))0x004835F0;
		static unsigned short (__thiscall *GetResist)(void *Char, unsigned char Type) = (unsigned short (__thiscall*)(void*, unsigned char))0x00438fa0;
		static void (__cdecl *Write)(void *Player, unsigned char Type, const char* Format, ...) = (void (__cdecl*)(void*, unsigned char, const char*, ...))0x00452e60;
		static int (__cdecl* CreateBuff)(int BuffIndex, __int32 BuffCooldown, int StatIncrease, int a4) = (int (__cdecl*)(int,__int32,int,int))0x00402610;
		static void (__thiscall *CancelBuff)(int* ptr, int id) = (void (__thiscall*)(int*, int id))0x0040B6A0;
		static int(__thiscall *FindBuff)(int* Playerptr, int BuffID) = (int(__thiscall*)(int*, int))0x0040B4A0;
		static int (__thiscall *SetXY)(int* Pointer, COORDINATES* Coords) = (int (__thiscall*)(int*, COORDINATES*))0x0040B110; 
		static void (__thiscall *SetDirection)(void *thispointer, int a2, int a3) = (void (__thiscall*)(void *thispointerpointer, int a2, int a3))0x0040B180; 
	}

	namespace CBuff
	{
		static int(__cdecl* CreateBuff)(int BuffIndex, __int32 BuffCooldown, int StatIncrease, int a4) = (int(__cdecl*)(int, __int32, int, int))0x00402610;
		static int(__thiscall *CBuff)(int thispointer, int a2, int a3, int a4, int a5) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5))0x00405CA0;
		static int(__stdcall *UpdateBuff)(int a1, int a2) = (int(__stdcall*)(int a1, int a2))0x00402580;

		static int(__thiscall *CBuffMoveSpeed__CBuffMoveSpeed)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405C60;
		static int(__thiscall *CBuffStone__CBuffStone)(int thispointer, int a2, int a3, int a4, int a5) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5))0x00405CF0;
		static int(__thiscall *CBuffMeditation__CBuffMeditation)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405D30;
		static int(__thiscall *CBuffFatalChance__CBuffFatalChance)(int thispointer, int a2, int a3, int a4, int a5) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5))0x00405D70;
		static int(__thiscall *CBuffRevivalSequela__CBuffRevivalSequela)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405DB0;
		static int(__thiscall *CBuffStun__CBuffStun)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405DE0;
		static int(__thiscall *CBuffMoveStop__CBuffMoveStop)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405E20;
		static int(__thiscall *CBuffPoison__CBuffPoison)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405E60;
		static int(__thiscall *CBuffPoisonCloud__CBuffPoisonCloud)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405EB0;
		static int(__thiscall *CBuffHaste__CBuffHaste)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405F00;
		static int(__thiscall *CBuffHP__CBuffHP)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405F30;
		static int(__thiscall *CBuffMP__CBuffMP)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405F60;
		static int(__thiscall *CBuffSleep__CBuffSleep)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00405F90;
		static void(__thiscall *CBuffCTDefensePer__Copy)(void *thispointer) = (void(__thiscall*)(void *thispointerpointer))0x00406010;
		static void(__thiscall *CBuffCTDefensePer__CBuffCTDefensePer)(int thispointer, const void *a2) = (void(__thiscall*)(int thispointer, const void *a2))0x00406050;
		static void(__thiscall *CBuffCTHealing__Copy)(void *thispointer) = (void(__thiscall*)(void *thispointerpointer))0x004060D0;
		static void(__thiscall *CBuffCTHealing__CBuffCTHealing)(int thispointer, const void *a2) = (void(__thiscall*)(int thispointer, const void *a2))0x00406110;
		static void(__thiscall *CBuffCTPrtyPtEx__Copy)(void *thispointer) = (void(__thiscall*)(void *thispointerpointer))0x004061A0;
		static void(__thiscall *CBuffCTPrtyPtEx__CBuffCTPrtyPtEx)(int thispointer, const void *a2) = (void(__thiscall*)(int thispointer, const void *a2))0x004061E0;
		static int(__thiscall *CBuffSuffering__CBuffSuffering)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00406220;
		static int(__thiscall *CBuffInchantWeapon__CBuffInchantWeapon)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00406260;
		static int(__thiscall *CBuffSpiritDmg__CBuffSpiritDmg)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00406290;
		static int(__thiscall *CBuffFlagPrty__CBuffFlagPrty)(int thispointer, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9, int a10) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9, int a10))0x004062D0;
		static int(__thiscall *CBuffFlagHP__CBuffFlagHP)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x00406330;
		static int(__thiscall *CBuffBerserk__CBuffBerserk)(int thispointer, int a2, int a3, int a4, int a5) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5))0x00406360;
		static int(__thiscall *CBuffSilenceShot__CBuffSilenceShot)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x004063A0;
		static int(__thiscall *CBuffManaBurn__CBuffManaBurn)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x004063E0;
		static int(__thiscall *CBuffPrty__CBuffPrty)(int thispointer, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9, int a10) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9, int a10))0x00406420;
		static int(__thiscall *CBuffPrtyEx__CBuffPrtyEx)(int thispointer, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9, int a10) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9, int a10))0x00406490;
		static int(__thiscall *CBuffExpire__CBuffExpire)(int thispointer, int a2, int a3, int a4, int a5, int a6, int a7) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5, int a6, int a7))0x004064F0;
		static void(__thiscall *CBuffExpireEvent__CBuffExpireEvent)(void *thispointer, int a2, int a3, int a4, int a5, int a6) = (void(__thiscall*)(void *thispointerpointer, int a2, int a3, int a4, int a5, int a6))0x00406550;
		static void(__thiscall *CBuffExpireLuckyStone2__CBuffExpireLuckyStone2)(void *thispointer, int a2, int a3, int a4, int a5, int a6) = (void(__thiscall*)(void *thispointerpointer, int a2, int a3, int a4, int a5, int a6))0x00406590;
		static int(__thiscall *CBuffRemainEx__CBuffRemainEx)(int thispointer, int a2, int a3, int a4, int a5, int a6) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5, int a6))0x00406630;
		static int(__thiscall *CBuffRemain__CBuffRemain)(int thispointer) = (int(__thiscall*)(int thispointer))0x00406680;
		static int(__thiscall *CBuffRemainDead__CBuffRemainDead)(int thispointer, int a2, int a3, int a4, int a5, int a6) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5, int a6))0x004066A0;
		static int(__thiscall *CBuffRemainDeadEx__CBuffRemainDeadEx)(int thispointer, int a2, int a3, int a4, int a5) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5))0x004066F0;
		static void(__thiscall *CBuffRemainXBlow__CBuffRemainXBlow)(void *thispointer, int a2, int a3, int a4, int a5, int a6) = (void(__thiscall*)(void *thispointerpointer, int a2, int a3, int a4, int a5, int a6))0x00406730;
		static void(__thiscall *CBuffRemainPrty__CBuffRemainPrty)(void *thispointer, int a2, int a3, int a4, int a5, int a6, int a7) = (void(__thiscall*)(void *thispointerpointer, int a2, int a3, int a4, int a5, int a6, int a7))0x00406770;
		static void(__thiscall *CBuffRemainCount__CBuffRemainCount)(void *thispointer, int a2, int a3, int a4, int a5, int a6) = (void(__thiscall*)(void *thispointerpointer, int a2, int a3, int a4, int a5, int a6))0x004067B0;
		static void(__thiscall *CBuffRemainLuckyStone1__CBuffRemainLuckyStone1)(void *thispointer, int a2, int a3, int a4, int a5, int a6) = (void(__thiscall*)(void *thispointerpointer, int a2, int a3, int a4, int a5, int a6))0x004067F0;
		static int(__thiscall *CBuffRemainPet__CBuffRemainPet)(int thispointer, int a2, int a3) = (int(__thiscall*)(int thispointer, int a2, int a3))0x00406830;
		static signed int(__stdcall *CBuffRemainPet__SetBuff)(int a1) = (signed int(__stdcall*)(int a1))0x00406890;
		static int(__thiscall *CBuffHydrochloricAcid__CBuffHydrochloricAcid)(int thispointer, int a2, int a3, int a4) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4))0x004068B0;
		static int(__thiscall *CBuffMixDamage__CBuffMixDamage)(int thispointer, int a2, int a3, int a4, int a5) = (int(__thiscall*)(int thispointer, int a2, int a3, int a4, int a5))0x00406900;
		static bool(__thiscall *CBuff__IsExpired)(void *thispointer, int a2) = (bool(__thiscall*)(void *thispointerpointer, int a2))0x00406990;
		static signed int(__thiscall *CBuffMoveSpeed__ApplyBuff)(void *thispointer, int a2) = (signed int(__thiscall*)(void *thispointerpointer, int a2))0x004069C0;
		static int(__thiscall *CBuffMoveSpeed__FreeBuff)(int thispointer, int a2) = (int(__thiscall*)(int thispointer, int a2))0x00406A00;
		static signed int(__thiscall *CBuffMoveSpeed__UpdateBuff)(void *thispointer, int a2, int a3) = (signed int(__thiscall*)(void *thispointerpointer, int a2, int a3))0x00406A40;
		static int(__thiscall *CBuffMoveSpeed__IsExpired)(void *thispointer, int a2) = (int(__thiscall*)(void *thispointerpointer, int a2))0x00406BD0;
		static signed int(__thiscall *CBuffStone__ApplyBuff)(int thispointer, int a2) = (signed int(__thiscall*)(int thispointer, int a2))0x00406C20;
		static int(__thiscall *CBuffStone__FreeBuff)(int thispointer, int a2) = (int(__thiscall*)(int thispointer, int a2))0x00406C80;
		static signed int(__stdcall *CBuffMeditation__ApplyBuff)(int a1) = (signed int(__stdcall*)(int a1))0x00406CE0;
		static int(__stdcall *CBuffMeditation__FreeBuff)(int a1) = (int(__stdcall*)(int a1))0x00406D10;
		static bool(__thiscall *CBuffMeditation__IsExpired)(void *thispointer, int a2) = (bool(__thiscall*)(void *thispointerpointer, int a2))0x00406D30;
		static signed int(__thiscall *CBuffFatalChance__ApplyBuff)(int thispointer, int a2) = (signed int(__thiscall*)(int thispointer, int a2))0x00406E40;
		static int(__thiscall *CBuffFatalChance__FreeBuff)(int thispointer, int a2) = (int(__thiscall*)(int thispointer, int a2))0x00406EA0;
		static signed int(__thiscall *CBuffRevivalSequela__ApplyBuff)(int thispointer, int a2) = (signed int(__thiscall*)(int thispointer, int a2))0x00406EF0;
		static int(__thiscall *CBuffRevivalSequela__FreeBuff)(int thispointer, int a2) = (int(__thiscall*)(int thispointer, int a2))0x00406F60;
		static signed int(__thiscall *CBuffRevivalSequela__UpdateBuff)(int thispointer, int a2, int a3) = (signed int(__thiscall*)(int thispointer, int a2, int a3))0x00406FC0;
		static signed int(__thiscall *CBuffStun__ApplyBuff)(void *thispointer, int a2) = (signed int(__thiscall*)(void *thispointerpointer, int a2))0x00407010;
		static int(__stdcall *CBuffStun__FreeBuff)(int a1) = (int(__stdcall*)(int a1))0x00407080;
		static signed int(__thiscall *CBuffStun__UpdateBuff)(void *thispointer, int a2, int a3) = (signed int(__thiscall*)(void *thispointerpointer, int a2, int a3))0x004070A0;
		static int(__thiscall *CBuffStun__IsExpired)(void *thispointer, int a2) = (int(__thiscall*)(void *thispointerpointer, int a2))0x00407200;
		static signed int(__thiscall *CBuffMoveStop__ApplyBuff)(void *thispointer, int a2) = (signed int(__thiscall*)(void *thispointerpointer, int a2))0x00407260;
		static int(__stdcall *CBuffMoveStop__FreeBuff)(int a1) = (int(__stdcall*)(int a1))0x004072B0;
		static signed int(__thiscall *CBuffMoveStop__UpdateBuff)(void *thispointer, int a2, int a3) = (signed int(__thiscall*)(void *thispointerpointer, int a2, int a3))0x00407300;
		static int(__thiscall *CBuffMoveStop__IsExpired)(void *thispointer, int a2) = (int(__thiscall*)(void *thispointerpointer, int a2))0x00407440;
		static signed int(__stdcall *CBuffPoison__ApplyBuff)(int a1) = (signed int(__stdcall*)(int a1))0x004074A0;
		static int(__stdcall *CBuffPoison__FreeBuff)(int a1) = (int(__stdcall*)(int a1))0x004074D0;
		static signed int(__thiscall *CBuffPoison__UpdateBuff)(void *thispointer, int a2, int a3) = (signed int(__thiscall*)(void *thispointerpointer, int a2, int a3))0x004074F0;
		static int(__thiscall *CBuffPoison__IsExpired)(int a5) = (int(__thiscall*)(int a5))0x00407620;
		static signed int(__stdcall *CBuffPoisonCloud__ApplyBuff)(int a1) = (signed int(__stdcall*)(int a1))0x00407780;
		static int(__stdcall *CBuffPoisonCloud__FreeBuff)(int a1) = (int(__stdcall*)(int a1))0x004077B0;
		static signed int(__thiscall *CBuffPoisonCloud__UpdateBuff)(void *thispointer, int a2, int a3) = (signed int(__thiscall*)(void *thispointerpointer, int a2, int a3))0x004077D0;
		static int(__thiscall *CBuffPoisonCloud__IsExpired)(int a2) = (int(__thiscall*)(int a2))0x00407900;
		static signed int(__thiscall *CBuffHaste__ApplyBuff)(void *thispointer, int a2) = (signed int(__thiscall*)(void *thispointerpointer, int a2))0x00407A40;
		static int(__thiscall *CBuffHaste__FreeBuff)(void *thispointer, int a2) = (int(__thiscall*)(void *thispointerpointer, int a2))0x00407AC0;
		static signed int(__thiscall *CBuffHP__ApplyBuff)(int a1) = (signed int(__thiscall*)(int a1))0x00407B00;
		static int(__stdcall *CBuffHP__FreeBuff)(int a1) = (int(__stdcall*)(int a1))0x00407B60;
		static signed int(__thiscall *CBuffMP__ApplyBuff)(int a1) = (signed int(__thiscall*)(int a1))0x00407B80;
		static int(__stdcall *CBuffMP__FreeBuff)(int a1) = (int(__stdcall*)(int a1))0x00407BE0;
		static signed int(__thiscall *CBuffRemainDeadEx__SetBuff)(int thispointer, int a2) = (signed int(__thiscall*)(int thispointer, int a2))0x00409AC0;
		static signed int(__thiscall *CBuffRemainXBlow__ApplyBuff)(int a2) = (signed int(__thiscall*)(int a2))0x00409B20;
		static signed int(__thiscall *CBuffRemainPrty__SetBuff)(int thispointer, int a2) = (signed int(__thiscall*)(int thispointer, int a2))0x00409BA0;
		static signed int(__thiscall *CBuffRemainPrty__ApplyBuff)(int a5) = (signed int(__thiscall*)(int a5))0x00409BF0;
		static int(__thiscall *CBuffRemainPrty__FreeBuff)(int a5) = (int(__thiscall*)(int a5))0x00409C40;
		static signed int(__thiscall *CBuffRemainCount__UpdateBuff)(int a2, int a3) = (signed int(__thiscall*)(int a2, int a3))0x00409C80;
		static signed int(__thiscall *CBuffRemainLuckyStone1__ApplyBuff)(int a5) = (signed int(__thiscall*)(int a5))0x00409D80;
		static signed int(__thiscall *CBuffRemainPet__ApplyBuff)(int a5) = (signed int(__thiscall*)(int a5))0x00409DC0;
		static void(__thiscall *CBuffRemainPet__FreeBuff)(int a5) = (void(__thiscall*)(int a5))0x00409E90;
		static signed int(__thiscall *CBuffRemainPet__IsExpired)(int a2) = (signed int(__thiscall*)(int a2))0x0040A040;
		static signed int(__thiscall *CBuffHydrochloricAcid__ApplyBuff)(void *thispointer, int a2) = (signed int(__thiscall*)(void *thispointerpointer, int a2))0x0040A330;
		static int(__stdcall *CBuffHydrochloricAcid__FreeBuff)(int a1) = (int(__stdcall*)(int a1))0x0040A370;
		static signed int(__thiscall *CBuffHydrochloricAcid__IsExpired)(int a2) = (signed int(__thiscall*)(int a2))0x0040A390;
		static signed int(__thiscall *CBuffMixDamage__ApplyBuff)(void *thispointer, int a2) = (signed int(__thiscall*)(void *thispointerpointer, int a2))0x0040A4A0;
		static signed int(__thiscall *CBuffMixDamage__IsExpired)(int a5) = (signed int(__thiscall*)(int a5))0x0040A4F0;
	}
	namespace Party{
		static int(__cdecl* FindParty)(int PartyID) = (int(__cdecl*)(int PartyID))0x0044D4E0;
		static int(__thiscall* GetSize)(int PartyID) = (int(__thiscall*)(int PartyID))0x00412ED0;
		static int(__thiscall* GetPlayerList)(void* PartyID) = (int(__thiscall*)(void* PartyID))0x0044F390;
	}

	namespace CMonster{
		static signed int (__thiscall *IsRemoved)(int Monsterptr) = (signed int (__thiscall*)(int))0x00449450; 
		static signed int (__thiscall *Create)(int a4, int a5) = (signed int (__thiscall*)(int a4, int a5))0x00439FB0; 
		static void (__thiscall *OnDelete)(void *Monster) = (void (__thiscall*)(void*))0x0043a3f0;
		static unsigned long (__thiscall *GetOperatorName)(void *Monster) = (unsigned long (__thiscall*)(void*))0x0043a720;
		static unsigned long (__thiscall *GetGuildName)(void *Monster) = (unsigned long (__thiscall*)(void*))0x00438eb0;
		static void* (__cdecl* FindMonster) (int nID) = (void* (__cdecl*) (int))0x0043A240;
		static int* (__thiscall *NewMonster)(int* InitMonsterptr, GenMonster) = (int* (__thiscall*)(int*, GenMonster))0x00439200;
	}

	namespace CMonsterReal{
		static void (__thiscall *AI)(void* Monsterptr) = (void (__thiscall*)(void*))0x0043D060;
		static int (__thiscall *ScanSight)(void* Monsterptr) = (int (__thiscall*)(void*))0x0043E8C0;
		static int (__thiscall *SetProperty)(int *thisMonster, int *thisInitMonster) = (int (__thiscall*)(int*, int*))0x0043CEA0; 
		static LONG (__thiscall *Add)(int *thisMonster, int a5) = (LONG (__thiscall*)(int*, int))0x0043CFA0;
        static int(__thiscall *ApplyDamage)(int* thisMonster, int* PlayerArray, int a6, int Damage, int a8, int a9, int a10, int a11) = (int(__thiscall*)(int*, int*, int, int, int, int, int, int))0x0043E950;
	}

	namespace CSMap{
		static int (__thiscall *GetCellMap1)(void *thispointer, void* a2, COORDINATES* Coords) = (int (__thiscall*)(void *thispointerpointer, void*, COORDINATES*))0x00438250; 
		static unsigned long (__thiscall *GetCellMap)(void *_this, void*, COORDINATES* Coords) = (unsigned long (__thiscall*)(void*, void*, COORDINATES*))0x00491360;
		static bool (__thiscall *IsValidTile)(int *ptr, COORDINATES* Coords, int a3) = (bool (__thiscall*)(int*, COORDINATES*, int))0x00438130; 
		static int (__thiscall *IsOnTile)(int *ptr, int a2, int a3) = (int (__thiscall*)(int *ptr, int a2, int a3))0x0045CD80; 
	}

	namespace CGenMonster{
		static int (__thiscall *GetGenTile)(int thispointer, int a2, int a3) = (int (__thiscall*)(int thispointer, int a2, int a3))0x00438880; 
	}
	namespace CCalendar
	{
		static void(__thiscall *OnTimer)(int a5) = (void(__thiscall*)(int a5))0x0040A750;
	}

	namespace Unknown{
		static int(__thiscall* unknown_libname_77)(void* unknown) = (int(__thiscall*)(void* unknown))0x0042F830;
		static int(__cdecl *sub_491080)(signed int unk) = (int(__cdecl*)(signed int unk))0x00491080;
		static int(__cdecl *sub_401000)(signed int unk) = (int(__cdecl*)(signed int unk))0x00401000;
		static int(__thiscall *sub_44AE20)(void* Pointer, int a2, int a3) = (int(__thiscall*)(void *Pointer, int a2, int a3))0x0044AE20;
		static int(__thiscall *sub_430C20)(int Pointer, int a2) = (int(__thiscall*)(int Pointer, int a2))0x00430C20;
		static int(__stdcall *unknown_libname_8)(void* Pointer) = (int(__stdcall*)(void* Pointer))0x00431370;
		static int(__thiscall *sub_420250)(void* Pointer) = (int(__thiscall*)(void* Pointer))0x00420250;
		static void(__thiscall *sub_47FF00)(void*, int a5) = (void(__thiscall*)(void*, int a5))0x0047FF00;
	}
		static void* (__thiscall *CMonsterBigBirdMaster)(void* Pointer) = (void* (__thiscall*)(void* Pointer))0x00444290;
};




static unsigned __int64 _ExpTable[] = {
	0, 5, 24, 60, 160, 328, 548, 814, 1157, 1558, //Level 1-10
	2250, 3086, 4135, 5444, 7068, 9126, 11660, 14769, 14769, 18572, 23214, //Level 11-20
	29155, 36409, 45245, 55988, 69026, 85569, 105656, 130009, 159494, 159150, //Level 21-30
	238255, 290216, 352918, 428488, 519513, 629149, 761081, 919784, 1110624, 1340045, //Level 31-40
	1615778, 1947099, 2345141, 2823265, 3397501, 4087087, 4915108, 5909267, 7102808, 8535623, //Level 41-50
	10255633, 12320243, 14798389, 17772795, 21342730, 25627317, 30769501, 36940820, 44347118, 53235407, //Level 51-60
	63902104, 76702906, 92064653, 110499551, 132622249, 169170373, 191028978, 229260177, 275138508, 330193415, //Level 61-70
	396260232, 1188853398, 1426699190, 1712116603, 2054620005, 2465627972, 2958842501, 3550695049, 4260939963, 5113193317, //Level 71-80
	6135910416, 7363228039, 8835873647, 10603329445, 12723860419, 15268923922, 18322568824, 21987686895, 26385224274, 31663104567, //Level 81-90
	37993920972, 45594437478, 54712077691, 65659881812, 78786685050, 94540297802, 113442994895, 136147038801, 163398692810, 266078431385, //Level 91-100
	325294117685, 372352941185, 468823529485, 539647058885, 588094117685, 647712941185, 711484235285, 789781082385, 819781082385, 939781082385, //Level 101-110
	1049781082385, 2079781082385, 3099781082385, 4119781082385, 5139781082385, 6169781082385, 7199781082385, 8269781082385, 9319781082385, 1699781082385, //Level 111-120
	1869781082385
};

//
//
//
//static unsigned __int64 _ExpTable[] = {
//	0, 85, 97, 111, 127, 146, 167, 192, 220, 252, 289, // 10
//	332, 381, 438, 503, 578, 664, 763, 877, 1008, 1159, // 20
//	1332, 1531, 1760, 2023, 2326, 2674, 3075, 3536, 4066, 4675, // 30
//	5376, 6182, 7109, 8175, 9401, 10811, 12432, 14296, 16440, 18906, // 40
//	21741, 25002, 28752, 33064, 38023, 43726, 50284, 57826, 66499, 76473, // 50
//	87943, 101134, 116304, 133749, 153811, 176882, 203414, 233926, 269014, 309366, // 60
//	355770, 409135, 470505, 541080, 622242, 715578, 822914, 946351, 1088303, 1251548, // 70
//	1439280, 1655171, 1903446, 2188962, 2517306, 2894901, 3329136, 3828506, 4402781, 5063198, // 80
//	5822677, 6696078, 7700489, 8855562, 10183896, 11711480, 13468201, 15488431, 17811695, 20483449, // 90
//	23555966, 27089360, 31152763, 35825677, 41199528, 47379457, 54486375, 62659331, 72058230, 82866964, // 100
//	95297008, 109591559, 126030292, 144934835, 166675060, 191676319, 220427766, 253491930, 291515719, 335243076, // 110
//	385529537, 443358967, 509862812, 586342233, 674293567, 775437602, 891753242, 1025516228, 1179343662, 1356245211, // 120
//	1559681992, 1793634290, 2062679433, 2372081347, 2727893549, 3137077581, 3607639218, 4148785100, 4771102865, 5486768294, // 130
//	6309783538, 7256251068, 8344688728, 9596392037, 11035850842, 12691228468, 14594912738, 16784149648, 19301772095, 22197037909, // 140
//	25526593595, 29355582634, 33758920029, 38822758033, 44646171737, 51343097497, 59044562121, 67901246439, 78086433404, 89799398414, // 150
//	103269308176, 118759704402, 136573660062, 157059709071, 180618665431, 207711465245, 238868185031, 274698412785, 315903174702, 363288650907, // 160
//	417781948543, 480449240824, 552516626947, 635394120989, 730703239137, 840308725007, 966355033758, 1111308288821, 1278004532144, 1469705211965, // 170
//	1690160993759, 1943685142822, 2235237914245, 2570523601381, 2956102141588, 3399517462826, 3909445082249, 4495861844586, 5170241121273, 5945777289463, // 180
//	6837643882882, 7863290465314, 9042784035111, 10399201640377, 11959081886433, 13752944169397, 15815885794806, 18188268664026, 20916508963629, 24053985308173, // 190
//	27662083104398, 31811395570057, 36583104905565, 42070570641399, 48381156237608, 55638329673249, 63984079124236, 73581690992871, 84618944641801, 97311786338071, // 200
//	111908554288781, 128694837432098, 147999063046912, 170198922503948, 195728760879540, 225088075011470, 258851286263190, 297678979202668, 342330826083068, 393680449995528, // 210
//	452732517494857, 520642395119085, 598738754386947, 688549567544989, 791832002676737, 910606803078247, 1047197823539984, 1204277497070981, 1384919121631628, 1592656989876372, // 220
//	1831555538357827, 2106288869111501, 2422232199478226, 2785567029399959, 3203402083809952, 3683912396381444, 4236499255838660, 4871974144214459, 5602770265846627, 6443185805723621, // 230
//	7409663676582164, 8521113228069488, 9799280212279910, 11269172244121896, 12959548080740180, 14903480292851206, 17139002336778886, 19709852687295716, 22666330590390072, 26066280178948580, // 240
//	29976222205790864, 34472655536659492, 39643553867158416, 45590086947232176, 52428599989317000, 60292889987714544, 69336823485871720, 79737347008752464, 91697949060065328, 105452641419075120, // 250
//	121270537631936384, 139461118276726832, 160380286018235840, 184437328920971200, 212102928259116864 // 255
//};
#endif





