#ifndef __LUNACORE_H
#define __LUNACORE_H
#undef UNICODE
#include <cstdio>
#include <windows.h>
#include <detours.h> 
#include <process.h>
#include <vector>
#include "KTools.h"
#include "KExports.h"
#include "KServer.h"


using namespace std;
class LunaCore
{
private:
   	DWORD call_reason;
	
   	vector<PVOID*> sources;
    	vector<PVOID> destinations;

    	vector<unsigned long> hook_sources;
    	vector<PVOID> hook_destinations;

	vector<unsigned char> intercept_instruction;
	vector<void*> intercept_sources;
    	vector<void*> intercept_destinations;
	vector<size_t> intercept_length;

	int ExportsType;
public:
	LunaCore(){}
	void Register(PVOID* source, PVOID dest);
    	void RegisterHook(unsigned long source, PVOID dest);
   	void RegisterCustom(void (*pfunc)());
	void RegisterIntercept(unsigned char instruction, void* source, void* destination, size_t length);

   	void Init(DWORD call_reason, int Exports);
	void InitExports();
	void SetExportsType(int exportstype);
	void SetCallReason(DWORD call_reason);
  
	void Attach();
    	void Detach();
    	bool Run();
};
#endif