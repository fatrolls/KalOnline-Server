#ifndef __KCONSOLE_H
#define __KCONSOLE_H

#include <string>
#include "Lock.h"
#include "EngineTools.h"

using namespace std;

class KConsole
{
	private:
		Lock Lock;
	protected:
		bool IsAllocated;
		string Title;

	public:
		void SetAllocated(bool isAllocated);
		bool GetAllocated();
		void Init(string Title = "Luna Console");
		void Write(int TextColor, string Output, ...);
		void _Write(int TextColor, string Input);
		void Hide();
		void Toggle();
		void Show();
};


enum _CTextColor{
	Black = 0,
	DarkBlue = 1,
	DarkGreen = 2,
	LightBlue = 3,
	DarkRed = 4,
	DarkMagenta = 5,
	DarkYellow = 6,
	White = 7,
	Grey = 8,
	
	Green = 10,

	Magenta = 13,
	Yellow = 14,
	test = 4 + 14*16,
};

#endif