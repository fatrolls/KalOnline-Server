#ifndef __KENGINE_H
#define __KENGINE_H
#include <WinSock2.h>
#include <string>
#include <KTools.h>
#include <KServer.h>
#include <iostream>
#include <sstream>

#pragma comment(lib, "libeay32.lib")
#include <iomanip>  
#include <stdio.h>  
#include <openssl/sha.h>  

using namespace std;

typedef struct screenOverlay_s
{
	float		x;
	float		y;
	float		width;
	float		height;
	int			*pTexture;
} screenOverlay_t;

typedef struct
{
	screenOverlay_t	*	pCurOverlay;
	float				lifeTime;
	float				curLifeTime;
	DWORD				color;
	BYTE				byType;

} OVERLAY_CONTAINER;


class KEngine{
public:
	void CopyExpTable(int EngineType);
	void InfoMessage(int color, char* Text, ...);
	void SetTip(int pTarget, const char* Text, COLORREF color, int dwLife, int bShowName);
	char* GetNameTag(int HonorRank);
	int ScreenOverlay(const char* FileName, int time, int color, int Type);
};

enum EngineType{
	OldEngine = 0,
	NewEngine = 1,
};

namespace EngineOld
{
	namespace KWindowCollector
	{
		static void(__cdecl *ProcessDestroy)() = (void(__cdecl*)())0x004A73B0;
		static int(__cdecl *MBox)(const char* pText, int nType, int nAction, int nDest, int nDest2) = (int(__cdecl*)(const char*, int, int, int, int))0x004A76C0;
	}
	namespace KGameSys
	{
		static int(__cdecl* UpdateStatus)() = (int(__cdecl*)())0x004AC410;
		static void(__cdecl *AddChattingMessage)(char Type, const char* Message, int Color) = (void(__cdecl*)(char, const char*, int))0x004AB5C0;
		static void(__cdecl *AddInfoMessage)(const char* Message, int Color, int Type) = (void(__cdecl*)(const char*, int, int))0x004AB5F0;
		static void(__cdecl *AddNoticeString)(const char* Message, int Color) = (void(__cdecl*)(const char*, int))0x004AA980;
		static void(__cdecl *AddMessageString)(const char* Text, int Color) = (void(__cdecl*)(const char*, int))0x004AA8F0;
		
		//static void(__cdecl *SetBuff)(BYTE Index, int Time, BYTE Type, BYTE Page) = (void(__cdecl*)(BYTE, int, BYTE, BYTE))0x0048F7F0;
		//static int(__cdecl *InsertBuff)(int ID, int TargetID, int Index, int Level, char State, int Type, int Time, char Text) = (int(__cdecl*)(int, int, int, int, char, int, int, char))0x004AA750;
		//static int(__cdecl *InsertBuff1)(int nID, int nTargetID, __int64 n64Index, BYTE bySkillLevel, __int64 n64State, BYTE byType, __int64 extension) = (int(__cdecl*)(int, int, __int64, BYTE, __int64, BYTE, __int64))0x004AA750;
		
		static int(__cdecl *BeginProductionbar)(int Type, int Time) = (int(__cdecl*)(int, int))0x004AFD90;
		static int(__cdecl *UpDataProductionbar)() = (int(__cdecl*)())0x004AFE40;
		static int(__cdecl *EndProductionbar)() = (int(__cdecl*)())0x004AFE90;

		static int(__cdecl *SetToolTip)(LPCTSTR Text) = (int(__cdecl*)(LPCTSTR))0x004AE640;
		static int(__cdecl *SetDrag)(int Index, int IID) = (int(__cdecl*)(int, int))0x004AE680;

		
	//	static int(__thiscall *Rect)(int a, RECT *lprc) = (int(__thiscall *)(int, RECT *))0x0040A580;
		//static int(__thiscall *InsertBuffIcon)(int *Target, int BuffIconID, int Time, int Type, int Sysnum) = (int(__thiscall *)(int *, int, int, int, int))0x00473960;

		static void(__cdecl *SetScreenInfo)(unsigned char Type, const char* Message) = (void(__cdecl*)(unsigned char, const char*))0x004AFF20;
	
		static int (__thiscall *SetIcon)(void* a, int Key, int Time, int Type, int nMsg) = (int (__thiscall*)(void*, int, int, int, int))0x00473960;
		static int (__thiscall *RemoveIcon)(void* a, int Key, int nMsg) = (int (__thiscall*)(void*, int, int))0x004736D0;
		static int (__thiscall *ShowBuffIcon)(int a, RECT *lprc) = (int (__thiscall*)(int, RECT*))0x0040A580;
		

		static int(__thiscall *SetBuff)(int* a, int a2, int a3, signed __int64 a4, int a5, int a6, int a7, int a8) = (int(__thiscall*)(int*, int, int, signed __int64, int, int, int, int))0x0046EB60;
		static int (__cdecl *CallBuff)(int Key, int nMsg, signed __int64 Time, int a4, int Type, int Packet, int a7) = (int (__cdecl*)(int, int, signed __int64, int, int, int, int))0x004AA750;

	}
	namespace KSocket
	{
		//static int(__stdcall *OriginalReceiveReturn)(SOCKET s, char *buf, int len, int flags) = (int(__stdcall*)(SOCKET, char*, int, int))0x00692470;
		static int(__stdcall *Receive)(SOCKET Socket, char* Buffer, int Length, int Flags) = (int(__stdcall*)(SOCKET, char*, int, int))0x0052F060;
		static int(__thiscall *SendPacket)(void* _this, const char* Buffer, int Length) = (int(__thiscall*)(void*, const char*, int))0x0052CBF0;
		static int *g_lpClient = (int*)0x0070F9C8;
	}
	namespace CGame_Character
	{
		static int(__cdecl* FindMonster)(int BaseID) = (int(__cdecl*)(int))0x00407A50;
		static unsigned long *m_Master = (unsigned long*)0x006F3840;
		static int(__cdecl *FindCharByID)(unsigned int ID) = (int(__cdecl*)(unsigned int))0x00407BF0;
		static int(__cdecl *FindCharByName)(const char* Name) = (int(__cdecl*)(const char*))0x00407B10;
		static int(__thiscall *SetTipEX)(int pTarget, string Text, COLORREF color) = (int(__thiscall*)(int, string, COLORREF))0x0040F760;
		static void(__thiscall *SetTip)(int pTarget, const char* Text, COLORREF color, int dwLife, int bShowName) = (void(__thiscall*)(int, const char*, COLORREF, int, int))0x0040E730;
	}
	namespace KMainCharInfo
	{
		static int(__cdecl *FindItemIndex)(int Index) = (int(__cdecl*)(int))0x00482CA0;
		static int(__cdecl *FindItemFromIID)(int IID) = (int(__cdecl*)(int))0x00482D00;
	}
	namespace KMacro
	{
		static int(__cdecl *FindItem)(int Index) = (int(__cdecl*)(int))0x0054C6A0;
	}
	namespace CGame_Effect
	{
		static int(__thiscall *Add)(int*_this, const char *filename, int targetId, int bGubun) = (int(__thiscall*)(int*, const char*, int, int))0x00412B90;
		static int(__thiscall *AddParticle)(const char *EffectName, int a3, int a4) = (int(__thiscall*)(const char*, int, int))0x00442320;
		static int(__thiscall *AddParticleToTargetBone)(void *_this, char *EffectName, int a3, int a4, int a5, int a6, int a7) = (int(__thiscall*)(void*, char*, int, int, int, int, int))0x004428E0;
		static int(__thiscall *AddFx)(void *_this, char *a2, int a3, int a4) = (int(__thiscall*)(void*, char*, int, int))0x00445B50;
		static int(__thiscall *AddFxToTarget)(void *_this, char *a2, int a3, int a4) = (int(__thiscall*)(void*, char*, int, int))0x00445DC0;
	}
	namespace CGame_ScreenOverlay
	{
		static int(__thiscall *Init)(int _this) = (int(__thiscall*)(int))0x00413B50;
		static char(__thiscall *Set)(int _this, int overlay, int time, int color, int Type) = (char(__thiscall*)(int, int, int, int, int))0x00414660;
		
	}
	namespace CTexture
	{
		static int(__cdecl* Load)(int a1, int a2, int a3) = (int(__cdecl*)(int, int, int))0x00577030;
		//static int(__cdecl *Load)(int FileName, int a2, int a3) = (int(__cdecl*)(int, int, int))0x0055FE40;
	}
	namespace KConfigPK
	{
		static char* (__cdecl *GetSys)(int a1) = (char*(__cdecl*)(int))0x0053F560;
	}
	namespace Unknown
	{
		//static int(__thiscall* sub_4013A0)(void *_this, int a2) = (int(__thiscall*)(void*, int))0x004013A0;
		//static int (__cdecl* sub_407A50)(int a1) = (int(__cdecl*)(int))0x00407A50;
		static void*(__thiscall *sub_55FE40)(void* _this) = (void*(__thiscall*)(void*))0x0055FE40;
		static int(__thiscall *sub_4013A0)(void *_this, int a2) = (int(__thiscall*)(void*, int))0x004013A0;

		static int (__cdecl *sub_407A50)(int a1) = (int(__cdecl*)(int))0x00407A50;

	
	}

	struct Packet
	{
		unsigned short Size;
		unsigned char Type;
		char Data[8000];
	};
}
#endif



static unsigned __int64 EngineExpTable[] = {
	0, 5, 24, 60, 160, 328, 548, 814, 1157, 1558, //Level 1-10
	2250, 3086, 4135, 5444, 7068, 9126, 11660, 14769, 14769, 18572, 23214, //Level 11-20
	29155, 36409, 45245, 55988, 69026, 85569, 105656, 130009, 159494, 159150, //Level 21-30
	238255, 290216, 352918, 428488, 519513, 629149, 761081, 919784, 1110624, 1340045, //Level 31-40
	1615778, 1947099, 2345141, 2823265, 3397501, 4087087, 4915108, 5909267, 7102808, 8535623, //Level 41-50
	10255633, 12320243, 14798389, 17772795, 21342730, 25627317, 30769501, 36940820, 44347118, 53235407, //Level 51-60
	63902104, 76702906, 92064653, 110499551, 132622249, 169170373, 191028978, 229260177, 275138508, 330193415, //Level 61-70
	396260232, 1188853398, 1426699190, 1712116603, 2054620005, 2465627972, 2958842501, 3550695049, 4260939963, 5113193317, //Level 71-80
	6135910416, 7363228039, 8835873647, 10603329445, 12723860419, 15268923922, 18322568824, 21987686895, 26385224274, 31663104567, //Level 81-90
	37993920972, 45594437478, 54712077691, 65659881812, 78786685050, 94540297802, 113442994895, 136147038801, 163398692810, 266078431385, //Level 91-100
	325294117685, 372352941185, 468823529485, 539647058885, 588094117685, 647712941185, 711484235285, 789781082385, 819781082385, 939781082385, //Level 101-110
	1049781082385, 2079781082385, 3099781082385, 4119781082385, 5139781082385, 6169781082385, 7199781082385, 8269781082385, 9319781082385, 1699781082385, //Level 111-120
	1869781082385
};