#ifndef __KITEM_H
#define __KITEM_H

class KItem
{
public:
	int* ItemArray;
	KItem(){};
	KItem(int* ItemArray);
	virtual ~KItem();

	int* GetArray(void);
	void SetArray(int* ItemArray);

	int GetIndex();
	int GetPid();
	int GetID();
	int GetAttack();
	int GetMagicAttack();
	int GetPrefix();
	int GetInfo();
	int GetIID();
	int GetOTP();
	int GetEva();
	int GetDef();
	int GetEB();
	int GetAmount();
	
	int SetAttack(int x);
	int SetMagicAttack(int x);
	int SetInfo(int x);
	int SetOTP(int x);
	int SetEva(int x);
	int SetDef(int x);

};

#endif