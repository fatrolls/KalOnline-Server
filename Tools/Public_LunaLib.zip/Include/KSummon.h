#ifndef __KSUMMON_H
#define __KSUMMON_H
#include <Windows.h>
//#include <time.h>
//#include <Mmsystem.h>

#include "KServer.h"
#include "KMonster.h"
#include "KPlayer.h"
#include "KTools.h"
using namespace std;

class KSummon
{
public:
	int* Monster(int index, int x, int y, int map, int amount, int casttype = 0, int casterpid = 0);
	int* Monster1(int index, int x, int y, int map, int amount);
	int* Monster2(int index, int x, int y, int map, int amount);
};
#endif