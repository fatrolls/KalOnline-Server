#ifndef __KPLAYER_H
#define __KPLAYER_H
#include <Windows.h>
#include <string>
#include "KServer.h"
#include "IniWriter.h"

using namespace std;
class KPlayer
{
public:
	int* PlayerArray;
	KPlayer(){};
	KPlayer(int* PointerToArray);
	virtual ~KPlayer();

	int* GetArray(void);
	void SetArray(int* PointerToArray);

	void CIOCriticalSectionEnter(void);
	void CIOCriticalSectionLeave(void);

	bool isGood();


	
	char* GetName();
	int GetAdmin();
	int GetLevel();
	int GetClass();
	int GetID();
	int GetPID();
	int GetUID();
	int GetType();
	int GetX();
	int GetY();
	int GetZ();
	int GetMap();
	bool IsOnMap(int map_);
	bool IsOnTile(int x);
	bool IsValidTile(int x);

	bool IsKnight();
	bool IsMage();
	bool IsArcher();
	bool IsThief();
	
	int GetCurHp();
	int GetCurMp();
	int GetMaxHp();
	int GetMaxMp();
	int GetStr(void);
	int GetHth(void);
	int GetAgi(void);
	int GetInt(void);
	int GetWis(void);
	int GetMaxPhyAtk(void);
	int GetMinPhyAtk(void);
	int GetMaxMagAtk(void);
	int GetMinMagAtk(void);
	int GetResist(unsigned char Type);
	int GetHit(void);
	int GetDodge(void);
	int GetDefense(void);
	int GetFinalDefense(int arg);
	int GetAttackSpeed(void);
	int GetAbsorb(void);
	int GetAttack(void);
	int GetMagic(void);


	int GetStatPoints();
	int GetSkillPoints();
	int GetRange();
	int GetSpeciality(void);
	int GetContribute(void);
	int GetGRole(void);
	int GetKilled();
	int GetRage();
	int GetGState();

	bool isNormal();
	bool isSupporter();
	bool isGM();
	bool isAdmin();

	void Teleport(bool AssassinSave, int map, int x, int y, int z = 0);
	int UpdateProperty(int Type, int AddSub, int Amount);

	void ChatMessage(char* Name, char* Text, ...);

	void PrivateNotice(char* Text, ...);
	void Notice(bool Private, bool ShowName, int Color, const char* Text, ...);

	void ScreenInfo(bool Private, bool ShowName, int Type, const char* Text, ...);
	void InfoMessage(int color, char* Text, ...);

	bool IsGstate(unsigned long State);

	int InsertItem(int Index, int Prefix, int Amount, bool Bound);

	void CancelBuff(int id);
	void InsertBuff(int id, int time, int inc);
	
	void Kick();

	
	void ShowMessageBox(char*Text, int Type, int Action, int Dest1, int Dest2);

	void Block();


	void SetAdmin(int x);
	void Levelup(int level, int statpoint, int skillpoint);

	void InsertBuffIcon(int Time, int Type, int nMsg, int Key);
	void RemoveBuffIcon(int Time, int Type, int nMsg, int Key);

	bool IsinRect(int x1, int y1, int x2, int y2);

	bool RemoveItem(int Index, int Amount);
	void ShowScreenOverlay(bool Private, const char* FileName, int Time, int D3DColor, int Type);

	

};

#endif