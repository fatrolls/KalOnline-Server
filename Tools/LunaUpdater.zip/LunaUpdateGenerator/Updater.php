<?php
$command = $_REQUEST['command'];

if($command == "GetChangelog")
{
	$file = file_get_contents('./Changelog.txt', true);
	echo"$file";
}
else if($command == "GetNews")
{
        echo "LunaClient Updater";
}
else if($command == "GetNewsColor")
{
        echo 10;
}
else if($command == "GetFileListPath")
{
        echo "http://www.YourDomain.com/LunaUpdater/FileList.xml";
}
else if($command == "GetDeleteListPath")
{
        echo "http://www.YourDomain.com/LunaUpdater/DeleteList.xml";
}
?>
