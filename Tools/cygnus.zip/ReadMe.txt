README.TXT
==========

Cygnus Hex Editor 2.50
----------------------
This is the fastest and easiest hex editor available anywhere! Features include tabbed MDI interface, multi-level undo & redo, extensive drag & drop support, Data Inspector allows you to view and edit data using natural data types and structures, support for powerful user-writable plug-ins, blazing fast and flexible search, search and replace, file compare, delete and insert characters as easily as you can in a word processor, edit files up to available virtual memory (up to 2GB), and many more powerful features.

IMPORTANT: This program requires Windows NT 4.0, Windows 2000, Windows 2003, Windows XP or later. Older versions of the software are available for users running Windows 95, Windows 98, Windows ME, and Windows NT 3.5.

See http://www.softcircuits.com/cygnus/ for more information.

Installation
------------
To install this program on your system, run Setup.exe. This file performs the installation and all program files are included within this file. To create an install disk, you can simply copy this file to a disk. An uninstall program is included to remove this application from your system.

Shareware
---------
This software is distributed as shareware. Registration for this program is only $39.00. Site license agreements are also available. When you register, we will send you a registration key to fully activate your copy and eliminate all shareware reminders. Registration also gives you 90 days of free telephone support and unlimited technical support via email and/or standard mail.

SoftCircuits Programming
PO Box 1355
West Jordan, UT 84084-8355
USA
http://www.softcircuits.com
